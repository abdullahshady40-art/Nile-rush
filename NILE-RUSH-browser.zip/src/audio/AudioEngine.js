import { Sfx } from './Sfx.js';
import { Music } from './Music.js';

/** Web Audio engine: master bus, SFX synthesis, generative Egyptian-flavoured music, optional file overrides. */
export class AudioEngine {
  constructor() {
    this.ctx = null; this.vol = { music: 0.7, sfx: 0.9, mute: false };
    this.buffers = { sfx: {}, music: {} };
    this.sfxSynth = null; this.music = null; this.pendingTrack = null;
  }
  get ready() { return !!this.ctx; }

  /** Must be called from a user gesture (tap / key). Safe to call repeatedly. */
  unlock() {
    if (!this.ctx) {
      const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return false;
      try { this.ctx = new AC({ latencyHint: 'interactive' }); } catch (e) { return false; }
      const c = this.ctx;
      this.master = c.createGain(); this.comp = c.createDynamicsCompressor();
      this.comp.threshold.value = -14; this.comp.ratio.value = 4; this.comp.attack.value = 0.004; this.comp.release.value = 0.2;
      this.musicGain = c.createGain(); this.sfxGain = c.createGain();
      this.musicGain.connect(this.master); this.sfxGain.connect(this.master); this.master.connect(this.comp); this.comp.connect(c.destination);
      this.sfxSynth = new Sfx(this); this.music = new Music(this);
      this.applyVolumes();
      if (this.pendingTrack) this.music.play(this.pendingTrack);
    }
    if (this.ctx.state === 'suspended') this.ctx.resume();
    return true;
  }
  setVolumes(v) { Object.assign(this.vol, v); this.applyVolumes(); }
  applyVolumes() {
    if (!this.ctx) return; const t = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.vol.mute ? 0 : 1, t, 0.03);
    this.musicGain.gain.setTargetAtTime(this.vol.music * 0.55, t, 0.05);
    this.sfxGain.gain.setTargetAtTime(this.vol.sfx, t, 0.05);
  }
  suspend() { if (this.ctx && this.ctx.state === 'running') this.ctx.suspend(); }
  resume() { if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume(); }

  async decodeOverrides(rawSfx, rawMusic) {
    if (!this.ctx) return;
    for (const [k, buf] of Object.entries(rawSfx || {})) { try { this.buffers.sfx[k] = await this.ctx.decodeAudioData(buf.slice(0)); } catch (e) { console.warn('SFX decode failed', k); } }
    for (const [k, buf] of Object.entries(rawMusic || {})) { try { this.buffers.music[k] = await this.ctx.decodeAudioData(buf.slice(0)); } catch (e) { console.warn('Music decode failed', k); } }
  }
  sfx(name, opt) {
    if (!this.ctx || this.vol.mute || this.vol.sfx <= 0) return;
    const b = this.buffers.sfx[name];
    if (b) { const s = this.ctx.createBufferSource(); s.buffer = b; s.connect(this.sfxGain); s.start(); return; }
    this.sfxSynth.play(name, opt);
  }
  playMusic(track) { this.pendingTrack = track; if (this.music) this.music.play(track); }
  stopMusic() { this.pendingTrack = null; if (this.music) this.music.stop(); }
  setIntensity(v) { if (this.music) this.music.intensity = v; }
}
