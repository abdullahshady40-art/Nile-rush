// Generative music in D Hijaz (Phrygian dominant): darbuka maqsum rhythm, plucked oud-style lead, drone and pad.
const ROOT = 146.83; // D3
const HIJAZ = [0, 1, 4, 5, 7, 8, 10, 12, 13, 16, 17, 19];
const hz = (semi) => ROOT * Math.pow(2, semi / 12);
const MAQSUM = ['D', '', 'T', 'T', 'D', '', 'T', ''];
const CHORDS = [[0, 7, 12], [1, 8, 13], [0, 7, 12], [-2, 5, 10]];

export class Music {
  constructor(eng) {
    this.e = eng; this.c = eng.ctx; this.playing = false; this.track = ''; this.step = 0; this.timer = 0; this.nextT = 0;
    this.intensity = 0; this.tempo = 90; this.phrase = []; this.bar = 0; this.src = null;
    this.out = this.c.createGain(); this.out.connect(eng.musicGain);
    const len = this.c.sampleRate * 0.5, b = this.c.createBuffer(1, len, this.c.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1; this.noise = b;
  }
  play(track) {
    if (this.track === track && this.playing) return;
    this.stop(); this.track = track; this.playing = true; this.step = 0; this.bar = 0; this.nextT = this.c.currentTime + 0.08; this._newPhrase();
    const buf = this.e.buffers.music[track === 'menu' || track === 'intro' ? 'menu' : 'game'];
    if (buf) { this.src = this.c.createBufferSource(); this.src.buffer = buf; this.src.loop = true; this.src.connect(this.out); this.src.start(); return; }
    this.timer = setInterval(() => this._tick(), 25);
  }
  stop() {
    this.playing = false; this.track = ''; clearInterval(this.timer); this.timer = 0;
    if (this.src) { try { this.src.stop(); } catch (e) { /* already stopped */ } this.src = null; }
  }
  _newPhrase() {
    const p = []; let d = 4;
    for (let i = 0; i < 16; i++) {
      if (i % 4 === 0 || Math.random() < 0.55) { d = Math.max(0, Math.min(HIJAZ.length - 1, d + [-2, -1, -1, 0, 1, 1, 2][Math.floor(Math.random() * 7)])); p.push(HIJAZ[d]); } else p.push(null);
    }
    p[0] = 0; p[15] = Math.random() < 0.5 ? 7 : 1; this.phrase = p;
  }
  _tick() {
    if (!this.playing) return;
    const c = this.c; if (c.state !== 'running') { this.nextT = c.currentTime + 0.05; return; }
    const game = this.track === 'game';
    const bpm = game ? 108 + this.intensity * 40 : this.track === 'intro' ? 96 : 84;
    const stepDur = 60 / bpm / 2; // eighth notes
    while (this.nextT < c.currentTime + 0.14) { this._play(this.step, this.nextT, stepDur, game); this.nextT += stepDur; this.step++; if (this.step % 16 === 0) { this.bar++; if (this.bar % 4 === 0) this._newPhrase(); } }
  }
  _play(step, t, dur, game) {
    const s8 = step % 8, s16 = step % 16, chord = CHORDS[Math.floor(step / 16) % 4];
    const m = MAQSUM[s8];
    if (m === 'D') this._dum(t, game ? 0.5 : 0.36); else if (m === 'T') this._tak(t, game ? 0.28 : 0.2);
    if (game && s8 % 2 === 1) this._tak(t + dur * 0.5, 0.09);
    if (s16 % 8 === 0) this._pad(hz(chord[0] - 12), hz(chord[1] - 12), hz(chord[2]), t, dur * 8);
    if (s8 === 0 || s8 === 4) this._pluck(hz(chord[0] - 12), t, dur * 3, 0.18, 'triangle', 700);
    if (game && (s8 === 2 || s8 === 6)) this._pluck(hz(chord[1] - 12), t, dur * 1.5, 0.1, 'triangle', 600);
    const n = this.phrase[s16];
    if (n !== null && n !== undefined) { this._pluck(hz(n + 12), t, dur * 2.2, game ? 0.15 : 0.13, 'sawtooth', 2600); if (game && s16 % 4 === 3) this._pluck(hz(n + 24), t + dur * 0.5, dur, 0.05, 'triangle', 3000); }
  }
  _env(g, t, a, d, v) { g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(v, t + a); g.gain.exponentialRampToValueAtTime(0.0001, t + d); }
  _pluck(f, t, d, v, type, cutoff) {
    const c = this.c, o = c.createOscillator(), o2 = c.createOscillator(), g = c.createGain(), fl = c.createBiquadFilter();
    o.type = type; o2.type = 'sine'; o.frequency.value = f; o2.frequency.value = f * 2.005; fl.type = 'lowpass'; fl.frequency.setValueAtTime(cutoff, t); fl.frequency.exponentialRampToValueAtTime(Math.max(300, cutoff * 0.25), t + d);
    this._env(g, t, 0.004, d + 0.15, v); o.connect(fl); o2.connect(fl); fl.connect(g); g.connect(this.out); o.start(t); o2.start(t); o.stop(t + d + 0.2); o2.stop(t + d + 0.2);
  }
  _pad(f1, f2, f3, t, d) {
    const c = this.c, g = c.createGain(), fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = 900;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.055, t + d * 0.35); g.gain.linearRampToValueAtTime(0.0001, t + d);
    for (const f of [f1, f2, f3]) for (const det of [-6, 6]) { const o = c.createOscillator(); o.type = 'sawtooth'; o.frequency.value = f; o.detune.value = det; o.connect(fl); o.start(t); o.stop(t + d + 0.1); }
    fl.connect(g); g.connect(this.out);
  }
  _dum(t, v) {
    const c = this.c, o = c.createOscillator(), g = c.createGain(); o.frequency.setValueAtTime(150, t); o.frequency.exponentialRampToValueAtTime(52, t + 0.16);
    this._env(g, t, 0.003, 0.28, v); o.connect(g); g.connect(this.out); o.start(t); o.stop(t + 0.32);
  }
  _tak(t, v) {
    const c = this.c, s = c.createBufferSource(), fl = c.createBiquadFilter(), g = c.createGain(); s.buffer = this.noise; fl.type = 'bandpass'; fl.frequency.value = 3200; fl.Q.value = 1.4;
    this._env(g, t, 0.001, 0.07, v); s.connect(fl); fl.connect(g); g.connect(this.out); s.start(t, Math.random() * 0.3); s.stop(t + 0.1);
  }
}
