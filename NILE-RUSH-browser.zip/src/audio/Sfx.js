// Procedural sound effects built with oscillators and noise — no audio files required.
export class Sfx {
  constructor(eng) { this.e = eng; this.c = eng.ctx; this.out = eng.sfxGain; this.noiseBuf = this._noise(); this.last = {}; }
  _noise() { const c = this.c, len = c.sampleRate * 1.2, b = c.createBuffer(1, len, c.sampleRate), d = b.getChannelData(0); for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1; return b; }

  tone(f, dur, type = 'sine', vol = 0.3, f2 = null, delay = 0, attack = 0.005) {
    const c = this.c, t = c.currentTime + delay, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t); if (f2) o.frequency.exponentialRampToValueAtTime(Math.max(20, f2), t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + attack); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(this.out); o.start(t); o.stop(t + dur + 0.05);
  }
  noise(dur, vol = 0.3, ftype = 'lowpass', f1 = 2000, f2 = null, delay = 0, q = 1) {
    const c = this.c, t = c.currentTime + delay, s = c.createBufferSource(), fl = c.createBiquadFilter(), g = c.createGain();
    s.buffer = this.noiseBuf; s.loop = true; fl.type = ftype; fl.Q.value = q; fl.frequency.setValueAtTime(f1, t);
    if (f2) fl.frequency.exponentialRampToValueAtTime(Math.max(30, f2), t + dur);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + 0.01); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    s.connect(fl); fl.connect(g); g.connect(this.out); s.start(t, Math.random() * 0.5); s.stop(t + dur + 0.05);
  }

  play(name, o = {}) {
    const now = this.c.currentTime;
    const throttle = { coin: 0.03, lane: 0.05, dust: 0.1 }[name];
    if (throttle && this.last[name] && now - this.last[name] < throttle) return; this.last[name] = now;
    const S = this;
    switch (name) {
      case 'jump': S.tone(260, 0.2, 'sine', 0.28, 620); S.noise(0.12, 0.08, 'highpass', 1200, 3000); break;
      case 'land': S.tone(120, 0.14, 'sine', Math.min(0.4, 0.15 + (o.v || 0) * 0.01), 50); S.noise(0.08, 0.1, 'lowpass', 900, 300); break;
      case 'slide': S.noise(0.42, 0.2, 'bandpass', 1800, 500, 0, 0.8); break;
      case 'lane': S.noise(0.1, 0.06, 'bandpass', 1500, 2600, 0, 1.2); break;
      case 'coin': { const k = Math.min(o.combo || 0, 8), b = 988 * Math.pow(1.0595, k); S.tone(b, 0.09, 'square', 0.1); S.tone(b * 1.335, 0.2, 'square', 0.1, null, 0.06); S.tone(b * 2, 0.25, 'sine', 0.08, null, 0.06); break; }
      case 'gem': [1319, 1568, 1976, 2637].forEach((f, i) => { S.tone(f, 0.25, 'triangle', 0.16, null, i * 0.05); S.tone(f * 2, 0.3, 'sine', 0.05, null, i * 0.05); }); break;
      case 'hit': S.noise(0.5, 0.55, 'lowpass', 2400, 120); S.tone(160, 0.5, 'sawtooth', 0.35, 40); S.tone(90, 0.6, 'sine', 0.5, 30); break;
      case 'smash': S.noise(0.35, 0.4, 'lowpass', 3500, 400); S.tone(200, 0.2, 'square', 0.15, 60); break;
      case 'near': S.noise(0.28, 0.22, 'bandpass', 700, 3800, 0, 2); S.tone(1500, 0.12, 'sine', 0.1, 2200, 0.08); break;
      case 'shield': [523, 659, 784, 1047].forEach((f, i) => S.tone(f, 0.5, 'sine', 0.15, null, i * 0.045)); S.noise(0.4, 0.08, 'highpass', 3000, 6000); break;
      case 'shieldBreak': S.noise(0.5, 0.35, 'highpass', 2500, 900); S.tone(880, 0.3, 'triangle', 0.2, 220); break;
      case 'magnet': S.tone(220, 0.18, 'sawtooth', 0.14, 330); S.tone(330, 0.18, 'sawtooth', 0.14, 220, 0.16); S.tone(440, 0.3, 'square', 0.1, 880, 0.3); break;
      case 'speed': S.noise(0.6, 0.25, 'bandpass', 400, 4000, 0, 1.5); S.tone(180, 0.6, 'sawtooth', 0.15, 720); break;
      case 'double': S.tone(784, 0.1, 'square', 0.12); S.tone(784, 0.1, 'square', 0.12, null, 0.1); S.tone(1175, 0.3, 'square', 0.14, null, 0.2); break;
      case 'multiplier': [659, 831, 988, 1319].forEach((f, i) => S.tone(f, 0.16, 'triangle', 0.16, null, i * 0.07)); break;
      case 'invincible': [392, 494, 587, 784, 988, 1175].forEach((f, i) => { S.tone(f, 0.28, 'sawtooth', 0.09, null, i * 0.06); S.tone(f * 0.5, 0.28, 'triangle', 0.12, null, i * 0.06); }); break;
      case 'dash': S.noise(0.5, 0.3, 'bandpass', 500, 5000, 0, 1); S.tone(140, 0.5, 'sawtooth', 0.18, 560); break;
      case 'board': S.tone(330, 0.12, 'triangle', 0.2, 660); S.tone(660, 0.3, 'triangle', 0.18, 990, 0.1); S.noise(0.3, 0.1, 'highpass', 2000, 5000); break;
      case 'boardBreak': S.noise(0.45, 0.4, 'lowpass', 3000, 300); S.tone(300, 0.35, 'sawtooth', 0.2, 80); break;
      case 'gameover': [392, 370, 349, 294].forEach((f, i) => { S.tone(f, 0.55, 'triangle', 0.22, f * 0.97, i * 0.24); S.tone(f / 2, 0.55, 'sine', 0.2, null, i * 0.24); }); break;
      case 'click': S.tone(720, 0.06, 'square', 0.09); S.tone(1080, 0.08, 'sine', 0.08, null, 0.03); break;
      case 'select': S.tone(523, 0.08, 'triangle', 0.16); S.tone(784, 0.16, 'triangle', 0.16, null, 0.07); break;
      case 'back': S.tone(520, 0.08, 'triangle', 0.13, 380); break;
      case 'buy': S.tone(1319, 0.08, 'square', 0.1); S.tone(1976, 0.3, 'square', 0.1, null, 0.08); S.noise(0.2, 0.06, 'highpass', 5000, 8000, 0.05); break;
      case 'error': S.tone(150, 0.25, 'sawtooth', 0.2, 100); break;
      case 'count': S.tone(660, 0.14, 'sine', 0.22); break;
      case 'go': S.tone(880, 0.35, 'sine', 0.25); S.tone(1320, 0.4, 'triangle', 0.15, null, 0.02); break;
      case 'reward': [523, 659, 784, 1047, 1319].forEach((f, i) => { S.tone(f, 0.3, 'triangle', 0.18, null, i * 0.08); S.tone(f * 2, 0.3, 'sine', 0.05, null, i * 0.08); }); break;
      case 'horn': S.tone(311, 0.7, 'sawtooth', 0.14); S.tone(392, 0.7, 'sawtooth', 0.14); break;
      default: break;
    }
  }
}
