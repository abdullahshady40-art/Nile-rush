import * as M from '../core/mat4.js';
import { getBoard } from './CharacterData.js';

const S = 0.85;                 // overall character scale (~1.76 m tall)
const HIP = 0.9;                // pelvis height before scaling
const rad = Math.PI / 180;

/**
 * Procedural low-poly runner. Poses are computed from a small state description, so the same code
 * animates Idle / Run / Jump / Fall / Slide / Hit / Boost / Death. If a GLB is available for the
 * character (see assets/models/README.md) it is drawn instead, animated by whole-body transforms.
 */
export class CharacterView {
  constructor(renderer) {
    this.r = renderer; this.g = renderer.geo;
    this.mRoot = M.create(); this.mTorso = M.create(); this.mHead = M.create(); this.mA = M.create(); this.mB = M.create(); this.mC = M.create(); this.tmp = M.create();
    this.col = [0, 0, 0]; this.pose = { pitch: 0, roll: 0, yaw: 0, rootY: 0, aL: 0, aR: 0, aLz: 0, aRz: 0, eL: 0, eR: 0, hL: 0, hR: 0, kL: 0, kR: 0, head: 0, torsoTw: 0 };
    this.models = new Map(); // characterId -> loaded GLB model
  }

  /** Fills this.pose for an animation state. st: {anim, phi, t, hitT, deadT, slideT, speed01} */
  computePose(st) {
    const p = this.pose, phi = st.phi, t = st.t;
    for (const k in p) p[k] = 0;
    switch (st.anim) {
      case 'idle': {
        const br = Math.sin(t * 2.2);
        p.rootY = br * 0.008; p.aL = -0.05 + br * 0.04; p.aR = -0.05 - br * 0.04; p.eL = 0.25; p.eR = 0.25; p.aLz = 0.08; p.aRz = -0.08;
        p.head = Math.sin(t * 0.7) * 0.25; p.pitch = 0.02; p.kL = -0.03; p.kR = -0.03;
        break;
      }
      case 'run': case 'boost': {
        const b = st.anim === 'boost';
        const amp = b ? 1.15 : 0.95;
        p.hL = Math.sin(phi) * amp; p.hR = Math.sin(phi + Math.PI) * amp;
        p.kL = -(0.12 + 0.95 * Math.max(0, Math.cos(phi))); p.kR = -(0.12 + 0.95 * Math.max(0, -Math.cos(phi)));
        p.aL = -Math.sin(phi) * (b ? 0.5 : 0.95) + (b ? -1.1 : 0); p.aR = Math.sin(phi) * (b ? 0.5 : 0.95) + (b ? -1.1 : 0);
        p.eL = b ? 0.5 : 1.15; p.eR = b ? 0.5 : 1.15;
        p.rootY = Math.abs(Math.sin(phi)) * 0.075 - 0.04; p.pitch = b ? -0.55 : -0.2 - st.speed01 * 0.08;
        p.torsoTw = Math.sin(phi) * 0.16; p.roll = Math.sin(phi) * 0.03; p.head = -p.torsoTw * 0.6;
        break;
      }
      case 'jump': {
        p.pitch = -0.12; p.aL = 2.5; p.aR = 1.9; p.eL = 0.35; p.eR = 0.5; p.hL = 0.95; p.kL = -1.25; p.hR = -0.4; p.kR = -0.55; p.rootY = 0.02;
        break;
      }
      case 'fall': {
        p.pitch = 0.02; p.aL = 0.5; p.aR = 0.5; p.aLz = 1.1; p.aRz = -1.1; p.eL = 0.3; p.eR = 0.3; p.hL = 0.3; p.hR = -0.2; p.kL = -0.35; p.kR = -0.25;
        break;
      }
      case 'slide': {
        const k = Math.min(1, st.slideT * 9);
        p.pitch = 1.32 * k; p.rootY = -0.36 * k; p.hL = 0.35; p.hR = 0.15; p.kL = -0.1; p.kR = -0.08; p.aL = -0.4; p.aR = -0.4; p.eL = 0.9; p.eR = 0.9; p.head = -0.5 * k;
        break;
      }
      case 'hit': {
        const k = Math.min(1, st.hitT * 3.2);
        p.pitch = -0.5 * k; p.aL = -1.4; p.aR = -1.2; p.eL = 0.2; p.eR = 0.2; p.hL = 0.4; p.hR = -0.3; p.kL = -0.6; p.kR = -0.4; p.head = 0.4 * k; p.rootY = -0.1 * k;
        break;
      }
      case 'death': {
        const k = Math.min(1, st.deadT * 2.6);
        p.pitch = 1.5 * k; p.rootY = -0.5 * k; p.aL = 2.2 * k; p.aR = 1.6 * k; p.aLz = 0.9 * k; p.aRz = -0.9 * k; p.hL = 0.35 * k; p.hR = -0.25 * k; p.kL = -0.5 * k; p.kR = -0.3 * k; p.head = 0.3 * k;
        break;
      }
      case 'board': {
        p.hL = 0.42; p.hR = -0.3; p.kL = -0.85; p.kR = -0.7; p.aL = -0.5; p.aR = -0.3; p.aLz = 0.75; p.aRz = -0.75; p.eL = 0.5; p.eR = 0.5;
        p.pitch = -0.2; p.rootY = -0.13 + Math.sin(t * 6) * 0.01; p.roll = Math.sin(t * 2) * 0.02;
        break;
      }
      default: break;
    }
    return p;
  }

  /** limb: cylinder hanging down from its pivot */
  _part(name, parent, ox, oy, oz, sx, sy, sz, c, em = 0, pat = 0) {
    M.translate(this.tmp, parent, ox, oy, oz); M.scale(this.tmp, this.tmp, sx, sy, sz);
    this.r.submit(this.g[name], this.tmp, c, this.alpha, em, pat, 0, this.alpha < 1 ? 1 : 0);
  }
  _joint(out, parent, ox, oy, oz, rx, ry, rz) {
    M.translate(out, parent, ox, oy, oz);
    if (ry) M.rotateY(out, out, ry); if (rz) M.rotateZ(out, out, rz); if (rx) M.rotateX(out, out, rx);
    return out;
  }

  /**
   * Draw a character. st: {x,y,z,yaw,anim,phi,t,hitT,deadT,slideT,speed01,alpha,boost}
   * def: character definition; skin: skin definition; onBoard: boolean
   */
  draw(def, skin, st) {
    const model = this.models.get(def.id);
    this.alpha = st.alpha === undefined ? 1 : st.alpha;
    const p = this.computePose(st);
    if (model) return this._drawModel(model, st, p);
    const r = this.r, g = this.g, pal = def.palette, sk = skin && skin.colors ? skin.colors : null;
    const top = sk ? sk.top : pal.top, bottom = sk ? sk.bottom : pal.bottom, accent = sk ? sk.accent : pal.accent, top2 = pal.top2, skinC = pal.skin, hair = pal.hair, shoes = pal.shoes;
    const look = def.look;
    // root: pelvis
    const root = this.mRoot;
    M.compose(root, st.x, st.y + (HIP + p.rootY) * S, st.z, 0, st.yaw || 0, p.roll + (st.roll || 0), S, S, S);
    if (p.pitch) M.rotateX(root, root, p.pitch);
    // hips
    this._part('box', root, 0, 0.02, 0, 0.44, 0.24, 0.26, bottom);
    // torso
    const torso = this._joint(this.mTorso, root, 0, 0.1, 0, 0, p.torsoTw, 0);
    this._part('box', torso, 0, 0.31, 0, 0.5, 0.62, 0.3, top);
    if (look === 'karim') { this._part('box', torso, 0, 0.36, -0.153, 0.5, 0.1, 0.02, top2); this._part('box', torso, 0, 0.2, 0.0, 0.52, 0.09, 0.32, accent); this._part('box', torso, 0, 0.3, 0.25, 0.36, 0.44, 0.18, accent); }
    else if (look === 'nour') { this._part('box', torso, 0, 0.5, 0, 0.53, 0.12, 0.33, accent); this._part('box', torso, 0, 0.05, 0, 0.52, 0.1, 0.32, top2, 0.1); this._part('cone', root, 0, -0.28, 0, 0.66, 0.5, 0.5, bottom); }
    else if (look === 'amun') { this._part('cyl', torso, 0, 0.5, 0, 0.62, 0.05, 0.42, C_GOLD, 0.25); this._part('box', torso, 0, 0.3, -0.153, 0.1, 0.5, 0.02, top2); this._part('box', root, 0, -0.12, 0, 0.5, 0.34, 0.34, bottom); this._part('box', root, 0, -0.3, -0.19, 0.2, 0.3, 0.02, C_GOLD, 0.15); }
    // head
    const head = this._joint(this.mHead, torso, 0, 0.66, 0, 0, p.head, 0);
    this._part('sphere', head, 0, 0.2, 0, 0.42, 0.44, 0.42, skinC);
    this._part('box', head, -0.085, 0.24, -0.195, 0.055, 0.07, 0.03, C_DARK); this._part('box', head, 0.085, 0.24, -0.195, 0.055, 0.07, 0.03, C_DARK);
    if (look === 'karim') {
      this._part('sphere', head, 0, 0.27, 0.02, 0.46, 0.3, 0.46, hair);
      this._part('dome', head, 0, 0.3, -0.01, 0.5, 0.5, 0.5, accent);
      this._part('box', head, 0, 0.35, -0.27, 0.36, 0.04, 0.22, accent);
    } else if (look === 'nour') {
      this._part('sphere', head, 0, 0.27, 0.03, 0.47, 0.34, 0.47, hair);
      const sway = Math.sin(st.phi * 1 + 1) * 0.25 + (st.anim === 'run' || st.anim === 'boost' ? 0.55 : 0.1);
      for (const s of [-1, 1]) {
        M.translate(this.mA, head, s * 0.16, 0.1, 0.16); M.rotateX(this.mA, this.mA, sway * (1 + s * 0.1));
        this._part('cyl', this.mA, 0, -0.26, 0, 0.09, 0.56, 0.09, hair);
        this._part('sphere', this.mA, 0, -0.55, 0, 0.13, 0.13, 0.13, accent);
      }
      // scarf tail
      const fl = Math.sin(st.t * 14) * 0.15;
      M.translate(this.mA, torso, 0, 0.55, 0.16); M.rotateX(this.mA, this.mA, 0.7 + fl);
      this._part('box', this.mA, 0, 0, 0.35, 0.16, 0.03, 0.72, accent);
    } else if (look === 'amun') {
      this._part('sphere', head, 0, 0.28, 0.02, 0.5, 0.36, 0.5, top2);
      this._part('box', head, 0, 0.12, 0.2, 0.46, 0.52, 0.16, top2, 0, 13);
      this._part('box', head, -0.235, 0.12, -0.02, 0.06, 0.46, 0.3, top2, 0, 13); this._part('box', head, 0.235, 0.12, -0.02, 0.06, 0.46, 0.3, top2, 0, 13);
      this._part('cyl', head, 0, 0.4, 0, 0.5, 0.04, C_GOLD, 0.3);
      this._part('sphere', head, 0, 0.42, -0.24, 0.06, 0.06, 0.06, C_GOLD, 0.6);
      this._part('box', head, 0, 0.24, -0.205, 0.3, 0.025, 0.02, C_DARK);
    }
    // arms
    for (let s = -1; s <= 1; s += 2) {
      const L = s < 0, ax = L ? p.aL : p.aR, az = (L ? p.aLz : p.aRz), ex = L ? p.eL : p.eR;
      const sh = this._joint(this.mA, torso, s * 0.33, 0.56, 0, ax, 0, az);
      const sleeve = look === 'nour' ? skinC : top;
      this._part('cyl', sh, 0, -0.15, 0, 0.13, 0.32, 0.13, look === 'amun' ? skinC : sleeve);
      const el = this._joint(this.mB, sh, 0, -0.3, 0, ex, 0, 0);
      this._part('cyl', el, 0, -0.14, 0, 0.11, 0.3, 0.11, skinC);
      this._part('sphere', el, 0, -0.3, 0, 0.14, 0.14, 0.14, skinC);
      if (look === 'nour' || look === 'amun') this._part('cyl', el, 0, -0.24, 0, 0.14, 0.05, 0.14, C_GOLD, 0.25);
    }
    // legs
    for (let s = -1; s <= 1; s += 2) {
      const L = s < 0, hx = L ? p.hL : p.hR, kx = L ? p.kL : p.kR;
      const hip = this._joint(this.mA, root, s * 0.12, -0.02, 0, hx, 0, 0);
      this._part('cyl', hip, 0, -0.21, 0, 0.17, 0.44, 0.17, look === 'amun' ? skinC : bottom);
      const kn = this._joint(this.mB, hip, 0, -0.42, 0, kx, 0, 0);
      this._part('cyl', kn, 0, -0.2, 0, 0.14, 0.42, 0.14, look === 'amun' ? skinC : bottom);
      this._part('box', kn, 0, -0.43, -0.06, 0.15, 0.09, 0.3, shoes);
      if (look === 'karim') this._part('box', kn, 0, -0.42, -0.06, 0.155, 0.03, 0.3, accent);
    }
    return true;
  }

  _drawModel(model, st, p) {
    const r = this.r, root = this.mRoot;
    const sc = model.scale || 1;
    M.compose(root, st.x, st.y + (p.rootY || 0), st.z, 0, (st.yaw || 0) + Math.PI + (model.rotY || 0), p.roll, sc, sc, sc);
    if (p.pitch) M.rotateX(root, root, -p.pitch * 0.7);
    if (st.anim === 'run' || st.anim === 'boost') M.translate(root, root, 0, Math.abs(Math.sin(st.phi)) * 0.06 / sc, 0);
    for (const part of model.parts) {
      M.multiply(this.tmp, root, part.matrix);
      r.submit(part.geo, this.tmp, part.color, this.alpha, 0, 0, 0, this.alpha < 1 ? 1 : 0);
    }
  }
}
const C_GOLD = [0.96, 0.72, 0.2], C_DARK = [0.06, 0.05, 0.05];

// -------------------------------------------------------------------- Nile Board model
export function drawBoard(r, board, x, y, z, yaw, t, alpha = 1) {
  const g = r.geo, pass = alpha < 1 ? 1 : 0;
  const cs = Math.cos(yaw), sn = Math.sin(yaw), P = (lx, lz) => [x + lx * cs + lz * sn, z - lx * sn + lz * cs];
  const bob = Math.sin(t * 5) * 0.03;
  let p = P(0, 0);
  r.submitTRS(g.box, p[0], y + bob, p[1], 0, yaw, 0, 0.78, 0.09, 1.9, board.hull, alpha, 0, 0, 0, pass);
  p = P(0, -1.05); r.submitTRS(g.box, p[0], y + 0.06 + bob, p[1], 0.35, yaw, 0, 0.62, 0.08, 0.5, board.hull, alpha, 0, 0, 0, pass);
  p = P(0, 0.95); r.submitTRS(g.box, p[0], y + 0.1 + bob, p[1], -0.25, yaw, 0, 0.6, 0.07, 0.4, board.hull, alpha, 0, 0, 0, pass);
  // sail
  p = P(0, 0.15); r.submitTRS(g.prism, p[0], y + 0.85 + bob, p[1], 0, yaw + Math.PI / 2, Math.sin(t * 6) * 0.04, 1.5, 1.4, 0.03, board.color, alpha, 0.1, 0, 0, pass);
  p = P(0, 0.15); r.submitTRS(g.cyl, p[0], y + 0.6 + bob, p[1], 0, yaw, 0, 0.04, 1.2, 0.04, board.hull, alpha, 0, 0, 0, pass);
  // glow underneath
  p = P(0, 0); r.submitTRS(g.sphere, p[0], y - 0.1 + bob, p[1], 0, yaw, 0, 1.1, 0.28, 2.3, board.trail, 0.4 * alpha, 0, 10, 0, 2);
  r.submitTRS(g.sphere, p[0], y - 0.1 + bob, p[1], 0, yaw, 0, 1.0, 0.2, 2.1, board.trail, 0.42 * alpha, 1, 10, 0, 2);
}
export { getBoard };
