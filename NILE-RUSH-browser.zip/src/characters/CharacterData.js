import { hex } from '../core/Utils.js';

// -------------------------------------------------------------------- characters
// stats (1-5) are what the player sees; fx are the real gameplay modifiers.
export const CHARACTERS = [
  {
    id: 'karim', name: 'Karim', title: 'Cairo Courier', look: 'karim',
    desc: 'Grew up dodging Cairo traffic on a delivery bike. Balanced and reliable.',
    stats: { speed: 3, jump: 3, magnet: 3, score: 3 },
    fx: { speed: 1, jump: 1, magnet: 0, magnetTime: 0, score: 1 },
    unlock: { type: 'free' },
    palette: { skin: hex('#b07a52'), hair: hex('#1a1412'), top: hex('#f0a12e'), top2: hex('#ffffff'), bottom: hex('#22304f'), shoes: hex('#f2f2ee'), accent: hex('#19b5a5') },
  },
  {
    id: 'nour', name: 'Nour', title: 'Nubian Dancer', look: 'nour',
    desc: 'Light on her feet with a gift for finding coins. Highest jumper in the delta.',
    stats: { speed: 2, jump: 5, magnet: 4, score: 2 },
    fx: { speed: 0.97, jump: 1.12, magnet: 1.6, magnetTime: 2, score: 1 },
    unlock: { type: 'coins', cost: 600 },
    palette: { skin: hex('#7d4b31'), hair: hex('#120c0a'), top: hex('#1fb5aa'), top2: hex('#f2b84b'), bottom: hex('#c2458f'), shoes: hex('#f2b84b'), accent: hex('#ff7a3d') },
  },
  {
    id: 'amun', name: 'Amun', title: 'Nile Guardian', look: 'amun',
    desc: 'A guardian in royal gold. Fastest runner and the best score multiplier.',
    stats: { speed: 5, jump: 3, magnet: 2, score: 5 },
    fx: { speed: 1.06, jump: 1, magnet: 0, magnetTime: 0, score: 1.2 },
    unlock: { type: 'distance', value: 2500 },
    palette: { skin: hex('#a86f43'), hair: hex('#0d0d10'), top: hex('#f2b84b'), top2: hex('#1c3f9e'), bottom: hex('#f4efe2'), shoes: hex('#d6a23a'), accent: hex('#1c3f9e') },
  },
];
export const getCharacter = (id) => CHARACTERS.find((c) => c.id === id) || CHARACTERS[0];

// -------------------------------------------------------------------- skins (outfit colours, any character)
export const SKINS = [
  { id: 'classic', name: 'Original', price: 0, desc: 'Each runner\'s own outfit.', preview: '#f0a12e' },
  { id: 'lapis', name: 'Lapis Blue', price: 250, desc: 'Deep lapis lazuli blue with gold trim.', preview: '#1c3f9e', colors: { top: hex('#1c3f9e'), bottom: hex('#0e1d4a'), accent: hex('#f2b84b') } },
  { id: 'copper', name: 'Sunset Copper', price: 250, desc: 'Warm copper tones of the evening Nile.', preview: '#c8622d', colors: { top: hex('#c8622d'), bottom: hex('#5b2a1e'), accent: hex('#ffd27a') } },
  { id: 'papyrus', name: 'Papyrus Green', price: 300, desc: 'Fresh green of the riverbank reeds.', preview: '#3f9a4d', colors: { top: hex('#3f9a4d'), bottom: hex('#f0e6c8'), accent: hex('#f2b84b') } },
  { id: 'gold', name: 'Pharaoh Gold', price: 700, desc: 'Head-to-toe royal gold.', preview: '#f7c948', colors: { top: hex('#f7c948'), bottom: hex('#c99a2e'), accent: hex('#1fb5aa') } },
];
export const getSkin = (id) => SKINS.find((s) => s.id === id) || SKINS[0];

// -------------------------------------------------------------------- Nile Boards
export const BOARDS = [
  { id: 'felucca', name: 'Felucca', price: 0, duration: 22, hits: 1, glide: 1, coinBonus: 1, magnet: false, color: hex('#f5f0e0'), hull: hex('#7a4a2a'), trail: [0.4, 0.85, 1], desc: 'A tiny sailing boat that floats above the road. Absorbs 1 crash.' },
  { id: 'papyrus', name: 'Papyrus Glider', price: 350, duration: 26, hits: 1, glide: 0.62, coinBonus: 1, magnet: false, color: hex('#7ac25a'), hull: hex('#d8c27a'), trail: [0.5, 1, 0.5], desc: 'Reed board with floaty jumps — stay in the air longer. Absorbs 1 crash.' },
  { id: 'lotus', name: 'Lotus Surf', price: 600, duration: 26, hits: 1, glide: 1, coinBonus: 1.25, magnet: false, color: hex('#ff8fb8'), hull: hex('#fff2f8'), trail: [1, 0.55, 0.75], desc: 'Every coin is worth 25% more while riding. Absorbs 1 crash.' },
  { id: 'barge', name: 'Solar Barge', price: 1200, duration: 30, hits: 2, glide: 0.85, coinBonus: 1, magnet: true, color: hex('#f2b84b'), hull: hex('#b8862a'), trail: [1, 0.8, 0.3], desc: 'Ra\'s golden barge: built-in magnet and absorbs 2 crashes.' },
];
export const getBoard = (id) => BOARDS.find((b) => b.id === id) || BOARDS[0];

// -------------------------------------------------------------------- cosmetics (run trails)
export const TRAILS = [
  { id: 'sand', name: 'Desert Dust', price: 0, desc: 'Classic kicked-up sand.', c: [0.86, 0.72, 0.5], add: 0, shape: 0, preview: '#d9b878' },
  { id: 'lotus', name: 'Lotus Petals', price: 220, desc: 'Pink petals follow your steps.', c: [1, 0.55, 0.72], add: 0, shape: 2, preview: '#ff8db8' },
  { id: 'sun', name: 'Sun Sparks', price: 300, desc: 'Golden sparks of Ra.', c: [1, 0.78, 0.25], add: 1, shape: 1, preview: '#ffc840' },
  { id: 'nile', name: 'Nile Spray', price: 300, desc: 'Turquoise river droplets.', c: [0.3, 0.9, 0.95], add: 1, shape: 0, preview: '#4de6f2' },
];
export const getTrail = (id) => TRAILS.find((t) => t.id === id) || TRAILS[0];

// -------------------------------------------------------------------- consumable boosts
export const BOOSTS = [
  { id: 'boardCharge', name: 'Board Charge', price: 60, desc: 'One activation of your Nile Board during a run.', unit: 'charge' },
  { id: 'headStart', name: 'Head Start', price: 120, desc: 'Launch the run with an 8-second invincible sprint.', unit: 'use' },
  { id: 'scoreBooster', name: 'Score Booster', price: 150, desc: 'Start the run with x2 score for 45 seconds.', unit: 'use' },
];

// -------------------------------------------------------------------- power-up duration upgrades
export const POWERUPS = {
  magnet:     { id: 'magnet',     name: 'Magnet',        base: 9,  step: 1.5, color: [0.95, 0.3, 0.35], desc: 'Pulls nearby coins to you.' },
  shield:     { id: 'shield',     name: 'Shield',        base: 14, step: 2,   color: [0.35, 0.8, 1],    desc: 'Absorbs one crash.' },
  speed:      { id: 'speed',      name: 'Speed Boost',   base: 6,  step: 1,   color: [1, 0.6, 0.15],    desc: 'Run 30% faster.' },
  double:     { id: 'double',     name: 'Double Score',  base: 12, step: 2,   color: [0.95, 0.85, 0.2], desc: 'Doubles all points.' },
  multiplier: { id: 'multiplier', name: 'Coin x2',       base: 12, step: 2,   color: [0.4, 0.95, 0.5],  desc: 'Every coin counts double.' },
  invincible: { id: 'invincible', name: 'Invincibility', base: 6,  step: 0.5, color: [1, 0.85, 0.4],    desc: 'Smash through everything.' },
};
export const UPGRADEABLE = ['magnet', 'shield', 'speed', 'double', 'multiplier'];
export const MAX_UPGRADE = 4;
export const upgradeCost = (lvl) => 150 * (lvl + 1) * (lvl + 1);
