// Persistent player data. localStorage first, in-memory fallback (private mode / blocked storage).
const KEY = 'nilerush.save.v1';

export const defaults = () => ({
  v: 1,
  coins: 0, highScore: 0, bestDistance: 0,
  selectedChar: 'karim', unlockedChars: ['karim'],
  selectedBoard: 'felucca', ownedBoards: ['felucca'],
  selectedSkin: 'classic', ownedSkins: ['classic'],
  selectedTrail: 'sand', ownedTrails: ['sand'],
  inventory: { boardCharge: 3, headStart: 0, scoreBooster: 0 },
  upgrades: { magnet: 0, shield: 0, speed: 0, double: 0, multiplier: 0 },
  missions: { slots: [], tiers: {}, completed: 0 },
  achievements: {},
  stats: { runs: 0, distance: 0, coins: 0, jumps: 0, slides: 0, nearMisses: 0, magnet: 0, shield: 0, speed: 0, double: 0, multiplier: 0, invincible: 0, totalScore: 0, bestCombo: 0, boardRides: 0, smashed: 0, purchases: 0, playSeconds: 0 },
  settings: { music: 0.7, sfx: 0.9, mute: false, quality: 'auto', time: 'auto', shake: true, vibration: true, touchButtons: false },
  tutorialDone: false, introSeen: false,
});

function merge(base, over) {
  if (over === null || typeof over !== 'object' || Array.isArray(base) || typeof base !== 'object') return over === undefined ? base : over;
  const out = { ...base };
  for (const k of Object.keys(over)) out[k] = k in base ? merge(base[k], over[k]) : over[k];
  return out;
}

export class SaveManager {
  constructor() { this.data = defaults(); this.mem = null; this.timer = 0; this.loaded = false; this.load(); }
  _read() { try { return window.localStorage.getItem(KEY); } catch (e) { return this.mem; } }
  _write(s) { try { window.localStorage.setItem(KEY, s); } catch (e) { this.mem = s; } }
  load() {
    try { const raw = this._read(); if (raw) this.data = merge(defaults(), JSON.parse(raw)); } catch (e) { console.warn('Save data unreadable, starting fresh', e); this.data = defaults(); }
    this.loaded = true;
  }
  save() { clearTimeout(this.timer); this.timer = 0; this._write(JSON.stringify(this.data)); }
  saveSoon() { if (this.timer) return; this.timer = setTimeout(() => this.save(), 1500); }
  reset() { this.data = defaults(); this.save(); }
  addCoins(n) { this.data.coins = Math.max(0, this.data.coins + n); this.saveSoon(); }
  spend(n) { if (this.data.coins < n) return false; this.data.coins -= n; this.save(); return true; }
}
