import { EventBus } from '../core/EventBus.js';

/**
 * Keyboard + pointer (touch / mouse) input. Emits: left, right, jump, slide, dash, board, pause, back.
 * Swipes fire as soon as the finger travels far enough, so lane changes feel instant.
 */
export class InputManager extends EventBus {
  constructor() {
    super();
    this.gameplay = false; this.layer = null; this.sx = 0; this.sy = 0; this.pid = -1; this.lastTap = 0; this.fired = false;
    window.addEventListener('keydown', (e) => this._key(e));
  }
  setGameplay(on) { this.gameplay = on; }
  attach(layer) {
    this.layer = layer;
    layer.addEventListener('pointerdown', (e) => this._down(e));
    layer.addEventListener('pointermove', (e) => this._move(e));
    layer.addEventListener('pointerup', (e) => this._up(e));
    layer.addEventListener('pointercancel', () => { this.pid = -1; });
    layer.addEventListener('contextmenu', (e) => e.preventDefault());
  }
  _key(e) {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const k = e.code;
    if (k === 'Escape' || k === 'KeyP') { if (!e.repeat) this.emit('pause'); return; }
    if (!this.gameplay) return;
    let h = true;
    switch (k) {
      case 'ArrowLeft': case 'KeyA': this.emit('left'); break;
      case 'ArrowRight': case 'KeyD': this.emit('right'); break;
      case 'ArrowUp': case 'KeyW': case 'Space': this.emit('jump'); break;
      case 'ArrowDown': case 'KeyS': this.emit('slide'); break;
      case 'ShiftLeft': case 'ShiftRight': case 'KeyE': if (!e.repeat) this.emit('dash'); break;
      case 'KeyB': if (!e.repeat) this.emit('board'); break;
      default: h = false;
    }
    if (h) e.preventDefault();
  }
  _down(e) {
    if (!this.gameplay) return;
    this.pid = e.pointerId; this.sx = e.clientX; this.sy = e.clientY; this.fired = false;
    try { this.layer.setPointerCapture(e.pointerId); } catch (err) { /* ignore */ }
  }
  _move(e) {
    if (!this.gameplay || e.pointerId !== this.pid) return;
    const dx = e.clientX - this.sx, dy = e.clientY - this.sy, th = Math.max(26, Math.min(46, Math.min(innerWidth, innerHeight) * 0.07));
    if (Math.abs(dx) < th && Math.abs(dy) < th) return;
    if (Math.abs(dx) > Math.abs(dy)) this.emit(dx < 0 ? 'left' : 'right'); else this.emit(dy < 0 ? 'jump' : 'slide');
    this.sx = e.clientX; this.sy = e.clientY; this.fired = true;
  }
  _up(e) {
    if (e.pointerId !== this.pid) return; this.pid = -1;
    if (this.gameplay && !this.fired) { // double tap = dash
      const now = performance.now();
      if (now - this.lastTap < 320) { this.emit('dash'); this.lastTap = 0; } else this.lastTap = now;
    }
  }
}
