export const ACHIEVEMENTS = [
  { id: 'first',       name: 'First Run',       desc: 'Finish your first run.',                     reward: 50,  test: (s) => s.runs >= 1 },
  { id: 'km',          name: '1000 Meters',     desc: 'Run 1,000 m in a single run.',               reward: 100, test: (s, r) => r.dist >= 1000 },
  { id: 'collector',   name: 'Coin Collector',  desc: 'Collect 500 coins in total.',                reward: 100, test: (s) => s.coins >= 500 },
  { id: 'speed',       name: 'Speed Demon',     desc: 'Reach a running speed of 30.',               reward: 150, test: (s, r) => r.topSpeed >= 30 },
  { id: 'survivor',    name: 'Survivor',        desc: 'Survive for 3 minutes in one run.',          reward: 200, test: (s, r) => r.time >= 180 },
  { id: 'perfect',     name: 'Perfect Run',     desc: 'Reach a x5 combo.',                          reward: 200, test: (s, r) => r.maxCombo >= 5 },
  { id: 'millionaire', name: 'Millionaire',     desc: 'Earn 1,000,000 points in total.',            reward: 500, test: (s) => s.totalScore >= 1000000 },
  { id: 'daredevil',   name: 'Daredevil',       desc: 'Make 50 near misses in total.',              reward: 150, test: (s) => s.nearMisses >= 50 },
  { id: 'rider',       name: 'Nile Rider',      desc: 'Ride your Nile Board 5 times.',              reward: 120, test: (s) => s.boardRides >= 5 },
  { id: 'explorer',    name: 'Nile Explorer',   desc: 'Run through all 7 environments (4,928 m).',  reward: 300, test: (s, r) => r.dist >= 4928 },
];

export class Achievements {
  constructor(save, onUnlock) { this.save = save; this.onUnlock = onUnlock; }
  isUnlocked(id) { return !!this.save.data.achievements[id]; }
  count() { return Object.keys(this.save.data.achievements).length; }
  /** stats: lifetime stats; run: {dist, topSpeed, time, maxCombo} */
  check(run) {
    const s = this.save.data.stats;
    for (const a of ACHIEVEMENTS) {
      if (this.save.data.achievements[a.id]) continue;
      if (a.test(s, run)) {
        this.save.data.achievements[a.id] = Date.now(); this.save.data.coins += a.reward; this.save.saveSoon();
        this.onUnlock && this.onUnlock(a);
      }
    }
  }
}
