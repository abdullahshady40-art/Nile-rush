// Mission system: 6 active slots, progress is counted from the moment a mission is assigned.
const T = [
  { id: 'coins',    stat: 'coins',      title: (n) => `Collect ${n.toLocaleString()} coins`,       targets: [100, 250, 500, 1000, 2000], rewards: [60, 120, 200, 320, 500] },
  { id: 'distance', stat: 'distance',   title: (n) => `Run ${n.toLocaleString()} meters`,           targets: [1000, 2500, 5000, 10000, 20000], rewards: [80, 150, 260, 420, 650] },
  { id: 'magnet',   stat: 'magnet',     title: (n) => `Use Magnet ${n} times`,                       targets: [5, 10, 20, 35, 60], rewards: [60, 110, 200, 320, 480] },
  { id: 'jumps',    stat: 'jumps',      title: (n) => `Jump over ${n} obstacles`,                    targets: [20, 50, 100, 200, 400], rewards: [70, 120, 220, 340, 520] },
  { id: 'near',     stat: 'nearMisses', title: (n) => `Make ${n} near misses`,                       targets: [10, 25, 50, 100, 200], rewards: [80, 140, 240, 380, 560] },
  { id: 'runs',     stat: 'runs',       title: (n) => `Play ${n} runs`,                              targets: [3, 6, 10, 20, 40], rewards: [50, 100, 180, 300, 480] },
  { id: 'shield',   stat: 'shield',     title: (n) => `Use Shield ${n} times`,                       targets: [3, 8, 15, 30, 50], rewards: [60, 110, 200, 320, 480] },
  { id: 'slides',   stat: 'slides',     title: (n) => `Slide under ${n} obstacles`,                  targets: [10, 30, 60, 120, 240], rewards: [70, 120, 220, 340, 520] },
  { id: 'board',    stat: 'boardRides', title: (n) => `Ride your Nile Board ${n} times`,             targets: [2, 5, 10, 20, 35], rewards: [70, 120, 220, 340, 520] },
  { id: 'score',    stat: 'runScore',   max: true, title: (n) => `Score ${n.toLocaleString()} in a single run`, targets: [5000, 15000, 40000, 100000, 250000], rewards: [80, 160, 280, 450, 700] },
  { id: 'combo',    stat: 'runCombo',   max: true, title: (n) => `Reach a x${n} combo in one run`, targets: [2, 3, 4, 5, 5], rewards: [60, 120, 200, 320, 480] },
];
const INITIAL = ['coins', 'distance', 'magnet', 'jumps', 'near', 'runs'];
const SLOTS = 6;

export class Missions {
  constructor(save, hooks = {}) { this.save = save; this.hooks = hooks; this.ensure(); }
  get slots() { return this.save.data.missions.slots; }
  tpl(id) { return T.find((t) => t.id === id); }

  _make(id, tier) {
    const t = this.tpl(id), i = Math.min(tier, t.targets.length - 1);
    return { id, tier: i, target: t.targets[i], reward: t.rewards[i], progress: 0, claimed: false };
  }
  ensure() {
    const m = this.save.data.missions;
    m.slots = (m.slots || []).filter((s) => this.tpl(s.id));
    let idx = 0;
    while (m.slots.length < SLOTS) {
      const used = m.slots.map((s) => s.id);
      const id = idx < INITIAL.length && !used.includes(INITIAL[idx]) ? INITIAL[idx] : (T.map((t) => t.id).find((x) => !used.includes(x)) || T[0].id);
      m.slots.push(this._make(id, (m.tiers[id] || 0))); idx++;
    }
  }
  title(slot) { return this.tpl(slot.id).title(slot.target); }
  done(slot) { return slot.progress >= slot.target; }

  /** additive stat (coins, jumps, ...) */
  add(stat, n = 1) {
    let changed = false;
    for (const s of this.slots) {
      const t = this.tpl(s.id); if (t.stat !== stat || t.max || s.claimed || this.done(s)) continue;
      s.progress = Math.min(s.target, s.progress + n); changed = true;
      if (this.done(s) && this.hooks.onComplete) this.hooks.onComplete(s, this.title(s));
    }
    if (changed) this.save.saveSoon();
  }
  /** "best in one run" stat (runScore, runCombo) */
  max(stat, value) {
    for (const s of this.slots) {
      const t = this.tpl(s.id); if (t.stat !== stat || !t.max || s.claimed || this.done(s)) continue;
      if (value > s.progress) { s.progress = Math.min(s.target, value); if (this.done(s) && this.hooks.onComplete) this.hooks.onComplete(s, this.title(s)); this.save.saveSoon(); }
    }
  }
  claim(i) {
    const s = this.slots[i]; if (!s || !this.done(s) || s.claimed) return 0;
    s.claimed = true; const reward = s.reward;
    this.save.data.coins += reward; this.save.data.missions.completed++;
    const m = this.save.data.missions; m.tiers[s.id] = Math.min(4, s.tier + 1);
    // replace with the next tier of the same mission, or a fresh mission type
    const used = this.slots.map((x) => x.id);
    const nextId = s.tier < 4 ? s.id : (T.map((t) => t.id).find((x) => !used.includes(x)) || s.id);
    this.slots[i] = this._make(nextId, nextId === s.id ? s.tier + 1 : (m.tiers[nextId] || 0));
    this.save.save(); return reward;
  }
  claimable() { return this.slots.filter((s) => this.done(s) && !s.claimed).length; }
}
