// Central tuning values for NILE RUSH. Everything gameplay-related lives here.
export const CFG = {
  version: '1.0.0',
  laneWidth: 2.4,
  baseSpeed: 15,
  maxSpeed: 33,
  speedRamp: 1700,          // metres: bigger = slower ramp
  gravity: 38,
  jumpVel: 13.2,
  slideTime: 0.78,
  laneSpeed: 15,            // lateral smoothing
  playerHalfW: 0.32,
  playerHalfD: 0.32,
  playerH: 1.7,
  slideH: 0.8,
  segLen: 32,
  envLen: 704,              // metres per environment
  envBlend: 160,
  spawnAhead: 175,
  despawnBehind: 12,
  comboWindow: 2.0,
  comboStep: 8,
  dashTime: 1.6,
  dashCost: 100,
  dashPerCoin: 3.5,
  dashPerNear: 12,
  nearMissGap: 0.5,
  powerupSpawnEvery: [260, 420],
};

export const QUALITY = {
  low:    { label: 'Low',    dprCap: 1,   scale: 0.8, decor: 0.5, view: 130, particles: 260,  shadows: 1, speedLines: 0, ambient: 0.3 },
  medium: { label: 'Medium', dprCap: 1.5, scale: 1,   decor: 0.8, view: 170, particles: 650,  shadows: 2, speedLines: 1, ambient: 0.7 },
  high:   { label: 'High',   dprCap: 2,   scale: 1,   decor: 1,   view: 210, particles: 1300, shadows: 2, speedLines: 1, ambient: 1 },
};

export function pickDefaultQuality() {
  const mem = navigator.deviceMemory || 4;
  const cores = navigator.hardwareConcurrency || 4;
  const coarse = typeof matchMedia === 'function' && matchMedia('(pointer:coarse)').matches;
  if (mem <= 2 || cores <= 3) return 'low';
  if (coarse || mem <= 4 || cores <= 6) return 'medium';
  return 'high';
}
