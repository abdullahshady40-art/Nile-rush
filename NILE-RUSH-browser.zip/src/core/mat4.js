// NileForge Engine — minimal column-major 4x4 matrix helpers (Float32Array(16)).
export const create = () => { const m = new Float32Array(16); m[0] = m[5] = m[10] = m[15] = 1; return m; };
export function identity(o) { o.fill(0); o[0] = o[5] = o[10] = o[15] = 1; return o; }
export function copy(o, a) { o.set(a); return o; }

export function multiply(o, a, b) {
  const a00 = a[0], a01 = a[1], a02 = a[2], a03 = a[3];
  const a10 = a[4], a11 = a[5], a12 = a[6], a13 = a[7];
  const a20 = a[8], a21 = a[9], a22 = a[10], a23 = a[11];
  const a30 = a[12], a31 = a[13], a32 = a[14], a33 = a[15];
  let b0 = b[0], b1 = b[1], b2 = b[2], b3 = b[3];
  o[0] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
  o[1] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
  o[2] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
  o[3] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
  b0 = b[4]; b1 = b[5]; b2 = b[6]; b3 = b[7];
  o[4] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
  o[5] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
  o[6] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
  o[7] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
  b0 = b[8]; b1 = b[9]; b2 = b[10]; b3 = b[11];
  o[8] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
  o[9] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
  o[10] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
  o[11] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
  b0 = b[12]; b1 = b[13]; b2 = b[14]; b3 = b[15];
  o[12] = b0 * a00 + b1 * a10 + b2 * a20 + b3 * a30;
  o[13] = b0 * a01 + b1 * a11 + b2 * a21 + b3 * a31;
  o[14] = b0 * a02 + b1 * a12 + b2 * a22 + b3 * a32;
  o[15] = b0 * a03 + b1 * a13 + b2 * a23 + b3 * a33;
  return o;
}

export function translate(o, m, x, y, z) {
  const m0 = m[0], m1 = m[1], m2 = m[2], m3 = m[3], m4 = m[4], m5 = m[5], m6 = m[6], m7 = m[7];
  const m8 = m[8], m9 = m[9], m10 = m[10], m11 = m[11], m12 = m[12], m13 = m[13], m14 = m[14], m15 = m[15];
  if (o !== m) { o[0] = m0; o[1] = m1; o[2] = m2; o[3] = m3; o[4] = m4; o[5] = m5; o[6] = m6; o[7] = m7; o[8] = m8; o[9] = m9; o[10] = m10; o[11] = m11; }
  o[12] = m0 * x + m4 * y + m8 * z + m12;
  o[13] = m1 * x + m5 * y + m9 * z + m13;
  o[14] = m2 * x + m6 * y + m10 * z + m14;
  o[15] = m3 * x + m7 * y + m11 * z + m15;
  return o;
}

export function rotateX(o, m, a) {
  const s = Math.sin(a), c = Math.cos(a);
  const a10 = m[4], a11 = m[5], a12 = m[6], a13 = m[7], a20 = m[8], a21 = m[9], a22 = m[10], a23 = m[11];
  if (o !== m) { o[0] = m[0]; o[1] = m[1]; o[2] = m[2]; o[3] = m[3]; o[12] = m[12]; o[13] = m[13]; o[14] = m[14]; o[15] = m[15]; }
  o[4] = a10 * c + a20 * s; o[5] = a11 * c + a21 * s; o[6] = a12 * c + a22 * s; o[7] = a13 * c + a23 * s;
  o[8] = a20 * c - a10 * s; o[9] = a21 * c - a11 * s; o[10] = a22 * c - a12 * s; o[11] = a23 * c - a13 * s;
  return o;
}
export function rotateY(o, m, a) {
  const s = Math.sin(a), c = Math.cos(a);
  const a00 = m[0], a01 = m[1], a02 = m[2], a03 = m[3], a20 = m[8], a21 = m[9], a22 = m[10], a23 = m[11];
  if (o !== m) { o[4] = m[4]; o[5] = m[5]; o[6] = m[6]; o[7] = m[7]; o[12] = m[12]; o[13] = m[13]; o[14] = m[14]; o[15] = m[15]; }
  o[0] = a00 * c - a20 * s; o[1] = a01 * c - a21 * s; o[2] = a02 * c - a22 * s; o[3] = a03 * c - a23 * s;
  o[8] = a00 * s + a20 * c; o[9] = a01 * s + a21 * c; o[10] = a02 * s + a22 * c; o[11] = a03 * s + a23 * c;
  return o;
}
export function rotateZ(o, m, a) {
  const s = Math.sin(a), c = Math.cos(a);
  const a00 = m[0], a01 = m[1], a02 = m[2], a03 = m[3], a10 = m[4], a11 = m[5], a12 = m[6], a13 = m[7];
  if (o !== m) { o[8] = m[8]; o[9] = m[9]; o[10] = m[10]; o[11] = m[11]; o[12] = m[12]; o[13] = m[13]; o[14] = m[14]; o[15] = m[15]; }
  o[0] = a00 * c + a10 * s; o[1] = a01 * c + a11 * s; o[2] = a02 * c + a12 * s; o[3] = a03 * c + a13 * s;
  o[4] = a10 * c - a00 * s; o[5] = a11 * c - a01 * s; o[6] = a12 * c - a02 * s; o[7] = a13 * c - a03 * s;
  return o;
}
export function scale(o, m, x, y, z) {
  o[0] = m[0] * x; o[1] = m[1] * x; o[2] = m[2] * x; o[3] = m[3] * x;
  o[4] = m[4] * y; o[5] = m[5] * y; o[6] = m[6] * y; o[7] = m[7] * y;
  o[8] = m[8] * z; o[9] = m[9] * z; o[10] = m[10] * z; o[11] = m[11] * z;
  o[12] = m[12]; o[13] = m[13]; o[14] = m[14]; o[15] = m[15];
  return o;
}

/** o = T(x,y,z) * Ry * Rx * Rz * S */
export function compose(o, x, y, z, rx, ry, rz, sx, sy, sz) {
  identity(o);
  o[12] = x; o[13] = y; o[14] = z;
  if (ry) rotateY(o, o, ry);
  if (rx) rotateX(o, o, rx);
  if (rz) rotateZ(o, o, rz);
  if (sx !== 1 || sy !== 1 || sz !== 1) scale(o, o, sx, sy, sz);
  return o;
}

export function perspective(o, fovy, aspect, near, far, sx = 0, sy = 0) {
  const f = 1 / Math.tan(fovy / 2), nf = 1 / (near - far);
  o.fill(0);
  o[0] = f / aspect; o[5] = f; o[8] = -sx; o[9] = -sy;
  o[10] = (far + near) * nf; o[11] = -1; o[14] = 2 * far * near * nf;
  return o;
}

export function lookAt(o, ex, ey, ez, tx, ty, tz, ux, uy, uz) {
  let zx = ex - tx, zy = ey - ty, zz = ez - tz;
  let l = Math.hypot(zx, zy, zz) || 1; zx /= l; zy /= l; zz /= l;
  let xx = uy * zz - uz * zy, xy = uz * zx - ux * zz, xz = ux * zy - uy * zx;
  l = Math.hypot(xx, xy, xz) || 1; xx /= l; xy /= l; xz /= l;
  const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
  o[0] = xx; o[1] = yx; o[2] = zx; o[3] = 0;
  o[4] = xy; o[5] = yy; o[6] = zy; o[7] = 0;
  o[8] = xz; o[9] = yz; o[10] = zz; o[11] = 0;
  o[12] = -(xx * ex + xy * ey + xz * ez);
  o[13] = -(yx * ex + yy * ey + yz * ez);
  o[14] = -(zx * ex + zy * ey + zz * ez);
  o[15] = 1;
  return o;
}
