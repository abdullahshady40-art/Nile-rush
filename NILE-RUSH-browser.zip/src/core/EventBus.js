export class EventBus {
  constructor() { this.map = new Map(); }
  on(evt, fn) { let a = this.map.get(evt); if (!a) this.map.set(evt, (a = [])); a.push(fn); return () => this.off(evt, fn); }
  off(evt, fn) { const a = this.map.get(evt); if (!a) return; const i = a.indexOf(fn); if (i >= 0) a.splice(i, 1); }
  emit(evt, a, b, c) { const l = this.map.get(evt); if (!l) return; for (let i = 0; i < l.length; i++) l[i](a, b, c); }
}
