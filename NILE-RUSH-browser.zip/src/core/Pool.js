/** Fixed-capacity object pool. Objects are created once and recycled. */
export class Pool {
  constructor(factory, size) {
    this.items = new Array(size);
    for (let i = 0; i < size; i++) { this.items[i] = factory(i); this.items[i].alive = false; }
    this.cursor = 0;
  }
  acquire() {
    const n = this.items.length;
    for (let i = 0; i < n; i++) {
      const idx = (this.cursor + i) % n; const it = this.items[idx];
      if (!it.alive) { this.cursor = (idx + 1) % n; it.alive = true; return it; }
    }
    return null;
  }
  releaseAll() { for (const it of this.items) it.alive = false; }
  forEachAlive(fn) { const a = this.items; for (let i = 0; i < a.length; i++) if (a[i].alive) fn(a[i], i); }
}
