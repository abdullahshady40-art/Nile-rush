import { CFG } from '../core/Config.js';
import { clamp, damp } from '../core/Utils.js';

/** Player physics + animation state. Forward is -Z; lanes are -1 / 0 / +1. */
export class Player {
  constructor() { this.cb = {}; this.reset(); }
  reset() {
    this.lane = 0; this.x = 0; this.y = 0; this.vy = 0; this.z = 0; this.prevZ = 0;
    this.slideT = 0; this.slideAnim = 0; this.pendingSlide = false; this.jumpBuf = 0;
    this.airborne = false; this.anim = 'run'; this.phi = 0; this.t = 0; this.hitT = 0; this.deadT = 0; this.roll = 0; this.yaw = 0;
    this.dead = false; this.hurt = 0; this.flicker = 0; this.speed = 0; this.vx = 0; this.dashT = 0; this.dashMeter = 0;
    this.boardOn = false; this.grace = 0; this.airTime = 0;
  }
  get height() { return this.slideT > 0 ? CFG.slideH : CFG.playerH; }
  get inAir() { return this.y > 0.02; }

  left() { if (this.dead) return; if (this.lane > -1) { this.lane--; this.cb.lane && this.cb.lane(-1); } else this.cb.bump && this.cb.bump(-1); }
  right() { if (this.dead) return; if (this.lane < 1) { this.lane++; this.cb.lane && this.cb.lane(1); } else this.cb.bump && this.cb.bump(1); }
  jump() { if (this.dead) return; this.jumpBuf = 0.14; }
  slide() {
    if (this.dead) return;
    if (this.inAir) { this.vy = Math.min(this.vy, -26); this.pendingSlide = true; return; }
    if (this.slideT <= 0) this.cb.slide && this.cb.slide();
    this.slideT = CFG.slideTime; this.slideAnim = 0;
  }

  /** fx: character/board modifiers {jump, glide} */
  update(dt, speed, fx) {
    this.t += dt; this.speed = speed; this.prevZ = this.z;
    if (this.grace > 0) this.grace -= dt;
    this.flicker = this.grace > 0 ? this.flicker + dt * 30 : 0;
    if (this.dead) { this.deadT += dt; this.z -= Math.max(0, speed * 0.28 * Math.exp(-this.deadT * 3)) * dt; return; }
    // forward
    this.z -= speed * dt;
    // lateral
    const tx = this.lane * CFG.laneWidth, nx = damp(this.x, tx, CFG.laneSpeed, dt);
    this.vx = (nx - this.x) / Math.max(dt, 1e-4); this.x = nx;
    this.roll = damp(this.roll, clamp(-this.vx * 0.028, -0.4, 0.4), 12, dt);
    // jump
    if (this.jumpBuf > 0) {
      this.jumpBuf -= dt;
      if (!this.inAir && this.vy <= 0) { this.vy = CFG.jumpVel * (fx.jump || 1); this.y = 0.03; this.slideT = 0; this.pendingSlide = false; this.airTime = 0; this.cb.jump && this.cb.jump(); this.jumpBuf = 0; }
    }
    if (this.inAir || this.vy > 0) {
      this.airTime += dt;
      const g = CFG.gravity * (this.vy > 0 || this.pendingSlide ? (fx.glide || 1) : (fx.glide || 1) * 1.05);
      this.vy -= g * dt; this.y += this.vy * dt;
      if (this.y <= 0) {
        const impact = -this.vy; this.y = 0; this.vy = 0;
        this.cb.land && this.cb.land(impact);
        if (this.pendingSlide) { this.pendingSlide = false; this.slideT = CFG.slideTime; this.slideAnim = 0; this.cb.slide && this.cb.slide(); }
      }
    }
    if (this.slideT > 0) { this.slideT -= dt; this.slideAnim += dt; }
    if (this.dashT > 0) this.dashT -= dt;
    // animation selection
    const grounded = !this.inAir;
    if (this.dashT > 0 && grounded && this.slideT <= 0) this.anim = 'boost';
    else if (this.slideT > 0 && grounded) this.anim = 'slide';
    else if (!grounded) this.anim = this.vy > 0 ? 'jump' : 'fall';
    else this.anim = 'run';
    if (this.boardOn && (this.anim === 'run' || this.anim === 'boost')) this.anim = 'board';
    this.phi += dt * (9 + speed * 0.3) * (this.anim === 'boost' ? 1.25 : 1);
  }

  hit() { this.dead = true; this.anim = 'death'; this.deadT = 0; this.slideT = 0; }
  aabb(out) {
    out.x = this.x; out.z = this.z; out.hw = CFG.playerHalfW; out.hd = CFG.playerHalfD;
    out.y0 = this.y; out.y1 = this.y + this.height; return out;
  }
}
