import * as M from '../core/mat4.js';

// Minimal glTF 2.0 / GLB loader for static meshes (positions, normals, UVs, indices, base colour + texture).
// Skinning/animation data in the file is ignored: the model is displayed in its bind pose and animated
// by the engine with whole-body transforms.
const COMP = { 5120: Int8Array, 5121: Uint8Array, 5122: Int16Array, 5123: Uint16Array, 5125: Uint32Array, 5126: Float32Array };
const NCOMP = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT4: 16 };

async function readBinary(url) { const r = await fetch(url); if (!r.ok) throw new Error(`HTTP ${r.status} for ${url}`); return r.arrayBuffer(); }

function parseGLB(buf) {
  const dv = new DataView(buf);
  if (dv.getUint32(0, true) !== 0x46546c67) throw new Error('Not a GLB file');
  let off = 12, json = null, bin = null;
  while (off < buf.byteLength) {
    const len = dv.getUint32(off, true), type = dv.getUint32(off + 4, true); off += 8;
    if (type === 0x4e4f534a) json = JSON.parse(new TextDecoder().decode(new Uint8Array(buf, off, len)));
    else if (type === 0x004e4942 && !bin) bin = buf.slice(off, off + len);
    off += len;
  }
  return { json, bin };
}

export async function loadGLTF(renderer, url, opts = {}) {
  const buf0 = await readBinary(url);
  let json, buffers = [];
  if (url.toLowerCase().endsWith('.gltf')) {
    json = JSON.parse(new TextDecoder().decode(new Uint8Array(buf0)));
    const base = url.slice(0, url.lastIndexOf('/') + 1);
    for (const b of json.buffers || []) buffers.push(b.uri.startsWith('data:') ? await (await fetch(b.uri)).arrayBuffer() : await readBinary(base + b.uri));
  } else { const g = parseGLB(buf0); json = g.json; buffers = [g.bin]; }

  const accessor = (idx) => {
    const a = json.accessors[idx], bv = json.bufferViews[a.bufferView], T = COMP[a.componentType], n = NCOMP[a.type];
    const base = (bv.byteOffset || 0) + (a.byteOffset || 0), stride = bv.byteStride || n * T.BYTES_PER_ELEMENT;
    const out = new Float32Array(a.count * n), src = new DataView(buffers[bv.buffer]);
    const get = { 5126: 'getFloat32', 5125: 'getUint32', 5123: 'getUint16', 5121: 'getUint8', 5122: 'getInt16', 5120: 'getInt8' }[a.componentType];
    const sz = T.BYTES_PER_ELEMENT, norm = a.normalized && a.componentType !== 5126;
    const div = { 5121: 255, 5123: 65535, 5120: 127, 5122: 32767 }[a.componentType] || 1;
    for (let i = 0; i < a.count; i++) for (let j = 0; j < n; j++) { const v = src[get](base + i * stride + j * sz, true); out[i * n + j] = norm ? Math.max(v / div, -1) : v; }
    return out;
  };

  // textures
  const texCache = new Map();
  const getTexture = async (ti) => {
    if (texCache.has(ti)) return texCache.get(ti);
    let p = null;
    try {
      const img = json.images[json.textures[ti].source]; let blob;
      if (img.bufferView !== undefined) { const bv = json.bufferViews[img.bufferView]; blob = new Blob([new Uint8Array(buffers[bv.buffer], bv.byteOffset || 0, bv.byteLength)], { type: img.mimeType || 'image/png' }); }
      else { const base = url.slice(0, url.lastIndexOf('/') + 1); blob = await (await fetch(img.uri.startsWith('data:') ? img.uri : base + img.uri)).blob(); }
      const bmp = await createImageBitmap(blob);
      p = renderer.createTexture(bmp, { flipY: false, repeat: true });
    } catch (e) { console.warn('glTF texture failed', e); }
    texCache.set(ti, p); return p;
  };

  const parts = [];
  const nodeMat = (n) => {
    const m = M.create();
    if (n.matrix) { m.set(n.matrix); return m; }
    const t = n.translation || [0, 0, 0], q = n.rotation || [0, 0, 0, 1], s = n.scale || [1, 1, 1];
    const [x, y, z, w] = q, x2 = x + x, y2 = y + y, z2 = z + z, xx = x * x2, xy = x * y2, xz = x * z2, yy = y * y2, yz = y * z2, zz = z * z2, wx = w * x2, wy = w * y2, wz = w * z2;
    m[0] = (1 - (yy + zz)) * s[0]; m[1] = (xy + wz) * s[0]; m[2] = (xz - wy) * s[0];
    m[4] = (xy - wz) * s[1]; m[5] = (1 - (xx + zz)) * s[1]; m[6] = (yz + wx) * s[1];
    m[8] = (xz + wy) * s[2]; m[9] = (yz - wx) * s[2]; m[10] = (1 - (xx + yy)) * s[2];
    m[12] = t[0]; m[13] = t[1]; m[14] = t[2]; m[15] = 1; return m;
  };
  const visit = async (ni, parent) => {
    const n = json.nodes[ni], m = M.multiply(M.create(), parent, nodeMat(n));
    if (n.mesh !== undefined) {
      for (const prim of json.meshes[n.mesh].primitives) {
        if (prim.mode !== undefined && prim.mode !== 4) continue;
        const pos = accessor(prim.attributes.POSITION); let nrm = prim.attributes.NORMAL !== undefined ? accessor(prim.attributes.NORMAL) : null;
        let uv = prim.attributes.TEXCOORD_0 !== undefined ? accessor(prim.attributes.TEXCOORD_0) : new Float32Array((pos.length / 3) * 2);
        let idx = prim.indices !== undefined ? accessor(prim.indices) : Float32Array.from({ length: pos.length / 3 }, (_, i) => i);
        let P = pos, U = uv, I = idx;
        if (!nrm) { // flat normals: de-index
          const np = new Float32Array(idx.length * 3), nu = new Float32Array(idx.length * 2), nn = new Float32Array(idx.length * 3);
          for (let i = 0; i < idx.length; i++) { const v = idx[i]; np.set(pos.subarray(v * 3, v * 3 + 3), i * 3); nu.set(uv.subarray(v * 2, v * 2 + 2), i * 2); }
          for (let i = 0; i < idx.length; i += 3) {
            const ax = np[i * 3 + 3] - np[i * 3], ay = np[i * 3 + 4] - np[i * 3 + 1], az = np[i * 3 + 5] - np[i * 3 + 2], bx = np[i * 3 + 6] - np[i * 3], by = np[i * 3 + 7] - np[i * 3 + 1], bz = np[i * 3 + 8] - np[i * 3 + 2];
            let cx = ay * bz - az * by, cy = az * bx - ax * bz, cz = ax * by - ay * bx; const l = Math.hypot(cx, cy, cz) || 1; cx /= l; cy /= l; cz /= l;
            for (let k = 0; k < 3; k++) { nn[(i + k) * 3] = cx; nn[(i + k) * 3 + 1] = cy; nn[(i + k) * 3 + 2] = cz; }
          }
          P = np; U = nu; nrm = nn; I = Float32Array.from({ length: idx.length }, (_, i) => i);
        }
        const count = P.length / 3, IT = count > 65535 ? Uint32Array : Uint16Array;
        const geo = renderer.createGeometry({ pos: P, nrm, uv: U, idx: IT.from(I) }, 'glb');
        const mat = prim.material !== undefined ? json.materials[prim.material] : null, pbr = mat && mat.pbrMetallicRoughness;
        const f = (pbr && pbr.baseColorFactor) || [1, 1, 1, 1];
        if (pbr && pbr.baseColorTexture) geo.map = await getTexture(pbr.baseColorTexture.index);
        parts.push({ geo, matrix: m, color: [f[0], f[1], f[2]], pos: P });
      }
    }
    for (const c of n.children || []) await visit(c, m);
  };
  const scene = json.scenes[json.scene || 0];
  for (const ni of scene.nodes) await visit(ni, M.create());

  // bounds in model space -> normalise (feet on y=0, centred, target height)
  let mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9]; const v = [0, 0, 0];
  for (const p of parts) for (let i = 0; i < p.pos.length; i += 3) {
    const x = p.pos[i], y = p.pos[i + 1], z = p.pos[i + 2], m = p.matrix;
    v[0] = m[0] * x + m[4] * y + m[8] * z + m[12]; v[1] = m[1] * x + m[5] * y + m[9] * z + m[13]; v[2] = m[2] * x + m[6] * y + m[10] * z + m[14];
    for (let k = 0; k < 3; k++) { if (v[k] < mn[k]) mn[k] = v[k]; if (v[k] > mx[k]) mx[k] = v[k]; }
  }
  const target = opts.height || 1.75, sc = target / Math.max(mx[1] - mn[1], 1e-4) * (opts.scale || 1);
  const pre = M.create(); M.scale(pre, pre, sc, sc, sc); M.translate(pre, pre, -(mn[0] + mx[0]) / 2, -mn[1] + (opts.yOffset || 0) / sc, -(mn[2] + mx[2]) / 2);
  for (const p of parts) { p.matrix = M.multiply(M.create(), pre, p.matrix); delete p.pos; }
  return { parts, scale: 1, rotY: (opts.rotY || 0) * Math.PI / 180 };
}
