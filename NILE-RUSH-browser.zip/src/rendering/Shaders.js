// GLSL (WebGL2 / ES 3.00) for the NileForge renderer.
// Pattern ids used by the mesh shader (instance extra.y):
//  0 plain | 1 windows | 2 hazard stripes | 3 stone/brick | 4 water | 5 sand | 6 asphalt
//  8 rim glow | 9 blob shadow | 10 unlit | 11 sign atlas | 12 tiles | 13 cloth stripes
//  14 night-only glow (alpha*night) | 15 night emissive (p1 = strength)

export const MESH_VS = `#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNrm;
layout(location=2) in vec2 aUv;
layout(location=3) in vec4 aM0;
layout(location=4) in vec4 aM1;
layout(location=5) in vec4 aM2;
layout(location=6) in vec4 aM3;
layout(location=7) in vec4 aCol;
layout(location=8) in vec4 aEx;
uniform mat4 uVP;
out vec3 vW; out vec3 vN; out vec2 vUv; flat out vec4 vC; flat out vec4 vE;
void main(){
  mat4 M = mat4(aM0, aM1, aM2, aM3);
  vec4 w = M * vec4(aPos, 1.0);
  vW = w.xyz; vN = mat3(M) * aNrm; vUv = aUv; vC = aCol; vE = aEx;
  gl_Position = uVP * w;
}`;

export const MESH_FS = `#version 300 es
precision highp float;
in vec3 vW; in vec3 vN; in vec2 vUv; flat in vec4 vC; flat in vec4 vE;
out vec4 o;
uniform vec3 uCam, uSunDir, uSunCol, uAmbS, uAmbG, uFogCol, uGrade;
uniform vec2 uFog;
uniform float uTime, uNight, uAdd, uUseMap, uFlash;
uniform sampler2D uMap;

float h21(vec2 p){ uvec2 v = uvec2(ivec2(floor(p))); v = v * 1664525u + 1013904223u; v.x += v.y * 1664525u; v.y += v.x * 1664525u; v ^= v >> 16u; v.x += v.y * 1664525u; v.y += v.x * 1664525u; v ^= v >> 16u; return float((v.x ^ v.y) & 16777215u) / 16777216.0; }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
  return mix(mix(h21(i), h21(i+vec2(1.,0.)), f.x), mix(h21(i+vec2(0.,1.)), h21(i+vec2(1.,1.)), f.x), f.y); }
float wallU(vec3 n){ return (abs(n.y) > 0.5) ? vW.x : dot(vW.xz, normalize(vec2(-n.z, n.x) + vec2(1e-4))); }

void main(){
  vec3 N = normalize(vN);
  vec3 toCam = uCam - vW; float dist = length(toCam); vec3 V = toCam / max(dist, 1e-4);
  vec3 base = vC.rgb; float alpha = vC.a; float emis = vE.x; int pat = int(vE.y + 0.5); float p1 = vE.z;
  float spec = 0.0; float unlit = 0.0;
  if (uUseMap > 0.5 && pat != 11) { vec4 t = texture(uMap, vUv); base *= t.rgb; alpha *= t.a; }

  if (pat == 1) {
    if (abs(N.y) < 0.5) {
      float u = wallU(N); float v = vW.y;
      vec2 cell = vec2(u / 2.4, v / 2.9); vec2 id = floor(cell); vec2 f = fract(cell);
      float win = step(0.2, f.x) * step(f.x, 0.8) * step(0.25, f.y) * step(f.y, 0.78) * step(1.4, v);
      float r = h21(id + p1);
      vec3 glass = mix(vec3(0.10, 0.16, 0.24), vec3(0.34, 0.50, 0.62), 0.5 * (1.0 - uNight));
      float lit = step(0.55, r) * uNight;
      vec3 warm = mix(vec3(1.0, 0.74, 0.38), vec3(1.0, 0.92, 0.68), r);
      base = mix(base, mix(glass, warm, lit), win);
      emis += win * lit * 1.15;
      base *= 1.0 - 0.10 * step(0.93, f.y);
    }
    base *= mix(0.70, 1.0, smoothstep(0.0, 2.2, vW.y));
  } else if (pat == 2) {
    float u = wallU(N);
    float s = step(0.5, fract((u + vW.y) * 1.25));
    base = mix(base, vec3(0.08, 0.07, 0.07), s);
  } else if (pat == 3) {
    float u = wallU(N); float v = vW.y;
    vec2 b = vec2(u * 1.5 + floor(v * 2.6) * 0.5, v * 2.6);
    float mortar = clamp(step(fract(b.x), 0.06) + step(fract(b.y), 0.09), 0.0, 1.0);
    base *= (0.90 + 0.16 * h21(floor(b))) * (1.0 - 0.24 * mortar);
    base *= mix(0.78, 1.0, smoothstep(0.0, 1.6, vW.y));
  } else if (pat == 4) {
    vec2 q = vW.xz * 0.35;
    float w1 = sin(q.x * 3.0 + uTime * 1.2 + sin(q.y * 2.0 + uTime * 0.7));
    float w2 = sin(q.y * 4.0 - uTime * 1.0 + q.x);
    vec3 Np = normalize(N + vec3(w1 * 0.06, 0.0, w2 * 0.06));
    float fres = pow(1.0 - max(dot(Np, V), 0.0), 3.0);
    vec3 R = reflect(-V, Np);
    spec = pow(max(dot(R, uSunDir), 0.0), 70.0) * 1.7;
    base = mix(base, uFogCol * 0.85 + uAmbS * 0.25, fres * 0.7);
    base += uSunCol * smoothstep(0.86, 1.0, vn(vW.xz * vec2(2.0, 0.7) + vec2(0.0, uTime * 0.7))) * 0.10;
    base += vec3(0.0, 0.03, 0.04) * w1;
  } else if (pat == 5) {
    float n = vn(vW.xz * 0.30); float rip = sin(vW.x * 2.4 + n * 7.0) * 0.5 + 0.5;
    base *= 0.90 + 0.09 * n + 0.05 * rip;
  } else if (pat == 6) {
    base *= (0.90 + 0.10 * h21(floor(vW.xz * 7.0))) * (0.94 + 0.10 * vn(vW.xz * 0.6));
  } else if (pat == 8) {
    float f = pow(1.0 - abs(dot(N, V)), 2.2);
    alpha *= f; emis = 1.2; unlit = 1.0;
  } else if (pat == 9) {
    float d = length(vUv - 0.5) * 2.0;
    alpha *= 1.0 - smoothstep(0.15, 1.0, d); unlit = 1.0;
  } else if (pat == 10) {
    unlit = 1.0;
  } else if (pat == 11) {
    float idx = floor(p1 + 0.5);
    vec2 cell = vec2(mod(idx, 4.0), 7.0 - floor(idx / 4.0));
    vec4 t = texture(uMap, (vUv * 0.985 + 0.0075 + cell) / vec2(4.0, 8.0));
    base = t.rgb * vC.rgb; alpha = t.a * vC.a; emis += uNight * 0.85;
  } else if (pat == 12) {
    vec2 g = floor(vW.xz / 1.6); vec2 f = fract(vW.xz / 1.6);
    float m = step(f.x, 0.03) + step(f.y, 0.03);
    base *= (0.93 + 0.07 * mod(g.x + g.y, 2.0)) * (1.0 - 0.18 * clamp(m, 0.0, 1.0));
  } else if (pat == 14) {
    alpha *= uNight; unlit = 1.0;
  } else if (pat == 15) {
    emis += uNight * p1;
  } else if (pat == 13) {
    float u = (abs(N.y) > 0.5) ? vW.x : dot(vW.xz, normalize(vec2(-N.z, N.x) + vec2(1e-4)));
    base = mix(base, vec3(0.96, 0.94, 0.88), step(0.5, fract(u * 1.3)));
  }

  float ndl = max(dot(N, uSunDir), 0.0);
  vec3 amb = mix(uAmbG, uAmbS, N.y * 0.5 + 0.5);
  vec3 lit = base * (amb + uSunCol * ndl) * uGrade + base * emis + spec * uSunCol;
  if (unlit > 0.5) lit = base * (1.0 + emis);
  lit += vec3(uFlash) * 0.5;
  float f = smoothstep(uFog.x, uFog.y, dist);
  if (uAdd > 0.5) { o = vec4(lit, alpha * (1.0 - f)); }
  else { o = vec4(mix(lit, uFogCol, f), alpha); }
}`;

export const SKY_VS = `#version 300 es
out vec2 vP;
void main(){
  vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2);
  vP = p * 2.0 - 1.0;
  gl_Position = vec4(vP, 0.9999, 1.0);
}`;

export const SKY_FS = `#version 300 es
precision highp float;
in vec2 vP; out vec4 o;
uniform vec3 uTop, uMid, uBot, uSunDir, uSunCol, uRight, uUp, uFwd, uCloudCol;
uniform vec2 uTan, uShift;
uniform float uNight, uTime, uFlash, uCloud;
float h31(vec3 p){ p = fract(p * vec3(.1031, .1030, .0973)); p += dot(p, p.yxz + 33.33); return fract((p.x + p.y) * p.z); }
float h21(vec2 p){ uvec2 v = uvec2(ivec2(floor(p))); v = v * 1664525u + 1013904223u; v.x += v.y * 1664525u; v.y += v.x * 1664525u; v ^= v >> 16u; v.x += v.y * 1664525u; v.y += v.x * 1664525u; v ^= v >> 16u; return float((v.x ^ v.y) & 16777215u) / 16777216.0; }
float vn(vec2 p){ vec2 i = floor(p), f = fract(p); f = f*f*(3.0-2.0*f);
  return mix(mix(h21(i), h21(i+vec2(1.,0.)), f.x), mix(h21(i+vec2(0.,1.)), h21(i+vec2(1.,1.)), f.x), f.y); }
float fbm(vec2 p){ float a = 0.5, s = 0.0; for (int i = 0; i < 4; i++) { s += a * vn(p); p *= 2.03; a *= 0.5; } return s; }
void main(){
  vec2 q = vP - uShift;
  vec3 rd = normalize(uFwd + uRight * q.x * uTan.x + uUp * q.y * uTan.y);
  float h = rd.y;
  vec3 col = mix(uMid, uTop, smoothstep(0.0, 0.7, h));
  col = mix(uBot, col, smoothstep(-0.02, 0.14, h));
  float sd = max(dot(rd, uSunDir), 0.0);
  vec3 disc = mix(uSunCol, vec3(1.0), 0.45);
  col += uSunCol * (pow(sd, 6.0) * 0.22 + pow(sd, 90.0) * 0.35) + disc * smoothstep(0.9994, 0.9998, sd) * 2.5;
  if (uNight > 0.01 && h > 0.0) {
    float r = h31(floor(rd * 210.0));
    float tw = 0.6 + 0.4 * sin(uTime * 3.0 + r * 60.0);
    col += step(0.9968, r) * tw * uNight * smoothstep(0.02, 0.3, h);
  }
  if (h > 0.015 && uCloud > 0.01) {
    vec2 cp = rd.xz / (h + 0.14) * 1.1 + vec2(uTime * 0.012, 0.0);
    float c = smoothstep(0.52, 0.9, fbm(cp)) * uCloud * smoothstep(0.015, 0.22, h);
    col = mix(col, uCloudCol, c * 0.85);
  }
  col += vec3(uFlash) * 0.55;
  o = vec4(col, 1.0);
}`;

export const PART_VS = `#version 300 es
layout(location=0) in vec4 aPS;
layout(location=1) in vec4 aCol;
layout(location=2) in vec2 aShape;
uniform mat4 uView, uProj;
out vec2 vP; out vec4 vC; out float vS;
void main(){
  vec2 c = vec2((gl_VertexID & 1) == 0 ? -1.0 : 1.0, (gl_VertexID & 2) == 0 ? -1.0 : 1.0);
  vec4 vp = uView * vec4(aPS.xyz, 1.0);
  float cs = cos(aShape.y), sn = sin(aShape.y);
  vp.xy += vec2(c.x * cs - c.y * sn, c.x * sn + c.y * cs) * aPS.w;
  gl_Position = uProj * vp; vP = c; vC = aCol; vS = aShape.x;
}`;

export const PART_FS = `#version 300 es
precision mediump float;
in vec2 vP; in vec4 vC; in float vS;
out vec4 o;
void main(){
  float d = length(vP); float a;
  if (vS < 0.5) a = pow(clamp(1.0 - d, 0.0, 1.0), 1.4);
  else if (vS < 1.5) { float m = abs(vP.x) + abs(vP.y); a = clamp(1.0 - m, 0.0, 1.0); a = a * a * 1.6; a += pow(clamp(1.0 - d, 0.0, 1.0), 3.0); }
  else if (vS < 2.5) a = step(max(abs(vP.x), abs(vP.y)), 0.8);
  else a = smoothstep(0.35, 0.0, abs(d - 0.7));
  if (a < 0.01) discard;
  o = vec4(vC.rgb, vC.a * min(a, 1.0));
}`;
