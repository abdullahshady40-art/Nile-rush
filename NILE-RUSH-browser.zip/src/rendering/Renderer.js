import * as M from '../core/mat4.js';
import { Geometry, buildPrimitives } from './Geometry.js';
import { MESH_VS, MESH_FS, SKY_VS, SKY_FS } from './Shaders.js';

const F = 24; // floats per instance: mat4(16) + colour(4) + extra(4)
export const PASS = { OPAQUE: 0, ALPHA: 1, ADD: 2 };

class Batch {
  constructor(geo, pass) { this.geo = geo; this.pass = pass; this.data = new Float32Array(F * 96); this.n = 0; }
  grow() { const d = new Float32Array(this.data.length * 2); d.set(this.data); this.data = d; }
}

export class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    const gl = canvas.getContext('webgl2', { antialias: false, alpha: false, depth: true, stencil: false, powerPreference: 'high-performance' });
    this.ok = !!gl;
    if (!gl) return;
    this.gl = gl;
    this.lost = false;
    canvas.addEventListener('webglcontextlost', (e) => { e.preventDefault(); this.lost = true; });
    canvas.addEventListener('webglcontextrestored', () => location.reload());
    this.mesh = this.createProgram(MESH_VS, MESH_FS);
    this.sky = this.createProgram(SKY_VS, SKY_FS);
    this.U = this.uniforms(this.mesh, ['uVP', 'uCam', 'uSunDir', 'uSunCol', 'uAmbS', 'uAmbG', 'uFogCol', 'uGrade', 'uFog', 'uTime', 'uNight', 'uAdd', 'uUseMap', 'uFlash', 'uMap']);
    this.SU = this.uniforms(this.sky, ['uTop', 'uMid', 'uBot', 'uSunDir', 'uSunCol', 'uRight', 'uUp', 'uFwd', 'uCloudCol', 'uTan', 'uShift', 'uNight', 'uTime', 'uFlash', 'uCloud']);
    this.instBuf = gl.createBuffer();
    this.geo = buildPrimitives(gl);
    this.batches = []; this.active = [];
    this.frameBuf = new Float32Array(F * 2048);
    this.tmp = M.create();
    this.time = 0; this.width = 1; this.height = 1; this.stats = { draws: 0, instances: 0 };
    this.camera = null; this.env = null; this.emptyVao = gl.createVertexArray();
    this.dummyTex = this.createTexture(new Uint8Array([255, 255, 255, 255]), { w: 1, h: 1, mip: false });
  }

  createProgram(vs, fs) {
    const gl = this.gl;
    const sh = (type, src) => {
      const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
      if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { const log = gl.getShaderInfoLog(s); console.error(log, src); throw new Error('Shader compile failed: ' + log); }
      return s;
    };
    const p = gl.createProgram();
    gl.attachShader(p, sh(gl.VERTEX_SHADER, vs)); gl.attachShader(p, sh(gl.FRAGMENT_SHADER, fs));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('Program link failed: ' + gl.getProgramInfoLog(p));
    return p;
  }
  uniforms(prog, names) { const o = {}; for (const n of names) o[n] = this.gl.getUniformLocation(prog, n); return o; }

  createTexture(source, o = {}) {
    const gl = this.gl; const t = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, t);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, o.flipY === false ? 0 : 1);
    if (source instanceof Uint8Array) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, o.w, o.h, 0, gl.RGBA, gl.UNSIGNED_BYTE, source);
    else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, source);
    const mip = o.mip !== false;
    if (mip) gl.generateMipmap(gl.TEXTURE_2D);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, mip ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    const wrap = o.repeat ? gl.REPEAT : gl.CLAMP_TO_EDGE;
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrap); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrap);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, 0);
    return t;
  }
  createGeometry(data, name) { return new Geometry(this.gl, data, name); }

  resize(cssW, cssH, pixelRatio) {
    const w = Math.max(2, Math.floor(cssW * pixelRatio)), h = Math.max(2, Math.floor(cssH * pixelRatio));
    if (this.canvas.width !== w || this.canvas.height !== h) { this.canvas.width = w; this.canvas.height = h; }
    this.width = w; this.height = h;
  }

  begin(camera, env, time) {
    this.camera = camera; this.env = env; this.time = time;
    for (let i = 0; i < this.active.length; i++) this.active[i].n = 0;
    this.active.length = 0;
  }

  _batch(geo, pass) {
    const k = geo.id * 3 + pass;
    let b = this.batches[k];
    if (!b) b = this.batches[k] = new Batch(geo, pass);
    if (b.n === 0) this.active.push(b);
    return b;
  }

  /** Submit one instance. c = [r,g,b]; pat = shader pattern id; p1 = pattern parameter. */
  submit(geo, m, c, a = 1, em = 0, pat = 0, p1 = 0, pass = 0) {
    const b = this._batch(geo, pass);
    if ((b.n + 1) * F > b.data.length) b.grow();
    const d = b.data, o = b.n * F;
    d.set(m, o);
    d[o + 16] = c[0]; d[o + 17] = c[1]; d[o + 18] = c[2]; d[o + 19] = a;
    d[o + 20] = em; d[o + 21] = pat; d[o + 22] = p1; d[o + 23] = 0;
    b.n++;
  }
  submitTRS(geo, x, y, z, rx, ry, rz, sx, sy, sz, c, a = 1, em = 0, pat = 0, p1 = 0, pass = 0) {
    M.compose(this.tmp, x, y, z, rx, ry, rz, sx, sy, sz);
    this.submit(geo, this.tmp, c, a, em, pat, p1, pass);
  }
  /** Copy n pre-built instances (24 floats each) — used by static world segments. */
  submitRaw(geo, arr, n, pass) {
    if (!n) return;
    const b = this._batch(geo, pass);
    while ((b.n + n) * F > b.data.length) b.grow();
    b.data.set(arr.subarray(0, n * F), b.n * F);
    b.n += n;
  }

  _flushPass(pass) {
    const gl = this.gl; let total = 0;
    for (const b of this.active) if (b.pass === pass) total += b.n;
    if (!total) return;
    if (total * F > this.frameBuf.length) this.frameBuf = new Float32Array(total * F * 2);
    let off = 0;
    for (const b of this.active) if (b.pass === pass) { this.frameBuf.set(b.data.subarray(0, b.n * F), off * F); b.off = off; off += b.n; }
    gl.bindBuffer(gl.ARRAY_BUFFER, this.instBuf);
    gl.bufferData(gl.ARRAY_BUFFER, this.frameBuf.subarray(0, total * F), gl.DYNAMIC_DRAW);
    const U = this.U; let lastTex;
    for (const b of this.active) {
      if (b.pass !== pass) continue;
      const g = b.geo, base = b.off * F * 4;
      gl.bindVertexArray(g.vao);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.instBuf);
      for (let i = 0; i < 4; i++) gl.vertexAttribPointer(3 + i, 4, gl.FLOAT, false, 96, base + i * 16);
      gl.vertexAttribPointer(7, 4, gl.FLOAT, false, 96, base + 64);
      gl.vertexAttribPointer(8, 4, gl.FLOAT, false, 96, base + 80);
      const tex = g.map || null;
      if (tex !== lastTex) { gl.bindTexture(gl.TEXTURE_2D, tex || this.dummyTex); gl.uniform1f(U.uUseMap, tex ? 1 : 0); lastTex = tex; }
      gl.drawElementsInstanced(gl.TRIANGLES, g.count, g.indexType, 0, b.n);
      this.stats.draws++; this.stats.instances += b.n;
    }
    gl.bindVertexArray(null);
  }

  render(particles) {
    if (this.lost) return;
    const gl = this.gl, cam = this.camera, env = this.env, U = this.U;
    this.stats.draws = 0; this.stats.instances = 0;
    gl.viewport(0, 0, this.width, this.height);
    gl.clearColor(env.fogCol[0], env.fogCol[1], env.fogCol[2], 1);
    gl.depthMask(true);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    // sky
    gl.disable(gl.DEPTH_TEST); gl.disable(gl.CULL_FACE); gl.disable(gl.BLEND);
    gl.useProgram(this.sky);
    const S = this.SU, t = Math.tan(cam.fov * Math.PI / 360);
    gl.uniform3fv(S.uTop, env.skyTop); gl.uniform3fv(S.uMid, env.skyMid); gl.uniform3fv(S.uBot, env.skyBot);
    gl.uniform3fv(S.uSunDir, env.sunDir); gl.uniform3fv(S.uSunCol, env.sunCol); gl.uniform3fv(S.uCloudCol, env.cloudCol);
    gl.uniform3fv(S.uRight, cam.right); gl.uniform3fv(S.uUp, cam.up); gl.uniform3fv(S.uFwd, cam.fwd);
    gl.uniform2f(S.uTan, t * cam.aspect, t); gl.uniform2f(S.uShift, cam.shiftX, cam.shiftY);
    gl.uniform1f(S.uNight, env.night); gl.uniform1f(S.uTime, this.time); gl.uniform1f(S.uFlash, env.flash); gl.uniform1f(S.uCloud, env.cloud);
    gl.bindVertexArray(this.emptyVao);
    gl.drawArrays(gl.TRIANGLES, 0, 3);

    // meshes
    gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL);
    gl.useProgram(this.mesh);
    gl.uniformMatrix4fv(U.uVP, false, cam.vp);
    gl.uniform3f(U.uCam, cam.pos[0], cam.pos[1], cam.pos[2]);
    gl.uniform3fv(U.uSunDir, env.sunDir); gl.uniform3fv(U.uSunCol, env.sunCol);
    gl.uniform3fv(U.uAmbS, env.ambS); gl.uniform3fv(U.uAmbG, env.ambG);
    gl.uniform3fv(U.uFogCol, env.fogCol); gl.uniform3fv(U.uGrade, env.grade);
    gl.uniform2f(U.uFog, env.fogNear, env.fogFar);
    gl.uniform1f(U.uTime, this.time); gl.uniform1f(U.uNight, env.night); gl.uniform1f(U.uFlash, env.flash);
    gl.uniform1i(U.uMap, 0); gl.activeTexture(gl.TEXTURE0);

    gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK); gl.disable(gl.BLEND); gl.uniform1f(U.uAdd, 0);
    this._flushPass(PASS.OPAQUE);

    gl.disable(gl.CULL_FACE); gl.enable(gl.BLEND); gl.depthMask(false);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
    this._flushPass(PASS.ALPHA);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE); gl.uniform1f(U.uAdd, 1);
    this._flushPass(PASS.ADD);

    if (particles) particles.render(this, cam);
    gl.depthMask(true); gl.disable(gl.BLEND);
  }
}
