import * as M from '../core/mat4.js';

export class Camera {
  constructor() {
    this.pos = new Float32Array([0, 4, 8]);
    this.target = new Float32Array([0, 1, 0]);
    this.fov = 64; this.aspect = 1; this.near = 0.3; this.far = 420;
    this.roll = 0; this.shiftX = 0; this.shiftY = 0;
    this.view = M.create(); this.proj = M.create(); this.vp = M.create();
    this.right = new Float32Array(3); this.up = new Float32Array(3); this.fwd = new Float32Array(3);
  }
  update() {
    const p = this.pos, t = this.target;
    const fx = t[0] - p[0], fy = t[1] - p[1], fz = t[2] - p[2];
    const fl = Math.hypot(fx, fy, fz) || 1;
    const f = this.fwd; f[0] = fx / fl; f[1] = fy / fl; f[2] = fz / fl;
    const ux = Math.sin(this.roll), uy = Math.cos(this.roll);
    M.lookAt(this.view, p[0], p[1], p[2], t[0], t[1], t[2], ux, uy, 0);
    M.perspective(this.proj, this.fov * Math.PI / 180, this.aspect, this.near, this.far, this.shiftX, this.shiftY);
    M.multiply(this.vp, this.proj, this.view);
    // basis (rows of view matrix)
    const v = this.view;
    this.right[0] = v[0]; this.right[1] = v[4]; this.right[2] = v[8];
    this.up[0] = v[1]; this.up[1] = v[5]; this.up[2] = v[9];
  }
}
