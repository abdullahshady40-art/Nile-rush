// Procedural primitive meshes + GPU geometry wrapper for the NileForge renderer.
// Vertex layout: position(3) normal(3) uv(2) — interleaved, 32 bytes.

class MeshBuilder {
  constructor() { this.pos = []; this.nrm = []; this.uv = []; this.idx = []; }
  v(px, py, pz, nx, ny, nz, u, v) { this.pos.push(px, py, pz); this.nrm.push(nx, ny, nz); this.uv.push(u, v); return this.pos.length / 3 - 1; }
  /** Adds a triangle and auto-corrects winding so the geometric normal agrees with vertex normals. */
  tri(a, b, c) {
    const p = this.pos, n = this.nrm;
    const ax = p[a * 3], ay = p[a * 3 + 1], az = p[a * 3 + 2];
    const e1x = p[b * 3] - ax, e1y = p[b * 3 + 1] - ay, e1z = p[b * 3 + 2] - az;
    const e2x = p[c * 3] - ax, e2y = p[c * 3 + 1] - ay, e2z = p[c * 3 + 2] - az;
    const cx = e1y * e2z - e1z * e2y, cy = e1z * e2x - e1x * e2z, cz = e1x * e2y - e1y * e2x;
    const nx = n[a * 3] + n[b * 3] + n[c * 3], ny = n[a * 3 + 1] + n[b * 3 + 1] + n[c * 3 + 1], nz = n[a * 3 + 2] + n[b * 3 + 2] + n[c * 3 + 2];
    if (cx * nx + cy * ny + cz * nz >= 0) this.idx.push(a, b, c); else this.idx.push(a, c, b);
  }
  quad(a, b, c, d) { this.tri(a, b, c); this.tri(a, c, d); }
  data() {
    return { pos: new Float32Array(this.pos), nrm: new Float32Array(this.nrm), uv: new Float32Array(this.uv), idx: this.pos.length / 3 > 65535 ? new Uint32Array(this.idx) : new Uint16Array(this.idx) };
  }
}

export function boxData() {
  const b = new MeshBuilder();
  const faces = [
    [0, 0, 1, 1, 0, 0, 0, 1, 0], [0, 0, -1, -1, 0, 0, 0, 1, 0],
    [1, 0, 0, 0, 0, -1, 0, 1, 0], [-1, 0, 0, 0, 0, 1, 0, 1, 0],
    [0, 1, 0, 1, 0, 0, 0, 0, -1], [0, -1, 0, 1, 0, 0, 0, 0, 1],
  ];
  for (const f of faces) {
    const [nx, ny, nz, tx, ty, tz, bx, by, bz] = f;
    const c = (s, t) => b.v(nx * .5 + tx * .5 * s + bx * .5 * t, ny * .5 + ty * .5 * s + by * .5 * t, nz * .5 + tz * .5 * s + bz * .5 * t, nx, ny, nz, (s + 1) / 2, (t + 1) / 2);
    b.quad(c(-1, -1), c(1, -1), c(1, 1), c(-1, 1));
  }
  return b.data();
}

export function planeData() {
  const b = new MeshBuilder();
  b.quad(b.v(-.5, 0, .5, 0, 1, 0, 0, 0), b.v(.5, 0, .5, 0, 1, 0, 1, 0), b.v(.5, 0, -.5, 0, 1, 0, 1, 1), b.v(-.5, 0, -.5, 0, 1, 0, 0, 1));
  return b.data();
}
/** Vertical quad in XY facing +Z, origin at centre. */
export function quadData() {
  const b = new MeshBuilder();
  b.quad(b.v(-.5, -.5, 0, 0, 0, 1, 0, 0), b.v(.5, -.5, 0, 0, 0, 1, 1, 0), b.v(.5, .5, 0, 0, 0, 1, 1, 1), b.v(-.5, .5, 0, 0, 0, 1, 0, 1));
  return b.data();
}

export function cylinderData(seg = 12, rTop = 0.5, rBot = 0.5, capTop = true, capBot = true, rot = 0) {
  const b = new MeshBuilder();
  const slope = (rBot - rTop); // height = 1
  const ring = [];
  for (let i = 0; i <= seg; i++) {
    const a = rot + (i / seg) * Math.PI * 2, c = Math.cos(a), s = Math.sin(a);
    const l = Math.hypot(1, slope);
    const nx = c / l, ny = slope / l, nz = s / l;
    const t = b.v(c * rTop, 0.5, s * rTop, nx, ny, nz, i / seg, 1);
    const bt = b.v(c * rBot, -0.5, s * rBot, nx, ny, nz, i / seg, 0);
    ring.push([t, bt]);
  }
  for (let i = 0; i < seg; i++) { b.tri(ring[i][1], ring[i][0], ring[i + 1][1]); if (rTop > 0) b.tri(ring[i + 1][1], ring[i][0], ring[i + 1][0]); }
  const cap = (y, r, ny) => {
    const c0 = b.v(0, y, 0, 0, ny, 0, .5, .5);
    let prev = -1;
    for (let i = 0; i <= seg; i++) {
      const a = rot + (i / seg) * Math.PI * 2, c = Math.cos(a), s = Math.sin(a);
      const v = b.v(c * r, y, s * r, 0, ny, 0, .5 + c * .5, .5 + s * .5);
      if (prev >= 0) b.tri(c0, prev, v);
      prev = v;
    }
  };
  if (capTop && rTop > 0) cap(0.5, rTop, 1);
  if (capBot && rBot > 0) cap(-0.5, rBot, -1);
  return b.data();
}

export function sphereData(lat = 10, lon = 14, top = 0, bottom = Math.PI) {
  const b = new MeshBuilder();
  const rows = [];
  for (let i = 0; i <= lat; i++) {
    const th = top + (i / lat) * (bottom - top);
    const row = [];
    for (let j = 0; j <= lon; j++) {
      const ph = (j / lon) * Math.PI * 2;
      const nx = Math.sin(th) * Math.cos(ph), ny = Math.cos(th), nz = Math.sin(th) * Math.sin(ph);
      row.push(b.v(nx * .5, ny * .5, nz * .5, nx, ny, nz, j / lon, 1 - i / lat));
    }
    rows.push(row);
  }
  for (let i = 0; i < lat; i++) for (let j = 0; j < lon; j++) b.quad(rows[i][j], rows[i][j + 1], rows[i + 1][j + 1], rows[i + 1][j]);
  return b.data();
}

export function torusData(R = 0.4, r = 0.1, seg = 20, tube = 8) {
  const b = new MeshBuilder();
  const rows = [];
  for (let i = 0; i <= seg; i++) {
    const a = (i / seg) * Math.PI * 2, ca = Math.cos(a), sa = Math.sin(a);
    const row = [];
    for (let j = 0; j <= tube; j++) {
      const t = (j / tube) * Math.PI * 2, ct = Math.cos(t), st = Math.sin(t);
      row.push(b.v((R + r * ct) * ca, r * st, (R + r * ct) * sa, ct * ca, st, ct * sa, i / seg, j / tube));
    }
    rows.push(row);
  }
  for (let i = 0; i < seg; i++) for (let j = 0; j < tube; j++) b.quad(rows[i][j], rows[i + 1][j], rows[i + 1][j + 1], rows[i][j + 1]);
  return b.data();
}

export function octaData() {
  const b = new MeshBuilder();
  for (const sx of [-1, 1]) for (const sy of [-1, 1]) for (const sz of [-1, 1]) {
    const l = Math.sqrt(3), nx = sx / l, ny = sy / l, nz = sz / l;
    b.tri(b.v(sx * .5, 0, 0, nx, ny, nz, 0, 0), b.v(0, sy * .5, 0, nx, ny, nz, 1, 0), b.v(0, 0, sz * .5, nx, ny, nz, .5, 1));
  }
  return b.data();
}

/** Triangular prism: triangle (-.5,-.5)(.5,-.5)(0,.5) in XY, extruded along Z (-.5..+.5). */
export function prismData() {
  const b = new MeshBuilder();
  const A = [-.5, -.5], B = [.5, -.5], C = [0, .5];
  for (const z of [.5, -.5]) {
    const nz = z > 0 ? 1 : -1;
    b.tri(b.v(A[0], A[1], z, 0, 0, nz, 0, 0), b.v(B[0], B[1], z, 0, 0, nz, 1, 0), b.v(C[0], C[1], z, 0, 0, nz, .5, 1));
  }
  const side = (p, q, nx, ny) => {
    const l = Math.hypot(nx, ny); nx /= l; ny /= l;
    b.quad(b.v(p[0], p[1], .5, nx, ny, 0, 0, 0), b.v(q[0], q[1], .5, nx, ny, 0, 1, 0), b.v(q[0], q[1], -.5, nx, ny, 0, 1, 1), b.v(p[0], p[1], -.5, nx, ny, 0, 0, 1));
  };
  side(A, B, 0, -1); side(B, C, 1, .5); side(C, A, -1, .5);
  return b.data();
}

let GEO_ID = 0;
export class Geometry {
  constructor(gl, data, name = '') {
    this.id = GEO_ID++; this.name = name; this.gl = gl; this.map = null;
    this.count = data.idx.length;
    this.indexType = data.idx instanceof Uint32Array ? gl.UNSIGNED_INT : gl.UNSIGNED_SHORT;
    const n = data.pos.length / 3;
    const inter = new Float32Array(n * 8);
    for (let i = 0; i < n; i++) {
      inter[i * 8] = data.pos[i * 3]; inter[i * 8 + 1] = data.pos[i * 3 + 1]; inter[i * 8 + 2] = data.pos[i * 3 + 2];
      inter[i * 8 + 3] = data.nrm[i * 3]; inter[i * 8 + 4] = data.nrm[i * 3 + 1]; inter[i * 8 + 5] = data.nrm[i * 3 + 2];
      inter[i * 8 + 6] = data.uv[i * 2]; inter[i * 8 + 7] = data.uv[i * 2 + 1];
    }
    this.vao = gl.createVertexArray(); gl.bindVertexArray(this.vao);
    this.vbo = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.vbo); gl.bufferData(gl.ARRAY_BUFFER, inter, gl.STATIC_DRAW);
    gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 3, gl.FLOAT, false, 32, 0);
    gl.enableVertexAttribArray(1); gl.vertexAttribPointer(1, 3, gl.FLOAT, false, 32, 12);
    gl.enableVertexAttribArray(2); gl.vertexAttribPointer(2, 2, gl.FLOAT, false, 32, 24);
    for (let l = 3; l <= 8; l++) { gl.enableVertexAttribArray(l); gl.vertexAttribDivisor(l, 1); }
    this.ibo = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, this.ibo); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, data.idx, gl.STATIC_DRAW);
    gl.bindVertexArray(null);
  }
  dispose() { const gl = this.gl; gl.deleteVertexArray(this.vao); gl.deleteBuffer(this.vbo); gl.deleteBuffer(this.ibo); }
}

export function buildPrimitives(gl) {
  const g = (name, d) => new Geometry(gl, d, name);
  return {
    box: g('box', boxData()),
    plane: g('plane', planeData()),
    quad: g('quad', quadData()),
    sign: g('sign', quadData()),
    cyl: g('cyl', cylinderData(14)),
    cyl6: g('cyl6', cylinderData(6)),
    cone: g('cone', cylinderData(14, 0, 0.5, false, true)),
    cone6: g('cone6', cylinderData(6, 0, 0.5, false, true)),
    pyramid: g('pyramid', cylinderData(4, 0, 0.5 * Math.SQRT2, false, true, Math.PI / 4)),
    sphere: g('sphere', sphereData(10, 16)),
    lowsphere: g('lowsphere', sphereData(5, 8)),
    dome: g('dome', sphereData(6, 18, 0, Math.PI / 2)),
    torus: g('torus', torusData(0.4, 0.1, 22, 8)),
    octa: g('octa', octaData()),
    prism: g('prism', prismData()),
  };
}
