import { PART_VS, PART_FS } from '../rendering/Shaders.js';

// Struct-of-floats particle pool rendered as instanced camera-facing billboards (2 draw calls).
const S = 20; // stride
const PX = 0, PY = 1, PZ = 2, VX = 3, VY = 4, VZ = 5, LIFE = 6, MAXL = 7, S0 = 8, S1 = 9, R = 10, G = 11, B = 12, A = 13, GRAV = 14, DRAG = 15, SHAPE = 16, ADD = 17, ROT = 18, ROTV = 19;
const rnd = Math.random;

export class ParticleSystem {
  constructor(renderer, max = 800) {
    const gl = this.gl = renderer.gl;
    this.max = max; this.n = 0;
    this.P = new Float32Array(max * S);
    this.inst = new Float32Array(max * 10);
    this.prog = renderer.createProgram(PART_VS, PART_FS);
    this.u = renderer.uniforms(this.prog, ['uView', 'uProj']);
    this.vao = gl.createVertexArray(); gl.bindVertexArray(this.vao);
    this.buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
    gl.bufferData(gl.ARRAY_BUFFER, this.inst.byteLength, gl.DYNAMIC_DRAW);
    for (let l = 0; l < 3; l++) { gl.enableVertexAttribArray(l); gl.vertexAttribDivisor(l, 1); }
    gl.bindVertexArray(null);
    this.trail = { r: 0.85, g: 0.72, b: 0.5, add: 0, shape: 0 };
    this.na = 0; this.nb = 0;
  }
  setMax(m) { this.max = Math.min(m, this.P.length / S); if (this.n > this.max) this.n = this.max; }
  clear() { this.n = 0; }

  emit(x, y, z, vx, vy, vz, life, s0, s1, r, g, b, a, grav = 0, drag = 0, shape = 0, add = 0) {
    if (this.n >= this.max) return;
    const P = this.P, o = this.n++ * S;
    P[o + PX] = x; P[o + PY] = y; P[o + PZ] = z; P[o + VX] = vx; P[o + VY] = vy; P[o + VZ] = vz;
    P[o + LIFE] = life; P[o + MAXL] = life; P[o + S0] = s0; P[o + S1] = s1;
    P[o + R] = r; P[o + G] = g; P[o + B] = b; P[o + A] = a; P[o + GRAV] = grav; P[o + DRAG] = drag;
    P[o + SHAPE] = shape; P[o + ADD] = add; P[o + ROT] = rnd() * 6.28; P[o + ROTV] = (rnd() - 0.5) * 6;
  }

  update(dt) {
    const P = this.P;
    for (let i = 0; i < this.n; i++) {
      const o = i * S;
      P[o + LIFE] -= dt;
      if (P[o + LIFE] <= 0) { // swap-remove
        const l = --this.n * S;
        if (l !== o) for (let k = 0; k < S; k++) P[o + k] = P[l + k];
        i--; continue;
      }
      const d = Math.max(0, 1 - P[o + DRAG] * dt);
      P[o + VX] *= d; P[o + VY] = (P[o + VY] - P[o + GRAV] * dt) * d; P[o + VZ] *= d;
      P[o + PX] += P[o + VX] * dt; P[o + PY] += P[o + VY] * dt; P[o + PZ] += P[o + VZ] * dt;
      P[o + ROT] += P[o + ROTV] * dt;
    }
  }

  render(renderer, cam) {
    if (!this.n) return;
    const gl = this.gl, P = this.P, I = this.inst;
    let k = 0, na = 0, nb = 0;
    for (let pass = 0; pass < 2; pass++) {
      for (let i = 0; i < this.n; i++) {
        const o = i * S; if ((P[o + ADD] > 0.5 ? 1 : 0) !== pass) continue;
        const t = 1 - P[o + LIFE] / P[o + MAXL];
        const size = P[o + S0] + (P[o + S1] - P[o + S0]) * t;
        const fade = t < 0.12 ? t / 0.12 : 1 - (t - 0.12) / 0.88;
        I[k++] = P[o + PX]; I[k++] = P[o + PY]; I[k++] = P[o + PZ]; I[k++] = size;
        I[k++] = P[o + R]; I[k++] = P[o + G]; I[k++] = P[o + B]; I[k++] = P[o + A] * fade;
        I[k++] = P[o + SHAPE]; I[k++] = P[o + ROT];
        if (pass === 0) na++; else nb++;
      }
    }
    gl.useProgram(this.prog);
    gl.uniformMatrix4fv(this.u.uView, false, cam.view); gl.uniformMatrix4fv(this.u.uProj, false, cam.proj);
    gl.bindVertexArray(this.vao); gl.bindBuffer(gl.ARRAY_BUFFER, this.buf);
    gl.bufferSubData(gl.ARRAY_BUFFER, 0, I.subarray(0, k));
    const draw = (first, count) => {
      if (!count) return; const base = first * 40;
      gl.vertexAttribPointer(0, 4, gl.FLOAT, false, 40, base); gl.vertexAttribPointer(1, 4, gl.FLOAT, false, 40, base + 16); gl.vertexAttribPointer(2, 2, gl.FLOAT, false, 40, base + 32);
      gl.drawArraysInstanced(gl.TRIANGLE_STRIP, 0, 4, count);
    };
    gl.enable(gl.BLEND); gl.disable(gl.CULL_FACE); gl.depthMask(false);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); draw(0, na);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE); draw(na, nb);
    gl.bindVertexArray(null);
    renderer.stats.draws += 2; renderer.stats.instances += na + nb;
  }

  // ------------------------------------------------------------- presets
  coinSparkle(x, y, z, rare = false) {
    const n = rare ? 9 : 5;
    for (let i = 0; i < n; i++) {
      const a = rnd() * 6.28, s = 1.5 + rnd() * 3;
      if (rare) this.emit(x, y, z, Math.cos(a) * s, 1 + rnd() * 3, Math.sin(a) * s, 0.55, 0.32, 0.02, 0.3, 0.95, 1, 1, 6, 1.5, 1, 1);
      else this.emit(x, y, z, Math.cos(a) * s, 1 + rnd() * 3, Math.sin(a) * s, 0.45, 0.24, 0.02, 1, 0.82, 0.25, 1, 7, 1.5, 1, 1);
    }
    this.emit(x, y, z, 0, 0, 0, 0.25, 0.2, 0.9, rare ? 0.3 : 1, rare ? 0.95 : 0.85, rare ? 1 : 0.3, 0.9, 0, 0, 3, 1);
  }
  ring(x, y, z, r, g, b, size = 1.6, life = 0.5) { this.emit(x, y, z, 0, 0, 0, life, 0.3, size, r, g, b, 0.9, 0, 0, 3, 1); }
  dust(x, y, z, speed) {
    const t = this.trail;
    this.emit(x + (rnd() - 0.5) * 0.4, y + 0.08, z + 0.2, (rnd() - 0.5) * 1.2, 0.5 + rnd() * 0.8, speed * 0.16, 0.55 + rnd() * 0.25, 0.14, 0.55, t.r, t.g, t.b, 0.55, -0.4, 1.5, t.shape, t.add);
  }
  jumpDust(x, y, z) {
    const t = this.trail;
    for (let i = 0; i < 10; i++) { const a = (i / 10) * 6.28, s = 2 + rnd() * 1.5; this.emit(x + Math.cos(a) * 0.3, y + 0.1, z + Math.sin(a) * 0.3, Math.cos(a) * s, 0.5 + rnd(), Math.sin(a) * s, 0.55, 0.2, 0.7, t.r, t.g, t.b, 0.6, -0.5, 2, 0, 0); }
  }
  hit(x, y, z) {
    for (let i = 0; i < 26; i++) { const a = rnd() * 6.28, e = rnd() * 3.14 - 0.4, s = 4 + rnd() * 8; this.emit(x, y, z, Math.cos(a) * Math.cos(e) * s, Math.sin(e) * s + 2, Math.sin(a) * Math.cos(e) * s, 0.6 + rnd() * 0.4, 0.3, 0.02, 1, 0.5 + rnd() * 0.4, 0.15, 1, 14, 0.8, 1, 1); }
    for (let i = 0; i < 10; i++) { const a = rnd() * 6.28, s = 2 + rnd() * 4; this.emit(x, y, z, Math.cos(a) * s, 1 + rnd() * 3, Math.sin(a) * s, 0.9, 0.3, 1.4, 0.3, 0.25, 0.22, 0.6, -1, 1.2, 0, 0); }
    this.emit(x, y, z, 0, 0, 0, 0.35, 0.5, 4, 1, 0.8, 0.5, 0.9, 0, 0, 3, 1);
  }
  debris(x, y, z, c, n = 14) {
    for (let i = 0; i < n; i++) { const a = rnd() * 6.28, s = 3 + rnd() * 7; this.emit(x + (rnd() - 0.5), y + rnd() * 1.2, z + (rnd() - 0.5), Math.cos(a) * s, 2 + rnd() * 6, Math.sin(a) * s - 6, 0.9 + rnd() * 0.5, 0.22, 0.12, c[0], c[1], c[2], 1, 20, 0.4, 2, 0); }
  }
  shieldBreak(x, y, z) {
    for (let i = 0; i < 24; i++) { const a = rnd() * 6.28, e = rnd() * 2 - 1, s = 5 + rnd() * 5; this.emit(x, y, z, Math.cos(a) * s, e * s, Math.sin(a) * s, 0.6, 0.35, 0.02, 0.35, 0.8, 1, 1, 0, 1.5, 1, 1); }
    this.ring(x, y, z, 0.4, 0.85, 1, 3.5, 0.5);
  }
  shieldTick(x, y, z) { const a = rnd() * 6.28; this.emit(x + Math.cos(a) * 0.9, y + 0.6 + rnd() * 1.1, z + Math.sin(a) * 0.9, 0, 0.6, 0, 0.5, 0.18, 0.02, 0.4, 0.85, 1, 0.9, 0, 0, 1, 1); }
  magnetTick(px, py, pz, R) {
    const a = rnd() * 6.28, d = R * (0.6 + rnd() * 0.4), sx = px + Math.cos(a) * d, sz = pz + Math.sin(a) * d * 0.7 - 2, sy = py + 0.6 + rnd() * 1.3;
    const k = 5.5; this.emit(sx, sy, sz, (px - sx) * k * 0.9, (py + 1 - sy) * k * 0.9, (pz - sz) * k * 0.9, 0.34, 0.26, 0.05, rnd() > 0.5 ? 1 : 0.3, 0.4, rnd() > 0.5 ? 0.3 : 1, 0.9, 0, 0, 1, 1);
  }
  boostTick(x, y, z, big = 1) {
    this.emit(x + (rnd() - 0.5) * 0.3, y + 0.3 + rnd() * 0.9, z + 0.5, (rnd() - 0.5) * 1.2, (rnd() - 0.5) * 1.2, 8 + rnd() * 8, 0.32, 0.36 * big, 0.04, 1, 0.55 + rnd() * 0.3, 0.12, 0.9, 0, 0.5, 0, 1);
  }
  pickupBurst(x, y, z, r, g, b) {
    this.ring(x, y, z, r, g, b, 3, 0.6);
    for (let i = 0; i < 14; i++) { const a = rnd() * 6.28, s = 2 + rnd() * 4; this.emit(x, y, z, Math.cos(a) * s, rnd() * 4, Math.sin(a) * s, 0.7, 0.3, 0.02, r, g, b, 1, 4, 1, 1, 1); }
  }
  landPuff(x, y, z) { const t = this.trail; for (let i = 0; i < 6; i++) { const a = rnd() * 6.28; this.emit(x, y + 0.1, z, Math.cos(a) * 2.4, 0.4, Math.sin(a) * 2.4, 0.4, 0.2, 0.55, t.r, t.g, t.b, 0.5, -0.3, 2, 0, 0); } }
  /** Ambient world particles around the camera. kind: 'mote' | 'firefly' | 'sand' | 'ember' */
  ambient(kind, cx, cy, cz, spread = 16) {
    const x = cx + (rnd() - 0.5) * spread * 2, y = 0.3 + rnd() * 5, z = cz - 4 - rnd() * 60;
    if (kind === 'mote') this.emit(x, y, z, (rnd() - 0.5) * 0.4, 0.15, 0.6, 3, 0.05, 0.05, 1, 0.95, 0.75, 0.55, 0, 0, 0, 1);
    else if (kind === 'firefly') this.emit(x, y * 0.6 + 0.4, z, (rnd() - 0.5) * 0.8, (rnd() - 0.5) * 0.5, (rnd() - 0.5) * 0.8, 3, 0.11, 0.11, 0.85, 1, 0.35, 0.95, 0, 0, 0, 1);
    else if (kind === 'sand') this.emit(x + 14, y, z, -26 - rnd() * 12, (rnd() - 0.5) * 0.6, 6, 0.9, 0.12, 0.5, 0.86, 0.66, 0.42, 0.42, 0, 0, 0, 0);
    else if (kind === 'ember') this.emit(x, y * 0.4, z, (rnd() - 0.5) * 0.6, 1.2 + rnd(), 1, 2.4, 0.07, 0.03, 1, 0.6, 0.25, 0.85, 0, 0, 0, 1);
  }
}
