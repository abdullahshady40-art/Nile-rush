import { ICON, POWER_ICON } from './icons.js';
import { POWERUPS } from '../characters/CharacterData.js';
import { fmt } from '../core/Utils.js';

const CHIPS = [
  ...Object.keys(POWERUPS).map((id) => ({ id, icon: POWER_ICON[id], color: POWERUPS[id].color })),
  { id: 'board', icon: ICON.board, color: [0.4, 0.85, 1] }, { id: 'headStart', icon: ICON.dash, color: [1, 0.7, 0.2] }, { id: 'scoreBoost', icon: ICON.double, color: [1, 0.85, 0.3] },
];
const rgb = (c) => `rgb(${(c[0] * 255) | 0},${(c[1] * 255) | 0},${(c[2] * 255) | 0})`;

/** In-game HUD. DOM nodes are created once; values are only written when they change. */
export class Hud {
  constructor(ui, el) {
    this.ui = ui; this.el = el; this.cache = {};
    el.innerHTML = `
      <div class="hud-top">
        <div class="hud-score"><div class="s" id="h-score">0</div><div class="b">Best <span id="h-best">0</span></div></div>
        <div class="hud-mid"><span id="h-dist">0</span> m<small>Distance</small></div>
        <div class="hud-right"><div class="row"><div class="hud-coins" id="h-coinbox">${ICON.coin}<span id="h-coins">0</span></div><button class="hud-pause" id="h-pause" aria-label="Pause">${ICON.pause}</button></div></div>
      </div>
      <div class="combo" id="h-combo"><b id="h-cx">x1</b><div class="bar"><i id="h-cbar"></i></div></div>
      <div class="hud-side" id="h-side">${CHIPS.map((c) => `<div class="pu" id="pu-${c.id}" style="--c:${rgb(c.color)}"><span class="i">${c.icon}</span><div class="bar"><i></i></div></div>`).join('')}</div>
      <div class="popups" id="h-pop"></div>
      <div class="hud-bottom">
        <div class="pad" id="h-pad"><button class="u" data-p="jump" aria-label="Jump">${ICON.up}</button><button class="l" data-p="left" aria-label="Move left">${ICON.left}</button><button class="d" data-p="slide" aria-label="Slide">${ICON.down}</button><button class="r" data-p="right" aria-label="Move right">${ICON.right}</button></div>
        <div style="flex:1"></div>
        <div style="display:flex;gap:.8em;align-items:flex-end">
          <button class="act" id="h-board" aria-label="Nile Board">${ICON.board}<span class="cnt" id="h-bcnt">0</span><span class="ring" id="h-bring"></span></button>
          <button class="act" id="h-dash" aria-label="Dash">${ICON.dash}<span class="ring" id="h-dring"></span></button>
        </div>
      </div>`;
    const $ = (id) => el.querySelector('#' + id);
    this.n = { score: $('h-score'), best: $('h-best'), dist: $('h-dist'), coins: $('h-coins'), coinbox: $('h-coinbox'), combo: $('h-combo'), cx: $('h-cx'), cbar: $('h-cbar'), pop: $('h-pop'), board: $('h-board'), bcnt: $('h-bcnt'), bring: $('h-bring'), dash: $('h-dash'), dring: $('h-dring') };
    this.chips = {}; for (const c of CHIPS) { const n = $('pu-' + c.id); this.chips[c.id] = { el: n, bar: n.querySelector('i'), on: false }; }
    const g = ui.game;
    $('h-pause').addEventListener('pointerdown', (e) => { e.preventDefault(); g.pause(); });
    this.n.dash.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); g.tryDash(); });
    this.n.board.addEventListener('pointerdown', (e) => { e.preventDefault(); e.stopPropagation(); g.tryBoard(); });
    $('h-pad').addEventListener('pointerdown', (e) => {
      const b = e.target.closest('button'); if (!b) return; e.preventDefault(); e.stopPropagation();
      const p = g.player, k = b.dataset.p; if (g.state !== 'playing') return;
      if (k === 'left') p.left(); else if (k === 'right') p.right(); else if (k === 'jump') p.jump(); else p.slide();
    });
  }
  reset() { this.cache = {}; for (const k in this.chips) { this.chips[k].on = false; this.chips[k].el.classList.remove('on'); } this.n.pop.innerHTML = ''; this.n.combo.classList.remove('on'); }
  _set(k, node, v, txt) { if (this.cache[k] !== v) { this.cache[k] = v; node.textContent = txt === undefined ? v : txt; } }

  update(run, p, boardCharges) {
    const d = this.ui.game.save.data, n = this.n;
    this._set('s', n.score, Math.floor(run.score), fmt(run.score));
    this._set('b', n.best, Math.max(d.highScore, Math.floor(run.score)), fmt(Math.max(d.highScore, run.score)));
    this._set('d', n.dist, Math.floor(run.dist), fmt(run.dist));
    this._set('c', n.coins, run.coins, fmt(run.coins));
    const combo = run.combo > 1 || run.chain > 2;
    if (this.cache.co !== combo) { this.cache.co = combo; n.combo.classList.toggle('on', combo); }
    this._set('cx', n.cx, run.combo, 'x' + run.combo);
    const cf = Math.round(run.comboFrac * 100); if (this.cache.cf !== cf) { this.cache.cf = cf; n.cbar.style.width = cf + '%'; }
    const src = { ...run.timers, shield: run.shield > 0 ? run.timers.shield : 0, board: run.boardActive ? run.boardT : 0, headStart: run.headStart, scoreBoost: run.scoreBoost };
    const tot = { board: run.board.duration, headStart: 8, scoreBoost: 45 };
    for (const id in this.chips) {
      const c = this.chips[id], v = src[id] || 0, on = v > 0;
      if (c.on !== on) { c.on = on; c.el.classList.toggle('on', on); }
      if (on) { const w = Math.round(Math.min(1, v / (tot[id] || run.duration(id))) * 50) * 2; if (c.w !== w) { c.w = w; c.bar.style.width = w + '%'; } }
    }
    const dr = Math.round(run.dash), ready = dr >= 100;
    if (this.cache.dr !== dr) { this.cache.dr = dr; n.dring.style.setProperty('--p', dr); n.dash.classList.toggle('ready', ready); }
    const bc = run.boardActive ? Math.round(run.boardT / run.board.duration * 100) : 0;
    if (this.cache.bc !== bc) { this.cache.bc = bc; n.bring.style.setProperty('--p', bc); }
    this._set('bn', n.bcnt, boardCharges);
    const vg = run.speed > 26 || p.dashT > 0; if (this.cache.vg !== vg) { this.cache.vg = vg; this.ui.vignette.classList.toggle('on', vg); }
  }
  popup(text) {
    const el = document.createElement('div'); el.className = 'pop'; el.textContent = text; this.n.pop.appendChild(el);
    el.addEventListener('animationend', () => el.remove()); while (this.n.pop.children.length > 3) this.n.pop.firstChild.remove();
  }
  coinBump() { const b = this.n.coinbox; b.classList.add('bump'); clearTimeout(this._bt); this._bt = setTimeout(() => b.classList.remove('bump'), 90); }
  flashDash() { const b = this.n.dash; b.classList.remove('shake'); void b.offsetWidth; b.classList.add('shake'); }
}
