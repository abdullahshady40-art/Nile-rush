// The NILE RUSH logotype, drawn as SVG paths (no font dependency): angular carved letters,
// a sun disc over the river and Nile waves underneath.
const G = {
  N: ['M0 60V0L40 60V0', 40], I: ['M0 0V60', 0], L: ['M0 0V60H34', 34], E: ['M34 0H0V60H34M0 30H26', 34],
  R: ['M0 60V0H30L40 10V22L30 32H0M18 32L40 60', 40], U: ['M0 0V48L12 60H28L40 48V0', 40],
  S: ['M40 6L34 0H6L0 6V24L6 30H34L40 36V54L34 60H6L0 54', 40], H: ['M0 0V60M40 0V60M0 30H40', 40],
};
function word(str, x0, y0) {
  let x = x0, out = '';
  for (const ch of str) { const [d, w] = G[ch]; out += `<path transform="translate(${x} ${y0})" d="${d}"/>`; x += w + 24; }
  return { paths: out, width: x - 24 - x0 };
}
let uid = 0;
export function logoSVG(cls = '') {
  const id = 'lg' + uid++;
  const a = word('NILE', 0, 0), b = word('RUSH', 0, 84);
  const W = 232, ox = (W - a.width) / 2;
  const nile = word('NILE', ox + 14, 30).paths, rush = word('RUSH', 14, 116).paths;
  return `<svg class="logo ${cls}" viewBox="0 0 ${W + 28} 214" role="img" aria-label="NILE RUSH" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff0b8"/><stop offset=".45" stop-color="#f7c948"/><stop offset="1" stop-color="#c47f14"/></linearGradient>
    <linearGradient id="${id}s" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#1fb5aa"/><stop offset="1" stop-color="#7ae9dd"/></linearGradient>
  </defs>
  <g fill="none" stroke-linejoin="miter" stroke-linecap="butt">
    <g stroke="#0a1230" stroke-width="27" transform="translate(4 6)" opacity=".55">${nile}${rush}</g>
    <g stroke="#0a1230" stroke-width="26">${nile}${rush}</g>
    <g stroke="url(#${id}g)" stroke-width="15">${nile}${rush}</g>
    <g stroke="#fff6d2" stroke-width="2.6" opacity=".7" transform="translate(-3 -3)">${nile}${rush}</g>
  </g>
  <circle cx="${ox + 14 + 62 + 24}" cy="14" r="10" fill="#e8552e" stroke="#0a1230" stroke-width="4"/>
  <circle cx="${ox + 14 + 62 + 24}" cy="14" r="4.5" fill="#ffd27a"/>
  <path d="M14 196q13-12 26 0t26 0 26 0 26 0 26 0 26 0 26 0 26 0" fill="none" stroke="#0a1230" stroke-width="9" stroke-linecap="round"/>
  <path d="M14 196q13-12 26 0t26 0 26 0 26 0 26 0 26 0 26 0 26 0" fill="none" stroke="url(#${id}s)" stroke-width="5" stroke-linecap="round"/>
</svg>`;
}
export const EMBLEM = `<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="30" fill="#0f1f4b" stroke="#f2b84b" stroke-width="3"/><circle cx="32" cy="24" r="8" fill="#e8552e"/><path d="M10 46 32 20l22 26z" fill="#f2b84b"/><path d="M10 50q7-6 11 0t11 0 11 0 11 0" fill="none" stroke="#22c3b4" stroke-width="3" stroke-linecap="round"/></svg>`;
