import { ICON } from './icons.js';
import { logoSVG } from './logo.js';
import { Hud } from './Hud.js';
import { fmt } from '../core/Utils.js';
import { CHARACTERS, getCharacter, BOOSTS } from '../characters/CharacterData.js';
import { Panels } from './screens/Panels.js';

const NAMES = ['splash', 'intro', 'menu', 'chars', 'missions', 'achievements', 'shop', 'settings', 'credits', 'tutorial', 'hud', 'pause', 'over', 'modal'];
const SUB = ['chars', 'missions', 'achievements', 'shop', 'settings', 'credits'];
const CREDIT_AR = 'عبدالله شادي — مطور الفكرة', CREDIT_EN = 'Abdullah Shady — Original Idea Developer';
export { CREDIT_AR, CREDIT_EN };

/** DOM interface layer: creates every screen once, routes clicks through data-act attributes. */
export class UI {
  constructor(game, root) {
    this.game = game; this.root = root; this.current = ''; this.returnTo = null; this.installEvt = null; this.tutStep = 0; this.charIdx = 0; this.shopTab = 'characters';
    root.innerHTML = '';
    this.vignette = Object.assign(document.createElement('div'), { className: 'vignette' }); root.parentElement.insertBefore(this.vignette, root);
    this.screens = {};
    for (const n of NAMES) { const s = document.createElement('section'); s.className = 'screen'; s.id = 'screen-' + n; s.setAttribute('aria-label', n); root.appendChild(s); this.screens[n] = s; }
    this.toasts = Object.assign(document.createElement('div'), { id: 'toasts', 'aria-live': 'polite' }); root.appendChild(this.toasts);
    this.ann = Object.assign(document.createElement('div'), { id: 'announce' }); root.appendChild(this.ann);
    this.panels = new Panels(this);
    this._buildSplash(); this._buildMenu(); this._buildPause(); this.hud = new Hud(this, this.screens.hud); this.screens.hud.classList.add('passthrough');
    root.addEventListener('click', (e) => this._click(e));
    root.addEventListener('input', (e) => this.panels.onInput(e));
    this.applyBodyClasses();
  }

  applyBodyClasses() { document.body.classList.toggle('buttons', !!this.game.save.data.settings.touchButtons); }
  get save() { return this.game.save; }
  get audio() { return this.game.audio; }
  sfx(n) { this.audio.sfx(n); }

  // -------------------------------------------------------------- screen management
  show(name, data) {
    for (const n of NAMES) this.screens[n].classList.toggle('active', n === name || (name === 'pause' && n === 'hud') || (name === 'over' && false));
    if (name === 'modal') this.screens.modal.classList.add('active');
    this.current = name;
    const g = this.game;
    document.getElementById('touch').classList.toggle('on', name === 'hud');
    if (name !== 'hud' && name !== 'pause') this.vignette.classList.remove('on');
    switch (name) {
      case 'splash': break;
      case 'intro': this._buildIntro(); break;
      case 'menu': g.setLayout('menu'); this.refreshMenu(); break;
      case 'chars': g.setLayout('chars'); this.panels.showChars(); break;
      case 'missions': case 'achievements': case 'shop': case 'settings': case 'credits': g.setLayout('none'); this.panels.render(name); break;
      case 'tutorial': this.tutStep = 0; this.panels.renderTutorial(); break;
      case 'over': this.panels.renderOver(data); break;
      case 'pause': this.panels.renderPause ? this.panels.renderPause() : 0; break;
      default: break;
    }
  }
  open(name) { this.sfx('click'); this.returnTo = this.current === 'pause' ? 'pause' : null; this.show(name); }
  back() {
    const c = this.current;
    if (SUB.includes(c)) { this.sfx('back'); const t = this.returnTo || 'menu'; this.returnTo = null; if (t === 'pause') { this.show('pause'); } else this.show(t); }
    else if (c === 'tutorial') this.act('tut-skip');
    else if (c === 'intro') this.game.endIntro();
    else if (c === 'modal') this.closeModal();
  }
  toast(text, kind = '') {
    const t = document.createElement('div'); t.className = 'toast ' + kind; t.textContent = text; this.toasts.appendChild(t);
    t.addEventListener('animationend', () => t.remove()); while (this.toasts.children.length > 3) this.toasts.firstChild.remove();
  }
  announce(en, ar) { this.ann.innerHTML = `<div class="en">${en}</div><div class="ar">${ar}</div>`; this.ann.classList.remove('on'); void this.ann.offsetWidth; this.ann.classList.add('on'); }
  modal(title, text, okLabel, onOk, danger = false) {
    this._modalOk = onOk;
    this.screens.modal.innerHTML = `<div class="dialog" role="dialog" aria-modal="true"><h2>${title}</h2><p>${text}</p><button class="btn ${danger ? 'danger' : 'primary'}" data-act="modal-ok">${okLabel}</button><button class="btn" data-act="modal-cancel">Cancel</button></div>`;
    this.screens.modal.classList.add('active');
  }
  closeModal() { this.screens.modal.classList.remove('active'); this.screens.modal.innerHTML = ''; }

  // -------------------------------------------------------------- static screens
  _buildSplash() {
    this.screens.splash.innerHTML = `${logoSVG()}<div class="loadbar" id="s-bar"><i></i></div><div class="splash-note" id="s-note">Loading…</div><button class="btn primary" id="s-start" data-act="start" style="display:none">${ICON.play} Tap to start</button>`;
    this.show('splash');
  }
  setProgress(p) { const b = this.screens.splash.querySelector('#s-bar i'); if (b) b.style.width = Math.round(p * 100) + '%'; }
  splashReady() {
    this.screens.splash.querySelector('#s-bar').style.display = 'none';
    this.screens.splash.querySelector('#s-note').textContent = 'Best with sound on. Swipe or use the arrow keys to run.';
    const b = this.screens.splash.querySelector('#s-start'); b.style.display = ''; b.focus();
  }
  splashError(msg) {
    this.screens.splash.querySelector('#s-bar').style.display = 'none';
    const n = this.screens.splash.querySelector('#s-note'); n.className = 'splash-note err'; n.textContent = msg;
  }

  _buildIntro() {
    this.screens.intro.innerHTML = `
      <div class="black"></div>
      <div class="card c1">${logoSVG()}</div>
      <div class="card c2"><div class="rule"></div><div class="ar" lang="ar">${CREDIT_AR.split(' — ')[0]} — ${CREDIT_AR.split(' — ')[1]}</div></div>
      <div class="card c3"><div class="en">${CREDIT_EN}</div><div class="rule"></div></div>
      <div class="lower"><div class="ar" lang="ar">${CREDIT_AR}</div><div class="en">${CREDIT_EN}</div></div>
      <button class="btn skip small" data-act="skip" style="pointer-events:auto">Skip ${ICON.right}</button>`;
  }

  _buildMenu() {
    this.screens.menu.innerHTML = `
      <div class="menu-top"><div>${logoSVG()}</div>
        <div class="menu-stats"><div class="wallet">${ICON.coin}<span id="m-coins">0</span></div><div class="wallet" style="font-size:.85em">${ICON.crown}<span id="m-best">0</span></div>
        <button class="btn small" id="m-install" data-act="install" style="display:none">${ICON.install} Install</button></div></div>
      <div class="menu-body"><div class="nav">
        <div class="who" id="m-who"></div>
        <div class="loadout" id="m-load"></div>
        <button class="btn primary play" data-act="play">${ICON.play} Play</button>
        <div class="row"><button class="btn" data-act="open" data-to="chars">${ICON.person} Characters</button><button class="btn" data-act="open" data-to="missions">${ICON.missions} Missions<span class="badge" id="m-mbadge" style="display:none">0</span></button></div>
        <div class="row"><button class="btn" data-act="open" data-to="achievements">${ICON.trophy} Achievements</button><button class="btn" data-act="open" data-to="shop">${ICON.shop} Shop</button></div>
        <div class="row"><button class="btn" data-act="open" data-to="settings">${ICON.gear} Settings</button><button class="btn" data-act="open" data-to="credits">${ICON.crown} Credits</button></div>
      </div></div>`;
  }
  refreshMenu() {
    const d = this.save.data, m = this.screens.menu, g = this.game;
    m.querySelector('#m-coins').textContent = fmt(d.coins); m.querySelector('#m-best').textContent = fmt(d.highScore);
    const c = getCharacter(d.selectedChar); m.querySelector('#m-who').innerHTML = `<b>${c.name}</b><span class="muted">${c.title}</span>`;
    const nb = g.missions.claimable(), b = m.querySelector('#m-mbadge'); b.style.display = nb ? '' : 'none'; b.textContent = nb;
    const inv = d.inventory, L = g.loadout, box = m.querySelector('#m-load');
    box.innerHTML = [['headStart', 'Head Start', ICON.dash], ['scoreBooster', 'Score Booster', ICON.double]].map(([k, n, i]) => `<button class="chip ${L[k] && inv[k] > 0 ? 'on' : ''}" data-act="loadout" data-k="${k}" ${inv[k] > 0 ? '' : 'disabled'} title="${inv[k] > 0 ? 'Use on next run' : 'Buy in the Shop'}">${i}${n} <span class="muted">×${inv[k]}</span></button>`).join('');
    this.setInstallVisible(!!this.installEvt || this._iosInstall());
  }
  _iosInstall() { const ua = navigator.userAgent; return /iPad|iPhone|iPod/.test(ua) && !window.navigator.standalone && !matchMedia('(display-mode: standalone)').matches; }
  setInstallVisible() {
    const on = (!!this.installEvt || this._iosInstall()) && !matchMedia('(display-mode: standalone)').matches;
    const b = this.screens.menu.querySelector('#m-install'); if (b) b.style.display = on ? '' : 'none';
    this.panels.refreshInstall && this.panels.refreshInstall(on);
  }
  install() {
    if (this.installEvt) { const e = this.installEvt; this.installEvt = null; e.prompt(); e.userChoice.finally(() => this.setInstallVisible()); }
    else if (this._iosInstall()) this.modal('Install NILE RUSH', 'In Safari tap the Share button, then “Add to Home Screen” to install the game as an app.', 'Got it', () => {});
  }

  _buildPause() {
    this.screens.pause.innerHTML = `<div class="dialog"><h2>Paused</h2>
      <button class="btn primary" data-act="resume">${ICON.play} Resume</button>
      <button class="btn" data-act="restart">Restart</button>
      <button class="btn" data-act="open" data-to="settings">${ICON.gear} Settings</button>
      <button class="btn" data-act="menu">Main menu</button></div>`;
  }

  // -------------------------------------------------------------- click routing
  _click(e) {
    const t = e.target.closest('[data-act]'); if (!t || t.disabled) return;
    this.audio.unlock(); this.act(t.dataset.act, t.dataset, t);
  }
  act(a, d = {}, el) {
    const g = this.game;
    switch (a) {
      case 'start': g.audio.decodeOverrides(g.assets.audioRaw.sfx, g.assets.audioRaw.music); this.sfx('select'); g.startIntro(); break;
      case 'skip': this.sfx('click'); g.endIntro(); break;
      case 'play': this.sfx('select'); g.requestPlay(); break;
      case 'open': this.open(d.to); break;
      case 'back': this.back(); break;
      case 'loadout': this.sfx('click'); g.loadout[d.k] = !g.loadout[d.k]; this.refreshMenu(); break;
      case 'install': this.install(); break;
      case 'resume': g.resume(); break;
      case 'restart': this.sfx('click'); g.restart(); break;
      case 'menu': this.sfx('click'); if (g.state === 'over') g.goMenu(); else g.quitToMenu(); break;
      case 'retry': this.sfx('select'); g.restart(); break;
      case 'modal-ok': { const f = this._modalOk; this.closeModal(); f && f(); break; }
      case 'modal-cancel': this.sfx('back'); this.closeModal(); break;
      default: this.panels.act(a, d, el);
    }
  }
}
