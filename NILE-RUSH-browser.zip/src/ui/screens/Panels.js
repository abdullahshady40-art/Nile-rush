import { ICON, POWER_ICON } from '../icons.js';
import { logoSVG } from '../logo.js';
import { fmt } from '../../core/Utils.js';
import { CHARACTERS, SKINS, BOARDS, TRAILS, BOOSTS, POWERUPS, UPGRADEABLE, MAX_UPGRADE, upgradeCost, getCharacter } from '../../characters/CharacterData.js';
import { ACHIEVEMENTS } from '../../missions/Achievements.js';
import { QUALITY, CFG } from '../../core/Config.js';

const css = (c) => `rgb(${(c[0] * 255) | 0},${(c[1] * 255) | 0},${(c[2] * 255) | 0})`;
const wallet = (n) => `<div class="wallet" aria-label="Coins">${ICON.coin}<span class="wal">${fmt(n)}</span></div>`;
const top = (title, coins) => `<div class="topbar"><button class="btn icon" data-act="back" aria-label="Back">${ICON.back}</button><h2>${title}</h2>${wallet(coins)}</div>`;

export class Panels {
  constructor(ui) { this.ui = ui; }
  get g() { return this.ui.game; }
  get d() { return this.ui.game.save.data; }
  el(n) { return this.ui.screens[n]; }

  render(name) {
    ({ missions: () => this.renderMissions(), achievements: () => this.renderAch(), shop: () => this.renderShop(), settings: () => this.renderSettings(), credits: () => this.renderCredits() })[name]();
  }
  keepScroll(name, fn) { const s = this.el(name).querySelector('.scroll'), y = s ? s.scrollTop : 0; fn(); const n = this.el(name).querySelector('.scroll'); if (n) n.scrollTop = y; }

  // ------------------------------------------------------------------ characters
  showChars() { const i = CHARACTERS.findIndex((c) => c.id === this.d.selectedChar); this.ui.charIdx = Math.max(0, i); this.g.setPreview(CHARACTERS[this.ui.charIdx].id); this.renderChars(); }
  renderChars() {
    const d = this.d, c = CHARACTERS[this.ui.charIdx], owned = d.unlockedChars.includes(c.id), sel = d.selectedChar === c.id;
    const bar = (label, v) => `<div class="stat"><span>${label}</span><div class="bar"><i style="width:${v * 20}%"></i></div></div>`;
    let action;
    if (owned) action = sel ? `<button class="btn off" disabled>${ICON.check} Selected</button>` : `<button class="btn primary" data-act="char-select">Select</button>`;
    else if (c.unlock.type === 'coins') action = `<button class="btn primary ${d.coins < c.unlock.cost ? 'off' : ''}" data-act="char-unlock">${ICON.lock} Unlock · ${fmt(c.unlock.cost)} ${ICON.coin}</button>`;
    else action = `<button class="btn off" disabled>${ICON.lock} Run ${fmt(c.unlock.value)} m in one run · best ${fmt(d.bestDistance)} m</button>`;
    const unlockTxt = owned ? 'Unlocked' : c.unlock.type === 'coins' ? `Unlock with ${fmt(c.unlock.cost)} coins` : `Unlock: run ${fmt(c.unlock.value)} m in a single run`;
    const portrait = this.g.assets.images['char:' + c.id];
    this.el('chars').innerHTML = `${top('Characters', d.coins)}
      <div class="chars-panel">
        <div class="chars-head"><button class="btn icon" data-act="char-prev" aria-label="Previous character">${ICON.left}</button>
          <div class="nm">${portrait ? `<img src="${portrait}" alt="" style="height:3em;border-radius:.5em">` : ''}<b>${c.name}</b><span class="muted">${c.title}</span></div>
          <button class="btn icon" data-act="char-next" aria-label="Next character">${ICON.right}</button></div>
        <div class="hint">${c.desc}</div>
        ${bar('Speed', c.stats.speed)}${bar('Jump', c.stats.jump)}${bar('Magnet', c.stats.magnet)}${bar('Score', c.stats.score)}
        <div class="hint">${owned ? '' : ICON.lock + ' '}${unlockTxt}</div>
        <div class="skins" role="group" aria-label="Outfit">${SKINS.map((s) => { const o = d.ownedSkins.includes(s.id); return `<button class="dot ${d.selectedSkin === s.id ? 'on' : ''} ${o ? '' : 'lockd'}" style="background:${s.preview}" data-act="${o ? 'skin-equip' : 'skin-shop'}" data-id="${s.id}" aria-label="${s.name}${o ? '' : ' (locked)'}" title="${s.name}"></button>`; }).join('')}</div>
        ${action}
      </div>`;
  }

  // ------------------------------------------------------------------ missions
  renderMissions() {
    const M = this.g.missions, d = this.d;
    const rows = M.slots.map((s, i) => {
      const done = M.done(s), pct = Math.min(100, Math.floor(s.progress / s.target * 100));
      return `<div class="item ${done ? 'done' : ''}"><div class="ico">${done ? ICON.check : ICON.missions}</div>
        <div class="txt"><div class="t">${M.title(s)}</div><div class="bar"><i style="width:${pct}%"></i></div><div class="d">${fmt(s.progress)} / ${fmt(s.target)}</div></div>
        <div class="r"><span class="price">+${fmt(s.reward)} ${ICON.coin}</span>${done ? `<button class="btn small primary" data-act="claim" data-i="${i}">Claim</button>` : '<span class="d">In progress</span>'}</div></div>`;
    }).join('');
    this.keepScroll('missions', () => { this.el('missions').innerHTML = `${top('Missions', d.coins)}<div class="panel"><div class="scroll"><div class="list">${rows}</div><p class="hint" style="text-align:center;margin-top:1em">Missions completed: ${d.missions.completed}. Claimed missions are replaced by a harder one.</p></div></div>`; });
  }

  // ------------------------------------------------------------------ achievements
  renderAch() {
    const d = this.d, A = this.g.achievements;
    const rows = ACHIEVEMENTS.map((a) => { const u = A.isUnlocked(a.id); return `<div class="item ${u ? 'done' : 'locked'}"><div class="ico">${u ? ICON.trophy : ICON.lock}</div><div class="txt"><div class="t">${a.name}</div><div class="d">${a.desc}</div></div><div class="r"><span class="price">+${a.reward} ${ICON.coin}</span><span class="d">${u ? 'Unlocked' : 'Locked'}</span></div></div>`; }).join('');
    this.el('achievements').innerHTML = `${top('Achievements', d.coins)}<div class="panel"><div class="scroll"><div class="sec">${A.count()} / ${ACHIEVEMENTS.length} unlocked</div><div class="grid">${rows}</div></div></div>`;
  }

  // ------------------------------------------------------------------ shop
  renderShop() {
    const d = this.d, tab = this.ui.shopTab;
    const tabs = [['characters', 'Characters'], ['boards', 'Nile Boards'], ['skins', 'Skins'], ['boosts', 'Boosts'], ['trails', 'Cosmetics']];
    const price = (p) => `<span class="price">${fmt(p)} ${ICON.coin}</span>`;
    const btn = (kind, id, own, eq, p, label = 'Buy') => own ? (eq ? `<button class="btn small off" disabled>${ICON.check} Equipped</button>` : `<button class="btn small turq" data-act="equip" data-kind="${kind}" data-id="${id}">Equip</button>`) : `<button class="btn small primary ${d.coins < p ? 'off' : ''}" data-act="buy" data-kind="${kind}" data-id="${id}">${label} ${price(p)}</button>`;
    let body = '';
    if (tab === 'characters') body = CHARACTERS.map((c) => { const o = d.unlockedChars.includes(c.id); return `<div class="item ${o ? '' : 'locked'}"><div class="ico" style="background:${css(c.palette.top)};color:#fff">${c.name[0]}</div><div class="txt"><div class="t">${c.name} <span class="muted">· ${c.title}</span></div><div class="d">${c.desc}</div></div><div class="r">${c.unlock.type === 'coins' ? btn('char', c.id, o, d.selectedChar === c.id, c.unlock.cost) : o ? btn('char', c.id, true, d.selectedChar === c.id, 0) : `<span class="d">${ICON.lock} Run ${fmt(c.unlock.value)} m</span>`}</div></div>`; }).join('');
    else if (tab === 'boards') body = BOARDS.map((b) => { const o = d.ownedBoards.includes(b.id); return `<div class="item"><div class="ico" style="background:${css(b.color)}">${ICON.board}</div><div class="txt"><div class="t">${b.name}</div><div class="d">${b.desc} · ${b.duration}s</div></div><div class="r">${btn('board', b.id, o, d.selectedBoard === b.id, b.price)}</div></div>`; }).join('');
    else if (tab === 'skins') body = SKINS.map((s) => { const o = d.ownedSkins.includes(s.id); return `<div class="item"><div class="ico"><div class="swatch" style="background:${s.preview}"></div></div><div class="txt"><div class="t">${s.name}</div><div class="d">${s.desc}</div></div><div class="r">${btn('skin', s.id, o, d.selectedSkin === s.id, s.price)}</div></div>`; }).join('');
    else if (tab === 'trails') body = TRAILS.map((t) => { const o = d.ownedTrails.includes(t.id); return `<div class="item"><div class="ico"><div class="swatch" style="background:${t.preview}"></div></div><div class="txt"><div class="t">${t.name}</div><div class="d">${t.desc}</div></div><div class="r">${btn('trail', t.id, o, d.selectedTrail === t.id, t.price)}</div></div>`; }).join('');
    else {
      body = `<div class="sec">Consumables</div>` + BOOSTS.map((b) => `<div class="item"><div class="ico">${b.id === 'boardCharge' ? ICON.board : b.id === 'headStart' ? ICON.dash : ICON.double}</div><div class="txt"><div class="t">${b.name} <span class="muted">×${d.inventory[b.id]}</span></div><div class="d">${b.desc}</div></div><div class="r"><button class="btn small primary ${d.coins < b.price ? 'off' : ''}" data-act="buy" data-kind="boost" data-id="${b.id}">Buy ${price(b.price)}</button></div></div>`).join('')
        + `<div class="sec">Power-up upgrades</div>` + UPGRADEABLE.map((id) => { const p = POWERUPS[id], lvl = d.upgrades[id] || 0, max = lvl >= MAX_UPGRADE, cost = upgradeCost(lvl); return `<div class="item"><div class="ico">${POWER_ICON[id]}</div><div class="txt"><div class="t">${p.name}</div><div class="d">${p.desc} Lasts ${(p.base + p.step * lvl).toFixed(1).replace('.0', '')}s</div><div class="pips">${Array.from({ length: MAX_UPGRADE }, (_, i) => `<i class="${i < lvl ? 'on' : ''}"></i>`).join('')}</div></div><div class="r">${max ? '<span class="d">Max level</span>' : `<button class="btn small primary ${d.coins < cost ? 'off' : ''}" data-act="upgrade" data-id="${id}">Upgrade ${price(cost)}</button>`}</div></div>`; }).join('');
    }
    this.keepScroll('shop', () => { this.el('shop').innerHTML = `${top('Shop', d.coins)}<div class="panel"><div class="tabs" role="tablist">${tabs.map(([k, n]) => `<button class="tab ${k === tab ? 'on' : ''}" role="tab" data-act="shop-tab" data-id="${k}">${n}</button>`).join('')}</div><div class="scroll"><div class="${tab === 'boosts' ? 'list' : 'grid'}">${body}</div></div></div>`; });
  }
  buy(kind, id) {
    const d = this.d, g = this.g;
    const T = { char: [CHARACTERS.find((c) => c.id === id), 'unlockedChars', 'selectedChar', (x) => x.unlock.cost], board: [BOARDS.find((b) => b.id === id), 'ownedBoards', 'selectedBoard', (x) => x.price], skin: [SKINS.find((s) => s.id === id), 'ownedSkins', 'selectedSkin', (x) => x.price], trail: [TRAILS.find((t) => t.id === id), 'ownedTrails', 'selectedTrail', (x) => x.price] };
    let item, cost, done;
    if (kind === 'boost') { item = BOOSTS.find((b) => b.id === id); cost = item.price; done = () => { d.inventory[id]++; }; }
    else { const [it, own, sel, pf] = T[kind]; item = it; cost = pf(it); done = () => { if (!d[own].includes(id)) d[own].push(id); d[sel] = id; }; }
    if (!g.save.spend(cost)) { this.ui.sfx('error'); this.ui.toast('Not enough coins — collect ' + fmt(cost - d.coins) + ' more', 'warn'); return; }
    done(); g.stat('purchases', 1); g.save.save(); this.ui.sfx('buy'); this.ui.toast(item.name + (kind === 'boost' ? ' purchased' : ' unlocked'), 'good');
    if (kind === 'char') g.setPreview(id);
    this.rerender();
  }
  rerender() { const c = this.ui.current; if (c === 'shop') this.renderShop(); else if (c === 'chars') this.renderChars(); }

  // ------------------------------------------------------------------ settings
  renderSettings() {
    const s = this.d.settings, g = this.g, q = g.quality.label.toLowerCase();
    const seg = (k, opts, cur) => `<div class="seg" role="group">${opts.map(([v, n]) => `<button class="${cur === v ? 'on' : ''}" data-act="set" data-k="${k}" data-v="${v}">${n}</button>`).join('')}</div>`;
    const tog = (k, on, label) => `<button class="tog ${on ? 'on' : ''}" role="switch" aria-checked="${on}" aria-label="${label}" data-act="toggle" data-k="${k}"></button>`;
    const fs = document.fullscreenEnabled;
    const paused = g.state === 'paused';
    this.keepScroll('settings', () => { this.el('settings').innerHTML = `${top('Settings', this.d.coins)}<div class="panel"><div class="scroll">
      <div class="sec">Audio</div>
      <div class="set"><label for="s-music">Music volume</label><input class="range" id="s-music" type="range" min="0" max="1" step="0.05" value="${s.music}" data-set="music"></div>
      <div class="set"><label for="s-sfx">Effects volume</label><input class="range" id="s-sfx" type="range" min="0" max="1" step="0.05" value="${s.sfx}" data-set="sfx"></div>
      <div class="set"><label>Mute all sound</label>${tog('mute', s.mute, 'Mute')}</div>
      <div class="sec">Graphics</div>
      <div class="set"><label>Quality</label>${seg('quality', [['low', 'Low'], ['medium', 'Medium'], ['high', 'High']], q)}</div>
      <div class="set"><label>Time of day</label>${seg('time', [['auto', 'Auto'], ['day', 'Day'], ['sunset', 'Sunset'], ['night', 'Night']], s.time)}</div>
      <div class="set"><label>Camera shake</label>${tog('shake', s.shake, 'Camera shake')}</div>
      <div class="sec">Controls</div>
      <div class="set"><label>On-screen arrow buttons</label>${tog('touchButtons', s.touchButtons, 'On-screen buttons')}</div>
      <div class="set"><label>Vibration</label>${tog('vibration', s.vibration, 'Vibration')}</div>
      <div class="hint">Keyboard: ← → move · ↑ / Space jump · ↓ slide · Shift dash · B Nile Board · P pause. Touch: swipe, double-tap to dash.</div>
      <div class="sec">Game</div>
      <div class="set" id="set-install-row" style="display:none"><label>Install as app</label><button class="btn small" id="set-install" data-act="install">${ICON.install} Install</button></div>
      ${fs ? `<div class="set"><label>Fullscreen</label><button class="btn small" data-act="fullscreen">${ICON.fullscreen} Toggle</button></div>` : ''}
      <div class="set"><label>Tutorial</label><button class="btn small" data-act="replay-tut">Replay</button></div>
      ${paused ? '' : `<div class="set"><label>Intro</label><button class="btn small" data-act="watch-intro">Watch</button></div>`}
      <div class="set"><label>Progress</label><button class="btn small danger" data-act="reset">Reset all progress</button></div>
      <p class="hint" style="text-align:center">NILE RUSH v${CFG.version} · NileForge Engine</p></div></div>`; });
    this.ui.setInstallVisible();
  }
  refreshInstall(on) { const b = this.el('settings').querySelector('#set-install-row'); if (b) b.style.display = on ? '' : 'none'; }
  onInput(e) {
    const t = e.target; if (!t.dataset || !t.dataset.set) return;
    const s = this.d.settings, v = parseFloat(t.value); s[t.dataset.set] = v; this.g.applySettings(); this.g.save.saveSoon();
    if (t.dataset.set === 'sfx') { clearTimeout(this._st); this._st = setTimeout(() => this.ui.sfx('coin'), 120); }
  }

  renderCredits() {
    this.el('credits').innerHTML = `${top('Credits', this.d.coins)}<div class="panel"><div class="scroll"><div class="credits">
      ${logoSVG()}
      <div class="ar" lang="ar">عبدالله شادي — مطور الفكرة</div>
      <div class="en">Abdullah Shady — Original Idea Developer</div>
      <div class="eng">Powered by NileForge Engine</div>
      <p>NILE RUSH is an original endless runner. Every character, building, sign, sound effect and piece of music is created in code for this game — no assets from any other game were used.</p>
      <p>Built with HTML5, CSS3, JavaScript, WebGL 2 and the Web Audio API. Version ${CFG.version}.</p></div></div></div>`;
  }

  // ------------------------------------------------------------------ tutorial
  renderTutorial() {
    const step = this.ui.tutStep, touch = matchMedia('(pointer:coarse)').matches;
    const key = (k, ic, t, s) => `<div class="key"><span class="k">${ic}</span><span>${t}<small>${s}</small></span></div>`;
    const steps = [
      { h: 'Move, jump, slide', b: `<div class="keys">${key('l', ICON.left, 'Move', touch ? 'Swipe left' : '← or A')}${key('r', ICON.right, 'Move', touch ? 'Swipe right' : '→ or D')}${key('u', ICON.up, 'Jump', touch ? 'Swipe up' : '↑, W or Space')}${key('d', ICON.down, 'Slide', touch ? 'Swipe down' : '↓ or S')}</div><p class="hint">${touch ? 'Double-tap to Dash when the ring is full.' : 'Press Shift to Dash when the ring is full.'}</p>` },
      { h: 'Collect coins', b: `<div class="demo">${ICON.coin}${ICON.coin}${ICON.coin}</div><p>Grab coins for score, combos and Dash energy. Blue gems are worth 5. Spend coins in the Shop.</p>` },
      { h: 'Use power-ups', b: `<div class="demo">${POWER_ICON.magnet}${POWER_ICON.shield}${POWER_ICON.speed}${POWER_ICON.double}${POWER_ICON.multiplier}${POWER_ICON.invincible}</div><p>Magnet pulls coins. Shield survives a crash. Speed, Double Score and Coin ×2 boost your run. The golden ankh makes you unstoppable.</p>` },
      { h: 'Avoid obstacles', b: `<div class="demo">${ICON.up}${ICON.down}${ICON.left}${ICON.right}</div><p><b>Jump</b> low barriers and crates. <b>Slide</b> under beams and banners. <b>Change lane</b> for trains and carts. Close calls give Near Miss bonuses.</p>` },
    ];
    const s = steps[step], last = step === steps.length - 1;
    this.el('tutorial').innerHTML = `<div class="tut" role="dialog" aria-label="Tutorial"><h3>${s.h}</h3>${s.b}<div class="dots">${steps.map((_, i) => `<i class="${i === step ? 'on' : ''}"></i>`).join('')}</div>
      <div class="tut-row"><button class="btn small" data-act="tut-skip">Skip</button><button class="btn primary" data-act="tut-next">${last ? 'Start running' : 'Next'}</button></div></div>`;
    this.ui.tutLen = steps.length;
  }

  // ------------------------------------------------------------------ pause / game over
  renderPause() {}
  renderOver(r) {
    if (!r) r = { score: 0, best: this.d.highScore, coins: 0, dist: 0, unlocked: [], wallet: this.d.coins };
    const M = this.g.missions, list = M.slots.map((s, i) => ({ s, i, pct: s.progress / s.target })).sort((a, b) => (M.done(b.s) - M.done(a.s)) || b.pct - a.pct).slice(0, 3);
    const claim = M.claimable();
    this.el('over').innerHTML = `<div class="dialog" role="dialog" aria-label="Game over"><h2>Game over</h2>
      <div class="res"><div class="big"><small>Score${r.newBest ? '<span class="newbest">New best</span>' : ''}</small><b>${fmt(r.score)}</b></div>
        <div><small>Best</small><b>${fmt(r.best)}</b></div><div><small>Distance</small><b>${fmt(r.dist)} m</b></div>
        <div><small>Coins</small><b>${fmt(r.coins)}</b></div><div><small>Near misses</small><b>${fmt(r.near || 0)}</b></div></div>
      ${r.unlocked && r.unlocked.length ? `<div class="chip on">${ICON.crown} ${r.unlocked.join(', ')} unlocked!</div>` : ''}
      <div class="mini">${list.map(({ s }) => { const done = M.done(s); return `<div class="m">${done ? ICON.check + ' ' : ''}${M.title(s)}<div class="bar"><i style="width:${Math.min(100, s.progress / s.target * 100)}%"></i></div></div>`; }).join('')}</div>
      <button class="btn primary" data-act="retry">${ICON.play} Retry</button>
      ${claim ? `<button class="btn turq" data-act="open" data-to="missions">${ICON.missions} Claim ${claim} mission reward${claim > 1 ? 's' : ''}</button>` : ''}
      <button class="btn" data-act="menu">Main menu</button></div>`;
  }

  // ------------------------------------------------------------------ actions
  act(a, d, el) {
    const ui = this.ui, g = this.g, sv = g.save, data = sv.data;
    switch (a) {
      case 'char-prev': case 'char-next': { const n = CHARACTERS.length; ui.charIdx = (ui.charIdx + (a === 'char-next' ? 1 : n - 1)) % n; g.setPreview(CHARACTERS[ui.charIdx].id); ui.sfx('click'); this.renderChars(); break; }
      case 'char-select': { const c = CHARACTERS[ui.charIdx]; data.selectedChar = c.id; sv.save(); ui.sfx('select'); this.renderChars(); break; }
      case 'char-unlock': this.buy('char', CHARACTERS[ui.charIdx].id); break;
      case 'skin-equip': data.selectedSkin = d.id; sv.save(); ui.sfx('click'); this.renderChars(); break;
      case 'skin-shop': ui.shopTab = 'skins'; ui.sfx('click'); ui.returnTo = 'chars'; ui.show('shop'); break;
      case 'claim': { const r = g.missions.claim(+d.i); if (r) { ui.sfx('reward'); ui.toast('+' + fmt(r) + ' coins', 'gold'); } this.renderMissions(); break; }
      case 'shop-tab': ui.shopTab = d.id; ui.sfx('click'); this.renderShop(); break;
      case 'buy': this.buy(d.kind, d.id); break;
      case 'equip': { const k = { char: 'selectedChar', board: 'selectedBoard', skin: 'selectedSkin', trail: 'selectedTrail' }[d.kind]; data[k] = d.id; sv.save(); ui.sfx('select'); this.renderShop(); break; }
      case 'upgrade': { const lvl = data.upgrades[d.id] || 0, cost = upgradeCost(lvl); if (lvl >= MAX_UPGRADE) break; if (!sv.spend(cost)) { ui.sfx('error'); ui.toast('Not enough coins', 'warn'); break; } data.upgrades[d.id] = lvl + 1; sv.save(); ui.sfx('buy'); this.renderShop(); break; }
      case 'set': { data.settings[d.k] = d.v; g.applySettings(); sv.save(); ui.sfx('click'); this.renderSettings(); break; }
      case 'toggle': { data.settings[d.k] = !data.settings[d.k]; g.applySettings(); ui.applyBodyClasses(); g.rig.shakeScale = data.settings.shake ? 1 : 0; sv.save(); ui.sfx('click'); this.renderSettings(); break; }
      case 'fullscreen': { const de = document.documentElement; if (document.fullscreenElement) document.exitFullscreen(); else if (de.requestFullscreen) de.requestFullscreen().catch(() => {}); break; }
      case 'replay-tut': ui.sfx('click'); ui.returnTo = null; data.tutorialDone = false; sv.save(); ui.toast('Tutorial will show before your next run', 'good'); break;
      case 'watch-intro': ui.sfx('click'); g.startIntro(); break;
      case 'reset': ui.modal('Reset progress?', 'All coins, unlocks, missions, achievements and high scores will be erased. This cannot be undone.', 'Erase everything', () => { sv.reset(); g.missions.ensure(); g.applySettings(); g.rig.shakeScale = 1; ui.applyBodyClasses(); ui.toast('Progress reset', 'warn'); g.goMenu(); }, true); break;
      case 'tut-next': ui.sfx('click'); if (ui.tutStep >= (ui.tutLen || 4) - 1) { data.tutorialDone = true; sv.save(); g.startRun(); } else { ui.tutStep++; this.renderTutorial(); } break;
      case 'tut-skip': data.tutorialDone = true; sv.save(); ui.sfx('click'); g.startRun(); break;
      default: break;
    }
  }
}
