import { loadGLTF } from '../rendering/GLTFLoader.js';

/**
 * Loads optional user assets described in assets/assets.json. Everything is optional: if a file is
 * missing the game falls back to its procedural art and synthesised audio.
 * Supported: .glb .gltf (models), .png .jpg .webp (images), .mp3 .wav .webm (audio).
 */
export class AssetManager {
  constructor(renderer) { this.r = renderer; this.config = { models: {}, images: {}, audio: {} }; this.images = {}; this.models = { characters: {}, boards: {} }; this.audioRaw = { sfx: {}, music: {} }; this.report = []; }

  async _json(url) { try { const r = await fetch(url, { cache: 'no-cache' }); if (!r.ok) return null; return await r.json(); } catch (e) { return null; } }
  async _bin(url) { try { const r = await fetch(url); return r.ok ? await r.arrayBuffer() : null; } catch (e) { return null; } }
  async _img(url) {
    try { const r = await fetch(url); if (!r.ok) return null; return await createImageBitmap(await r.blob()); } catch (e) { return null; }
  }

  async init(progress = () => {}) {
    const cfg = await this._json('assets/assets.json'); if (cfg) this.config = { models: {}, images: {}, audio: {}, ...cfg };
    const jobs = [];
    const chars = (this.config.models && this.config.models.characters) || {};
    for (const [id, spec] of Object.entries(chars)) {
      const s = typeof spec === 'string' ? { file: spec } : spec; if (!s.file) continue;
      jobs.push(loadGLTF(this.r, 'assets/models/' + s.file, s).then((m) => { this.models.characters[id] = m; this.report.push('model:' + id); }).catch((e) => console.warn('[assets] model failed', id, e.message)));
    }
    const boards = (this.config.models && this.config.models.boards) || {};
    for (const [id, spec] of Object.entries(boards)) {
      const s = typeof spec === 'string' ? { file: spec } : spec; if (!s.file) continue;
      jobs.push(loadGLTF(this.r, 'assets/models/' + s.file, { height: 0.5, ...s }).then((m) => { this.models.boards[id] = m; this.report.push('board:' + id); }).catch((e) => console.warn('[assets] board failed', id, e.message)));
    }
    const imgs = this.config.images || {};
    if (imgs.logo) jobs.push(this._img('assets/images/' + imgs.logo).then((b) => { if (b) this.images.logo = imgs.logo; }));
    for (const [id, f] of Object.entries(imgs.characters || {})) if (f) jobs.push(this._img('assets/images/' + f).then((b) => { if (b) this.images['char:' + id] = 'assets/images/' + f; }));
    for (const [id, f] of Object.entries(imgs.textures || {})) if (f) jobs.push(this._img('assets/images/' + f).then((b) => { if (b) this.images['tex:' + id] = b; }));
    const au = this.config.audio || {};
    for (const [k, f] of Object.entries(au.music || {})) if (f) jobs.push(this._bin('assets/audio/' + f).then((b) => { if (b) this.audioRaw.music[k] = b; }));
    for (const [k, f] of Object.entries(au.sfx || {})) if (f) jobs.push(this._bin('assets/audio/' + f).then((b) => { if (b) this.audioRaw.sfx[k] = b; }));
    let done = 0; jobs.forEach((j) => j.then(() => progress(++done / jobs.length)));
    await Promise.all(jobs); progress(1);
  }
}
