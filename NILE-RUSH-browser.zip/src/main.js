import { Game } from './game/Game.js';
import { UI } from './ui/UI.js';

const canvas = document.getElementById('gl');
const game = new Game(canvas);
const ui = new UI(game, document.getElementById('ui'));
game.ui = ui;
game.input.attach(document.getElementById('touch'));
window.__nile = game; // handy for debugging in the browser console

// audio can only start after a user gesture
const unlock = () => game.audio.unlock();
window.addEventListener('pointerdown', unlock, { passive: true }); window.addEventListener('keydown', unlock);

// PWA install prompt
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); ui.installEvt = e; ui.setInstallVisible(); });
window.addEventListener('appinstalled', () => { ui.installEvt = null; ui.setInstallVisible(); ui.toast('NILE RUSH installed!', 'good'); });

// service worker (needs https or localhost)
if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch((err) => console.warn('Service worker registration failed', err)));
}
// block pinch/double-tap zoom and pull-to-refresh gestures inside the game
document.addEventListener('gesturestart', (e) => e.preventDefault());
document.addEventListener('dblclick', (e) => e.preventDefault());

game.boot((p) => ui.setProgress(p)).then(() => ui.splashReady()).catch((err) => {
  console.error(err);
  ui.splashError(err && err.message === 'WEBGL2_UNAVAILABLE' ? 'This browser or device does not support WebGL 2, which NILE RUSH needs. Try an up-to-date Chrome, Edge, Firefox or Safari 15+.' : 'The game could not start: ' + (err && err.message));
});
