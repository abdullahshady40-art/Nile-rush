import { CFG } from '../core/Config.js';
import { damp, clamp, lerp, easeOutCubic } from '../core/Utils.js';

/** Chase camera with smoothing, speed FOV, shake, plus menu / character-stage / cinematic modes. */
export class CameraRig {
  constructor(cam) {
    this.cam = cam; this.shake = 0; this.x = 0; this.y = 4; this.z = 8; this.lx = 0; this.ly = 1.4; this.lz = -8;
    this.fov = 64; this.staged = false; this.shakeScale = 1; this.startT = 1; this.shiftX = 0; this.shiftY = 0; this.kick = 0; this.orbit = 0; this.seeded = false;
  }
  addShake(a) { this.shake = Math.max(this.shake, a * this.shakeScale); }
  addKick(a) { this.kick = Math.max(this.kick, a); }
  startRun() { this.startT = 0; }
  setShift(sx, sy, dt) { this.shiftX = damp(this.shiftX, sx, 5, dt); this.shiftY = damp(this.shiftY, sy, 5, dt); this.cam.shiftX = this.shiftX; this.cam.shiftY = this.shiftY; }

  _apply(dt, px, py, pz, lx, ly, lz, fov, roll, useShake = true) {
    const c = this.cam, rnd = Math.random;
    let sx = 0, sy = 0;
    if (useShake && this.shake > 0.001) { sx = (rnd() - 0.5) * this.shake; sy = (rnd() - 0.5) * this.shake * 0.7; }
    this.shake *= Math.exp(-7 * dt); this.kick *= Math.exp(-4 * dt);
    c.pos[0] = px + sx; c.pos[1] = py + sy; c.pos[2] = pz; c.target[0] = lx + sx * 0.4; c.target[1] = ly + sy * 0.4; c.target[2] = lz;
    c.fov = fov + this.kick; c.roll = roll;
  }

  /** gameplay chase */
  play(dt, p, speed01, boost, dead) {
    if (!this.seeded) { this.x = p.x * 0.55; this.y = 4.5; this.z = p.z + 9; this.seeded = true; }
    this.startT = Math.min(1, this.startT + dt / 1.3);
    const k = easeOutCubic(this.startT);
    const tx = p.x * 0.58, ty = 3.45 + p.y * 0.34 + (p.slideT > 0 ? -0.35 : 0) + (1 - k) * 1.6;
    const tz = p.z + 7.3 + speed01 * 0.9 + (1 - k) * 3;
    this.x = damp(this.x, tx, 7, dt); this.y = damp(this.y, ty, 6, dt); this.z = damp(this.z, tz, 12, dt);
    this.lx = damp(this.lx, p.x * 0.34, 8, dt); this.ly = damp(this.ly, 1.45 + p.y * 0.3, 7, dt); this.lz = p.z - 9;
    const fov = 60 + speed01 * 9 + (boost ? 9 : 0);
    this._apply(dt, this.x, this.y, this.z, this.lx, this.ly, this.lz, fov, dead ? 0 : -p.vx * 0.0045);
  }

  /** main menu: character stage */
  stage(dt, t, sz, aspect, zoom = 1) {
    const back = aspect < 0.9 ? 6.6 : 4.9;
    const ang = Math.sin(t * 0.25) * 0.18 - 0.55;
    const px = Math.sin(ang) * back * zoom + 0, pz = sz + Math.cos(ang) * back * zoom;
    if (!this.staged) { this.x = px; this.y = 1.45; this.z = pz; this.lx = 0; this.ly = 1.05; this.staged = true; }
    this.x = damp(this.x, px, 3, dt); this.y = damp(this.y, 1.45, 3, dt); this.z = damp(this.z, pz, 3, dt);
    this.lx = damp(this.lx, 0, 4, dt); this.ly = damp(this.ly, 1.05, 4, dt); this.lz = sz;
    this._apply(dt, this.x, this.y, this.z, this.lx, this.ly, this.lz, aspect < 0.9 ? 46 : 40, 0, false);
    this.seeded = false;
  }

  /** scripted intro shots. c = seconds into cinematic; p = player */
  cinematic(dt, c, p) {
    let px, py, pz, lx, ly, lz, fov;
    if (c < 3.8) { const u = c / 3.8; px = p.x + 2.4 - u * 1.4; py = 0.85 + u * 0.5; pz = p.z - 5.6 + u * 1.2; lx = p.x; ly = 1.1; lz = p.z; fov = 55 - u * 6; }
    else if (c < 7.4) { const u = (c - 3.8) / 3.6; px = p.x + 6.2 - u * 1.2; py = 1.5 + u * 0.4; pz = p.z + 0.5 - u * 1.8; lx = p.x; ly = 1.2; lz = p.z - 1.4; fov = 46; }
    else { const u = clamp((c - 7.4) / 3.6, 0, 1); px = p.x * 0.5 + (1 - u) * -2; py = 1.6 + u * 2.0; pz = p.z + 4.5 + u * 3.4; lx = p.x * 0.4; ly = 1.4; lz = p.z - 9; fov = 52 + u * 12; }
    this.x = px; this.y = py; this.z = pz; this.lx = lx; this.ly = ly; this.lz = lz; this.seeded = false;
    this._apply(dt, px, py, pz, lx, ly, lz, fov, 0, false);
  }
}
