import { CFG, QUALITY, pickDefaultQuality } from '../core/Config.js';
import { clamp, damp, lerp, Rng } from '../core/Utils.js';
import { Renderer } from '../rendering/Renderer.js';
import { Camera } from '../rendering/Camera.js';
import { CameraRig } from './CameraRig.js';
import { Run } from './Run.js';
import { World } from '../world/World.js';
import { Atmosphere } from '../world/TimeOfDay.js';
import { ENVS } from '../world/Environments.js';
import { paintSignAtlas } from '../world/SignAtlas.js';
import { Obstacles } from '../world/Obstacles.js';
import { Collectibles } from '../world/Collectibles.js';
import { Spawner } from '../world/Spawner.js';
import { ParticleSystem } from '../particles/ParticleSystem.js';
import { Player } from '../player/Player.js';
import { CharacterView, drawBoard } from '../characters/CharacterView.js';
import { CHARACTERS, getCharacter, getSkin, getBoard, getTrail, POWERUPS } from '../characters/CharacterData.js';
import { SaveManager } from '../storage/SaveManager.js';
import { AudioEngine } from '../audio/AudioEngine.js';
import { InputManager } from '../input/InputManager.js';
import { AssetManager } from '../assets/AssetManager.js';
import { Missions } from '../missions/Missions.js';
import { Achievements } from '../missions/Achievements.js';

const PU_STAT = { magnet: 'magnet', shield: 'shield', speed: 'speed', double: 'double', multiplier: 'multiplier', invincible: 'invincible' };

/** Top-level orchestrator: state machine, game loop, wiring of every subsystem. */
export class Game {
  constructor(canvas) {
    this.canvas = canvas; this.state = 'boot'; this.time = 0; this.last = 0; this.tsc = 1;
    this.save = new SaveManager(); this.audio = new AudioEngine(); this.input = new InputManager();
    this.ui = null; this.loadout = { headStart: false, scoreBooster: false };
    this.previewChar = this.save.data.selectedChar; this.stageSpin = 0; this.layout = 'menu';
    this.st = { x: 0, y: 0, z: 0, yaw: 0, roll: 0, anim: 'idle', phi: 0, t: 0, hitT: 0, deadT: 0, slideT: 0, speed01: 0, alpha: 1 };
    this._box = { x: 0, z: 0, hw: 0, hd: 0, y0: 0, y1: 0 };
    this.fps = 60; this.frames = 0; this.fpsT = 0; this.dustT = 0; this.ambT = 0; this.achT = 0; this.distAcc = 0; this.saveT = 0; this.lastEnv = -1;
    this._introRng = new Rng(7); this.dyingT = 0; this.overTimer = 0; this.introT = 0; this.introNext = 0; this.zoom = 1;
  }

  // ------------------------------------------------------------------ boot
  async boot(progress = () => {}) {
    const r = this.r = new Renderer(this.canvas);
    if (!r.ok) throw new Error('WEBGL2_UNAVAILABLE');
    this.cam = new Camera(); this.rig = new CameraRig(this.cam);
    r.geo.sign.map = r.createTexture(paintSignAtlas());
    this.assets = new AssetManager(r); await this.assets.init(progress);
    this.particles = new ParticleSystem(r, 1300); this.world = new World(r); this.atm = new Atmosphere();
    this.obstacles = new Obstacles(r); this.collect = new Collectibles(r); this.spawner = new Spawner(this.obstacles, this.collect);
    this.player = new Player(); this.view = new CharacterView(r);
    for (const [id, m] of Object.entries(this.assets.models.characters)) this.view.models.set(id, m);
    this.run = new Run(this.save);
    this.missions = new Missions(this.save, { onComplete: (s, title) => { this.ui && this.ui.toast('Mission complete: ' + title, 'good'); this.audio.sfx('reward'); } });
    this.achievements = new Achievements(this.save, (a) => { this.ui && this.ui.toast('Achievement: ' + a.name + '  +' + a.reward, 'gold'); this.audio.sfx('reward'); });
    this._wirePlayer(); this._wireInput();
    this.checkUnlocks(false);
    this.applySettings(); this.onResize();
    window.addEventListener('resize', () => this.onResize()); window.addEventListener('orientationchange', () => setTimeout(() => this.onResize(), 200));
    document.addEventListener('visibilitychange', () => { if (document.hidden) { if (this.state === 'playing') this.pause(); this.audio.suspend(); } else if (this.audio.ready) this.audio.resume(); });
    this.setupScene('menu');
    this.last = performance.now(); requestAnimationFrame((t) => this.loop(t));
  }

  _wirePlayer() {
    const p = this.player, A = this.audio;
    p.cb.lane = () => { if (this.state === 'playing') A.sfx('lane'); };
    p.cb.jump = () => { A.sfx('jump'); this.particles.jumpDust(p.x, 0, p.z); };
    p.cb.land = (v) => { if (this.state === 'playing') { A.sfx('land', { v }); this.particles.landPuff(p.x, 0, p.z); if (v > 14) this.rig.addShake(0.06); } };
    p.cb.slide = () => { A.sfx('slide'); this.particles.jumpDust(p.x, 0, p.z); };
    p.cb.bump = () => { this.rig.addShake(0.05); };
  }
  _wireInput() {
    const I = this.input, P = this.player, on = (s) => this.state === s;
    I.on('left', () => on('playing') && P.left()); I.on('right', () => on('playing') && P.right());
    I.on('jump', () => on('playing') && P.jump()); I.on('slide', () => on('playing') && P.slide());
    I.on('dash', () => on('playing') && this.tryDash()); I.on('board', () => on('playing') && this.tryBoard());
    I.on('pause', () => { if (this.state === 'playing') this.pause(); else if (this.state === 'paused') this.resume(); else if (this.ui) this.ui.back(); });
  }

  // ------------------------------------------------------------------ settings / sizing
  get quality() { const q = this.save.data.settings.quality; return QUALITY[q === 'auto' ? (this._auto || (this._auto = pickDefaultQuality())) : q] || QUALITY.medium; }
  applySettings() {
    const s = this.save.data.settings, q = this.quality;
    this.audio.setVolumes({ music: s.music, sfx: s.sfx, mute: s.mute });
    this.atm.setForced(s.time); this.rig.shakeScale = s.shake ? 1 : 0;
    this.particles.setMax(q.particles);
    if (this._qKey !== s.quality + s.time) { this._qKey = s.quality + s.time; this.world.setQuality({ ...q }); }
    this.onResize();
  }
  onResize() {
    if (!this.r) return;
    const q = this.quality, w = this.canvas.clientWidth || innerWidth, h = this.canvas.clientHeight || innerHeight;
    this.r.resize(w, h, Math.min(window.devicePixelRatio || 1, q.dprCap) * q.scale);
    this.cam.aspect = w / h; this.aspect = w / h;
  }

  // ------------------------------------------------------------------ scene setup
  setupScene(mode) {
    const seed = mode === 'intro' ? 20260921 : (Math.random() * 1e9) | 0;
    this.world.reset(seed, { ...this.quality }); this.obstacles.clear(); this.collect.clear(); this.particles.clear();
    this.player.reset(); this.lastEnv = -1; this.distAcc = 0;
    this.rig.seeded = false; this.rig.shake = 0; this.rig.staged = false;
    if (mode === 'menu') { this.player.z = -4; this.stageZ = -4; this.world.update(0); }
  }

  // ------------------------------------------------------------------ state changes
  goMenu() {
    this.setupScene('menu'); this.state = 'menu'; this.tsc = 1; this.input.setGameplay(false);
    this.previewChar = this.save.data.selectedChar; this.layout = 'menu';
    this.audio.playMusic('menu'); this.ui.show('menu');
  }
  startIntro() {
    this.setupScene('intro'); this.state = 'intro'; this.introT = 0; this.introNext = 26; this.player.z = 0;
    this.run.reset(); this.audio.playMusic('intro'); this.input.setGameplay(false); this.ui.show('intro');
  }
  endIntro() { if (this.state !== 'intro') return; this.save.data.introSeen = true; this.save.saveSoon(); this.goMenu(); }

  requestPlay() {
    this.audio.unlock();
    if (!this.save.data.tutorialDone) { this.ui.show('tutorial'); return; }
    this.startRun();
  }
  startRun() {
    const inv = this.save.data.inventory, lo = {};
    if (this.loadout.headStart && inv.headStart > 0) { inv.headStart--; lo.headStart = true; }
    if (this.loadout.scoreBooster && inv.scoreBooster > 0) { inv.scoreBooster--; lo.scoreBooster = true; }
    this.loadout.headStart = this.loadout.scoreBooster = false;
    this.setupScene('run'); this.run.reset(lo); this.spawner.reset(62); this.world.update(0);
    this.player.reset(); this.rig.startRun(); this.state = 'playing'; this.tsc = 1; this.input.setGameplay(true);
    this.atm.update(0, 0, this.time); this.achT = 0; this.saveT = 0; this.save.save();
    this.audio.playMusic('game'); this.audio.sfx('go'); this.ui.show('hud'); this.ui.hud.reset();
    this.ui.announce(ENVS[0].name, ENVS[0].ar);
  }
  pause() { if (this.state !== 'playing') return; this.state = 'paused'; this.input.setGameplay(false); this.audio.sfx('back'); this.ui.show('pause'); this.save.save(); }
  resume() { if (this.state !== 'paused') return; this.state = 'playing'; this.input.setGameplay(true); this.ui.show('hud'); this.audio.sfx('select'); }
  restart() { this.startRun(); }
  quitToMenu() { this.finishRun(false); this.goMenu(); }

  // ------------------------------------------------------------------ actions
  stat(name, n = 1) { const s = this.save.data.stats; s[name] = (s[name] || 0) + n; this.missions.add(name, n); }
  tryDash() {
    const r = this.run, p = this.player; if (p.dead || p.dashT > 0) return;
    if (r.dash < CFG.dashCost) { this.audio.sfx('error'); this.ui.hud.flashDash(); return; }
    r.dash = 0; p.dashT = CFG.dashTime; this.audio.sfx('dash'); this.rig.addKick(11); this.rig.addShake(0.12);
    for (let i = 0; i < 16; i++) this.particles.boostTick(p.x, 0, p.z, 1.8);
  }
  tryBoard() {
    const r = this.run, p = this.player, inv = this.save.data.inventory; if (p.dead || r.boardActive) return;
    if (inv.boardCharge <= 0) { this.audio.sfx('error'); this.ui.toast('No Board Charges — buy more in the Shop', 'warn'); return; }
    inv.boardCharge--; r.boardActive = true; r.boardT = r.board.duration; r.boardHits = r.board.hits; p.boardOn = true;
    this.stat('boardRides', 1); this.audio.sfx('board'); this.particles.pickupBurst(p.x, 0.5, p.z, ...r.board.trail); this.save.saveSoon();
  }
  endBoard(broken) {
    const r = this.run, p = this.player; r.boardActive = false; p.boardOn = false;
    this.particles.pickupBurst(p.x, 0.4, p.z, ...r.board.trail); this.audio.sfx(broken ? 'boardBreak' : 'back');
    if (broken) { this.rig.addShake(0.3); p.grace = 1.6; }
  }

  // ------------------------------------------------------------------ collectibles
  onTake(c) {
    const r = this.run, p = this.player, P = this.particles;
    if (c.kind === 'coin' || c.kind === 'gem') {
      const gem = c.kind === 'gem', n = Math.max(1, Math.round((gem ? 5 : 1) * r.coinMult));
      r.coins += n; this.save.data.coins += n; this.stat('coins', n);
      r.bumpCombo(gem ? 3 : 1); r.addScore(gem ? 50 : 10); r.dash = Math.min(100, r.dash + CFG.dashPerCoin * (gem ? 4 : 1));
      this.audio.sfx(gem ? 'gem' : 'coin', { combo: r.chain % 8 }); P.coinSparkle(c.x, c.y, c.z, gem);
      this.ui.hud.coinBump();
    } else {
      const id = c.power; r.activate(id); r.addScore(100); this.stat(PU_STAT[id], 1);
      const col = POWERUPS[id].color; P.pickupBurst(c.x, c.y, c.z, col[0], col[1], col[2]);
      this.audio.sfx(id === 'shield' ? 'shield' : id); this.ui.toast(POWERUPS[id].name + '!', 'power');
      this.rig.addKick(id === 'speed' ? 8 : 3);
    }
  }

  // ------------------------------------------------------------------ obstacles / collisions
  _smash(o) {
    o.alive = false; o.smashed = true; this.run.smashed++; this.stat('smashed', 1);
    this.particles.debris(o.x, o.yb + o.h * 0.5, o.z, [0.7, 0.55, 0.35], o.type === 'train' ? 26 : 16);
    this.audio.sfx('smash'); this.rig.addShake(0.22); this.run.addScore(25);
  }
  _onHit(o) {
    const r = this.run, p = this.player;
    if (p.grace > 0) return;
    if (r.invincible || p.dashT > 0) return this._smash(o);
    if (r.shield > 0) { r.shield = 0; r.timers.shield = 0; this._smash(o); p.grace = 1.2; this.audio.sfx('shieldBreak'); this.particles.shieldBreak(p.x, 1, p.z); return; }
    if (r.boardActive) { r.boardHits--; this._smash(o); p.grace = 1.5; if (r.boardHits <= 0) this.endBoard(true); else { this.audio.sfx('shieldBreak'); this.rig.addShake(0.25); } return; }
    this.die(o);
  }
  _checkObstacles() {
    const p = this.player, r = this.run, b = p.aabb(this._box);
    this.obstacles.pool.forEachAlive((o) => {
      const dz = Math.abs(o.z - p.z), reach = o.hd + b.hd;
      if (dz < reach + 1.2) {
        const gapX = Math.abs(o.x - b.x) - (o.hw + b.hw);
        if (b.y0 < o.yb + o.h && b.y1 > o.yb && gapX > 0) o.minGap = Math.min(o.minGap === undefined ? 9 : o.minGap, gapX);
        if (gapX < 0.05) {
          if (o.jump) o.minV = Math.min(o.minV === undefined ? 9 : o.minV, b.y0 - (o.yb + o.h));
          if (o.slide) o.minV = Math.min(o.minV === undefined ? 9 : o.minV, o.yb - b.y1);
        }
      }
      if (dz < reach && Math.abs(o.x - b.x) < o.hw + b.hw - 0.08 && b.y0 < o.yb + o.h - 0.1 && b.y1 > o.yb + 0.05) { o.hitFlag = true; this._onHit(o); if (this.state !== 'playing') return; }
      if (!o.counted && p.z < o.z - o.hd) {
        o.counted = true;
        if (!o.hitFlag && o.alive) {
          let near = false;
          if (o.jump && o.minV !== undefined && o.minV > -0.05) { r.jumps++; this.stat('jumps', 1); if (o.minV < 0.3) near = true; }
          if (o.slide && o.minV !== undefined && o.minV >= 0 && p.slideT > 0) { r.slides++; this.stat('slides', 1); if (o.minV < 0.25) near = true; }
          if (o.minGap !== undefined && o.minGap < CFG.nearMissGap && !o.jump && !o.slide) near = true;
          if (near) this._nearMiss(o);
        }
      }
    });
  }
  _nearMiss(o) {
    const r = this.run; r.near++; this.stat('nearMisses', 1); r.bumpCombo(2); r.dash = Math.min(100, r.dash + CFG.dashPerNear);
    const v = r.addScore(100); this.audio.sfx('near'); this.ui.hud.popup('NEAR MISS  +' + v); this.rig.addKick(4);
    this.particles.ring(o.x, 1, o.z, 1, 0.9, 0.5, 2.4, 0.4);
  }

  // ------------------------------------------------------------------ death / results
  die(o) {
    if (this.state !== 'playing') return;
    const p = this.player; p.hit(); this.state = 'dying'; this.dyingT = 0; this.input.setGameplay(false);
    this.particles.hit(p.x, 1, p.z); this.audio.sfx('hit'); this.rig.addShake(0.6); this.rig.addKick(-6);
    if (this.save.data.settings.vibration && navigator.vibrate) navigator.vibrate(120);
    this.audio.stopMusic(); this.run.breakCombo();
  }
  finishRun(record = true) {
    const r = this.run, d = this.save.data, s = d.stats;
    const meters = Math.floor(this.distAcc); if (meters > 0) { this.stat('distance', meters); this.distAcc -= meters; }
    if (!record || r.time < 0.5) { this.save.save(); return null; }
    s.runs++; this.missions.add('runs', 1); s.totalScore += r.score; s.playSeconds += r.time; s.bestCombo = Math.max(s.bestCombo, r.maxCombo);
    this.missions.max('runScore', r.score); this.missions.max('runCombo', r.maxCombo);
    const newBest = r.score > d.highScore; if (newBest) d.highScore = Math.floor(r.score);
    if (r.dist > d.bestDistance) d.bestDistance = Math.floor(r.dist);
    this.achievements.check({ dist: r.dist, topSpeed: r.topSpeed, time: r.time, maxCombo: r.maxCombo });
    const unlocked = this.checkUnlocks(true); this.save.save();
    return { score: Math.floor(r.score), best: d.highScore, newBest, coins: r.coins, dist: Math.floor(r.dist), unlocked, near: r.near, wallet: d.coins };
  }
  checkUnlocks(announce) {
    const d = this.save.data, out = [];
    for (const c of CHARACTERS) if (c.unlock.type === 'distance' && !d.unlockedChars.includes(c.id) && d.bestDistance >= c.unlock.value) { d.unlockedChars.push(c.id); out.push(c.name); if (announce && this.ui) this.ui.toast(c.name + ' unlocked!', 'gold'); }
    return out;
  }
  gameOver() {
    this.state = 'over'; this.tsc = 1; const res = this.finishRun(true);
    this.audio.sfx('gameover'); this.ui.show('over', res);
  }

  // ------------------------------------------------------------------ frame loop
  loop(now) {
    requestAnimationFrame((t) => this.loop(t));
    let dt = (now - this.last) / 1000; this.last = now; if (!(dt > 0)) return; dt = Math.min(dt, 0.05);
    this.frames++; this.fpsT += dt; if (this.fpsT >= 1) { this.fps = this.frames / this.fpsT; this.frames = 0; this.fpsT = 0; }
    this.time += dt;
    try { this.frame(dt); } catch (e) { console.error(e); if (!this._errShown) { this._errShown = true; this.ui && this.ui.toast('Something went wrong: ' + e.message, 'warn'); } }
  }

  frame(dt) {
    const st = this.state;
    if (st === 'playing' || st === 'dying') this.updatePlay(dt);
    else if (st === 'intro') this.updateIntro(dt);
    else if (st === 'menu') this.updateStage(dt);
    else if (st === 'paused' || st === 'over') this.updateFrozen(dt);
    this.render();
  }

  _scene(dist, dt, air) {
    const env = this.atm.update(dist, dt, this.time); this.world.update(dist);
    this.ambT += dt; const [kind, rate] = this.atm.ambientFx(), q = this.quality;
    const n = Math.floor(this.ambT * rate * q.ambient); if (n > 0) { this.ambT = 0; for (let i = 0; i < Math.min(n, 6); i++) this.particles.ambient(kind, this.cam.pos[0], 2, this.cam.pos[2], 14); }
    return env;
  }

  updateStage(dt) {
    this.stageSpin += dt; const isChars = this.layout === 'chars';
    const p = this.player; p.t += dt; this.atm.update(0, dt, this.time); this.world.update(0);
    this.rig.stage(dt, this.time, this.stageZ, this.aspect, isChars ? 0.8 : 1);
    const wide = this.aspect > 1.15;
    const sx = this.layout === 'none' ? 0 : wide ? (isChars ? -0.32 : 0.34) : 0, sy = this.layout === 'none' ? 0 : wide ? 0 : (isChars ? 0.34 : 0.3);
    this.rig.setShift(sx, sy, dt);
    this.particles.update(dt); this._scene(0, dt);
  }
  updateFrozen(dt) {
    this.particles.update(dt * 0.0); this.rig.setShift(0, 0, dt);
    if (this.state === 'over') { this.player.t += dt; this.atm.update(this.run.dist, dt, this.time); }
  }

  updatePlay(realDt) {
    if (this.state === 'dying') { this.dyingT += realDt; this.tsc = this.dyingT < 0.9 ? 0.25 : 0.05; if (this.dyingT > 1.35) { this.gameOver(); return; } }
    const dt = realDt * this.tsc, steps = Math.max(1, Math.ceil(dt / (1 / 60))), h = dt / steps;
    for (let i = 0; i < steps; i++) this._step(h);
    const r = this.run, p = this.player;
    this.particles.update(dt);
    this.rig.setShift(0, 0, realDt);
    this.rig.play(realDt, p, clamp((r.speed - CFG.baseSpeed) / (CFG.maxSpeed - CFG.baseSpeed), 0, 1), p.dashT > 0 || r.timers.speed > 0, p.dead);
    this.atm.update(r.dist, dt, this.time); this.world.update(r.dist);
    // ambient
    this.ambT += dt; const [kind, rate] = this.atm.ambientFx(), q = this.quality, n = Math.floor(this.ambT * rate * q.ambient);
    if (n > 0) { this.ambT = 0; for (let i = 0; i < Math.min(n, 6); i++) this.particles.ambient(kind, p.x, 2, p.z, 14); }
    if (this.state === 'playing') {
      const ei = this.world.envIndexAt(r.dist);
      if (ei !== this.lastEnv) { if (this.lastEnv !== -1) this.ui.announce(ENVS[ei].name, ENVS[ei].ar); this.lastEnv = ei; }
      this.ui.hud.update(r, p, this.save.data.inventory.boardCharge);
      this.audio.setIntensity(clamp((r.speed - CFG.baseSpeed) / (CFG.maxSpeed - CFG.baseSpeed), 0, 1));
      this.achT += realDt; this.saveT += realDt;
      if (this.achT > 0.6) { this.achT = 0; this.achievements.check({ dist: r.dist, topSpeed: r.topSpeed, time: r.time, maxCombo: r.maxCombo }); this.missions.max('runScore', r.score); }
      if (this.saveT > 12) { this.saveT = 0; this.save.saveSoon(); }
    }
  }

  _step(h) {
    const r = this.run, p = this.player, dead = p.dead;
    const fx = { jump: r.char.fx.jump, glide: r.boardActive ? r.board.glide : 1 };
    if (!dead) {
      const tgt = r.targetSpeed(r.dist) * (p.dashT > 0 ? 1.55 : 1);
      r.speed = damp(r.speed, tgt, 2.2, h); if (r.speed > r.topSpeed) r.topSpeed = r.speed;
    } else r.speed = damp(r.speed, 0, 3, h);
    p.update(h, r.speed, fx);
    if (dead) { this.obstacles.update(h, p.z); return; }
    const ds = p.prevZ - p.z; r.dist += ds; this.distAcc += ds;
    const m = Math.floor(this.distAcc); if (m >= 10) { this.stat('distance', m); this.distAcc -= m; }
    r.addScore(ds * 2); r.tick(h);
    if (r.boardActive && r.boardT <= 0) this.endBoard(false);
    // world streaming
    this.spawner.update(r.dist, r.speed, (d) => ENVS[this.world.envIndexAt(d)].style);
    this.obstacles.update(h, p.z);
    this.collect.update(h, p.x, p.y, p.z, p.prevZ, p.height, r.magnetRadius, (c) => this.onTake(c));
    this._checkObstacles();
    // trains: horn when a fast one is close
    this._fxTick(h);
  }

  _fxTick(h) {
    const r = this.run, p = this.player, P = this.particles, t = this.time;
    this.dustT += h;
    const trail = getTrail(this.save.data.selectedTrail); P.trail.r = trail.c[0]; P.trail.g = trail.c[1]; P.trail.b = trail.c[2]; P.trail.add = trail.add; P.trail.shape = trail.shape;
    if (this.dustT > 0.045) {
      this.dustT = 0;
      if (!p.inAir && !p.dead) P.dust(p.x, 0, p.z, r.speed);
      if (p.dashT > 0 || r.timers.speed > 0) P.boostTick(p.x, 0, p.z, 1);
      if (r.shield > 0) P.shieldTick(p.x, 0, p.z);
      if (r.boardActive) P.emit(p.x, 0.15, p.z + 0.9, (Math.random() - 0.5) * 0.6, 0.4, r.speed * 0.15, 0.45, 0.28, 0.02, r.board.trail[0], r.board.trail[1], r.board.trail[2], 0.8, 0, 1, 0, 1);
      const mr = r.magnetRadius; if (mr > 0) P.magnetTick(p.x, 0, p.z, mr);
      if (r.invincible) P.emit(p.x + (Math.random() - 0.5) * 0.8, 0.4 + Math.random() * 1.4, p.z, 0, 0.5, 0, 0.5, 0.2, 0.02, 1, 0.85, 0.35, 0.9, 0, 0, 1, 1);
    }
  }

  // ------------------------------------------------------------------ intro cinematic
  updateIntro(dt) {
    this.introT += dt; const p = this.player, r = this.run, h = dt;
    const speed = 17, dist = -p.z;
    // AI: steer towards next coin line, jump barrier walls
    let target = p.lane;
    this.collect.pool.forEachAlive((c) => { if (c.kind === 'coin' && c.z < p.z - 3 && c.z > p.z - 32 && Math.abs(c.z - p.z) < 26) target = Math.round(c.x / CFG.laneWidth); });
    if (target !== p.lane) { if (target < p.lane) p.left(); else p.right(); }
    this.obstacles.pool.forEachAlive((o) => { const d = p.z - o.z; if (o.type === 'barrier' && d > 5 && d < 7.5 && !p.inAir) p.jump(); });
    while (this.introNext < dist + 130) {
      const d = this.introNext, l = ((Math.floor(d / 26)) % 3) - 1;
      if (Math.floor(d / 26) % 4 === 3) for (const x of [-1, 0, 1]) this.obstacles.spawn('barrier', x, d + 6, 'city', this._introRng, {});
      for (let i = 0; i < 9; i++) this.collect.spawnCoin(l, d + i * 1.7 - 2, 0.9 + (i > 3 && i < 6 ? 0.3 : 0), false);
      this.introNext += 26;
    }
    p.update(h, speed, {}); r.dist = -p.z;
    this.obstacles.update(h, p.z);
    this.collect.update(h, p.x, p.y, p.z, p.prevZ, p.height, 0, (c) => { this.audio.sfx('coin', { combo: 0 }); this.particles.coinSparkle(c.x, c.y, c.z); });
    this.obstacles.pool.forEachAlive((o) => { if (o.z > p.z + 12) o.alive = false; });
    this.particles.update(dt); this._fxIntro(dt);
    this.rig.setShift(0, 0, dt);
    const c = this.introT - 6.0;
    this.rig.cinematic(dt, Math.max(0, c), p);
    this.atm.update(dist, dt, this.time); this.world.update(dist);
    if (this.introT > 6.0 + 11.6) this.endIntro();
  }
  _fxIntro(dt) { this.dustT += dt; if (this.dustT > 0.05 && !this.player.inAir) { this.dustT = 0; this.particles.dust(this.player.x, 0, this.player.z, 17); } }

  // ------------------------------------------------------------------ rendering
  render() {
    const r = this.r, cam = this.cam, t = this.time, p = this.player, q = this.quality;
    cam.update(); r.begin(cam, this.atm.out, t);
    this.world.draw(t);
    const st = this.state;
    if (st === 'menu') this._drawStage(t);
    else if (st !== 'boot') { this._drawPlayer(t); this.obstacles.draw(t, q.shadows); this.collect.draw(t, cam.pos[2]); if (st === 'playing' || st === 'dying') this._speedLines(t, q); }
    r.render(this.particles);
  }

  _drawStage(t) {
    const id = this.previewChar, def = getCharacter(id), s = this.st, chars = this.layout === 'chars';
    s.x = 0; s.y = 0; s.z = this.stageZ; s.yaw = chars ? this.stageSpin * 0.7 + Math.PI : Math.PI - 0.5 + Math.sin(t * 0.3) * 0.12; s.roll = 0; s.anim = 'idle'; s.phi = 0; s.t = t; s.alpha = 1; s.slideT = 0; s.speed01 = 0;
    const d = this.save.data;
    this.view.draw(def, getSkin(d.selectedSkin), s);
    // pedestal ring + shadow
    this.r.submitTRS(this.r.geo.plane, s.x, 0.03, s.z, 0, 0, 0, 1.9, 1, 1.9, [0, 0, 0], 0.4, 0, 9, 0, 1);
    this.r.submitTRS(this.r.geo.torus, s.x, 0.05, s.z, 0, 0, 0, 2.5, 0.05, 2.5, def.palette.accent, 0.5, 0.3, 10, 0, 2);
  }

  _drawPlayer(t) {
    const p = this.player, r = this.run, s = this.st, d = this.save.data, g = this.r.geo;
    const def = r.char || getCharacter(d.selectedChar);
    s.x = p.x; s.y = p.y + (p.boardOn ? 0.28 : 0); s.z = p.z; s.yaw = 0; s.roll = p.roll; s.anim = p.anim; s.phi = p.phi; s.t = p.t; s.hitT = p.hitT; s.deadT = p.deadT; s.slideT = p.slideAnim;
    s.speed01 = clamp((p.speed - CFG.baseSpeed) / (CFG.maxSpeed - CFG.baseSpeed), 0, 1);
    s.alpha = p.grace > 0 && Math.sin(p.flicker) > 0 ? 0.35 : 1;
    if (this.state === 'intro') { s.anim = p.inAir ? (p.vy > 0 ? 'jump' : 'fall') : 'run'; }
    if (p.dead) s.anim = 'death';
    this.view.draw(def, getSkin(d.selectedSkin), s);
    if (p.boardOn) drawBoard(this.r, r.board, p.x, p.y, p.z, 0, this.time, s.alpha);
    // blob shadow
    const sh = clamp(1 - p.y * 0.25, 0.4, 1);
    this.r.submitTRS(g.plane, p.x, 0.035, p.z, 0, 0, 0, 1.5 * sh, 1, 1.5 * sh, [0, 0, 0], 0.5 * sh, 0, 9, 0, 1);
    if (this.state === 'playing' || this.state === 'dying') {
      const y = p.y + 0.95;
      if (r.shield > 0) this.r.submitTRS(g.sphere, p.x, y, p.z, 0, 0, 0, 2.5, 2.7, 2.5, [0.35, 0.8, 1], 0.9, 0, 8, 0, 2);
      if (r.invincible || p.dashT > 0) this.r.submitTRS(g.sphere, p.x, y, p.z, 0, 0, 0, 2.9, 3, 2.9, [1, 0.8, 0.3], 0.9, 0, 8, 0, 2);
      if (r.magnetRadius > 0) this.r.submitTRS(g.torus, p.x, y, p.z, Math.PI / 2, this.time * 3, 0, 4.5 + Math.sin(this.time * 6) * 0.3, 4.5, 4.5, [0.95, 0.3, 0.4], 0.5, 0, 10, 0, 2);
    }
  }

  _speedLines(t, q) {
    const p = this.player, r = this.run; if (!q.speedLines || p.dead) return;
    const k = clamp((r.speed - 20) / 14, 0, 1) + (p.dashT > 0 ? 0.6 : 0) + (r.timers.speed > 0 ? 0.4 : 0); if (k < 0.05) return;
    const n = Math.floor(6 + k * 8), g = this.r.geo;
    for (let i = 0; i < n; i++) {
      const u = i * 0.6180339, side = i % 2 ? 1 : -1, x = p.x * 0.5 + side * (3.2 + ((u * 7) % 1) * 4), y = 0.4 + ((u * 13) % 1) * 4.6;
      const z = p.z + 4 - (((t * (r.speed * 2.3) + i * 17.3) % 70)), len = 5 + ((u * 5) % 1) * 5;
      this.r.submitTRS(g.box, x, y, z - len / 2, 0, 0, 0, 0.04, 0.04, len, [1, 1, 1], 0.28 * Math.min(1, k), 0, 10, 0, 2);
    }
  }

  // ------------------------------------------------------------------ helpers used by the UI
  setLayout(name) { this.layout = name; }
  setPreview(id) { this.previewChar = id; this.stageSpin = 0; }
}
