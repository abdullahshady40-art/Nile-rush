import { CFG } from '../core/Config.js';
import { POWERUPS, getBoard, getCharacter } from '../characters/CharacterData.js';

/** State of the current run: score, combo, power-up timers, boosts. Pure logic, no rendering. */
export class Run {
  constructor(save) { this.save = save; this.reset(); }

  reset(opts = {}) {
    const s = this.save.data;
    this.char = getCharacter(s.selectedChar); this.board = getBoard(s.selectedBoard);
    this.score = 0; this.coins = 0; this.dist = 0; this.time = 0; this.topSpeed = 0;
    this.chain = 0; this.combo = 1; this.comboT = 0; this.maxCombo = 1; this.comboFrac = 0;
    this.near = 0; this.jumps = 0; this.slides = 0; this.smashed = 0; this.powerups = 0;
    this.timers = { magnet: 0, shield: 0, speed: 0, double: 0, multiplier: 0, invincible: 0 };
    this.shield = 0; this.boardT = 0; this.boardHits = 0; this.boardActive = false;
    this.headStart = opts.headStart ? 8 : 0; this.scoreBoost = opts.scoreBooster ? 45 : 0;
    this.dash = 0; this.speed = CFG.baseSpeed; this.newBest = false;
  }

  duration(id) {
    const lvl = this.save.data.upgrades[id] || 0, p = POWERUPS[id];
    return p.base + p.step * lvl + (id === 'magnet' ? this.char.fx.magnetTime : 0);
  }
  get invincible() { return this.timers.invincible > 0 || this.headStart > 0; }
  get magnetRadius() {
    if (this.timers.magnet > 0 || (this.boardActive && this.board.magnet)) return 6.2 + this.char.fx.magnet;
    return 0;
  }
  get scoreMult() { return this.combo * (this.timers.double > 0 ? 2 : 1) * this.char.fx.score * (this.scoreBoost > 0 ? 2 : 1); }
  get coinMult() { return (this.timers.multiplier > 0 ? 2 : 1) * (this.boardActive ? this.board.coinBonus : 1); }

  targetSpeed(dist) {
    let v = CFG.baseSpeed + (CFG.maxSpeed - CFG.baseSpeed) * (1 - Math.exp(-dist / CFG.speedRamp));
    v *= this.char.fx.speed;
    if (this.timers.speed > 0) v *= 1.3;
    if (this.headStart > 0) v *= 1.45;
    return v;
  }

  addScore(n) { const v = Math.round(n * this.scoreMult); this.score += v; return v; }
  bumpCombo(n = 1) {
    this.chain += n; this.comboT = CFG.comboWindow;
    const lvl = Math.min(5, 1 + Math.floor(this.chain / CFG.comboStep));
    this.combo = lvl; if (lvl > this.maxCombo) this.maxCombo = lvl;
  }
  activate(id) {
    this.powerups++;
    if (id === 'shield') this.shield = 1;
    this.timers[id] = this.duration(id);
  }
  breakCombo() { this.chain = 0; this.combo = 1; this.comboT = 0; }

  tick(dt) {
    this.time += dt;
    for (const k in this.timers) if (this.timers[k] > 0) { this.timers[k] -= dt; if (this.timers[k] <= 0) { this.timers[k] = 0; if (k === 'shield') this.shield = 0; } }
    if (this.headStart > 0) this.headStart = Math.max(0, this.headStart - dt);
    if (this.scoreBoost > 0) this.scoreBoost = Math.max(0, this.scoreBoost - dt);
    if (this.boardActive) { this.boardT -= dt; }
    if (this.comboT > 0) { this.comboT -= dt; if (this.comboT <= 0) this.breakCombo(); }
    this.comboFrac = this.combo >= 5 ? 1 : (this.chain % CFG.comboStep) / CFG.comboStep;
  }
}
