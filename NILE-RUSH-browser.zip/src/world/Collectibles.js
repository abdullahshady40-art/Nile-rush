import { Pool } from '../core/Pool.js';
import { CFG } from '../core/Config.js';
import { POWERUPS } from '../characters/CharacterData.js';

const GOLD = [1, 0.8, 0.2], GOLD_D = [0.88, 0.6, 0.1], GEM = [0.25, 0.92, 1];

export class Collectibles {
  constructor(renderer) {
    this.r = renderer; this.g = renderer.geo;
    this.pool = new Pool(() => ({ kind: 'coin', power: '', x: 0, y: 0, z: 0, spin: 0, homing: false }), 420);
  }
  clear() { this.pool.releaseAll(); }
  spawnCoin(lane, dist, y, rare = false) {
    const c = this.pool.acquire(); if (!c) return null;
    c.kind = rare ? 'gem' : 'coin'; c.power = ''; c.x = lane * CFG.laneWidth; c.y = y; c.z = -dist; c.spin = Math.random() * 6; c.homing = false; return c;
  }
  spawnPower(kind, lane, dist, y = 1.1) {
    const c = this.pool.acquire(); if (!c) return null;
    c.kind = 'power'; c.power = kind; c.x = lane * CFG.laneWidth; c.y = y; c.z = -dist; c.spin = 0; c.homing = false; return c;
  }

  /** px,py,pz: player position; prevZ: previous frame z; magnetR: 0 = off; onTake(c) called on pickup */
  update(dt, px, py, pz, prevZ, ph, magnetR, onTake) {
    const cy = py + ph * 0.5, k = 1 - Math.exp(-14 * dt);
    this.pool.forEachAlive((c) => {
      c.spin += dt * (c.kind === 'power' ? 2.2 : 5);
      if (c.z > pz + 8) { c.alive = false; return; }
      if (magnetR > 0 && c.kind !== 'power') {
        const dx = px - c.x, dy = cy - c.y, dz = pz - c.z;
        if (c.homing || dx * dx + dy * dy + dz * dz < magnetR * magnetR) { c.homing = true; c.x += dx * k; c.y += dy * k; c.z += dz * k * 1.2; }
      }
      const dx = Math.abs(c.x - px), dy = Math.abs(c.y - cy);
      const inZ = c.z <= prevZ + 0.7 && c.z >= pz - 0.7 || Math.abs(c.z - pz) < 0.9;
      if (inZ && dx < 0.95 && dy < (c.kind === 'power' ? 1.4 : 1.15)) { c.alive = false; onTake(c); }
    });
  }

  draw(t, camZ) {
    const r = this.r, g = this.g;
    this.pool.forEachAlive((c) => {
      if (c.z < camZ - 200) return;
      if (c.kind === 'coin') {
        r.submitTRS(g.cyl, c.x, c.y, c.z, Math.PI / 2, c.spin, 0, 0.68, 0.1, 0.68, GOLD, 1, 0.5, 0, 0, 0);
        r.submitTRS(g.cyl, c.x, c.y, c.z, Math.PI / 2, c.spin, 0, 0.44, 0.13, 0.44, GOLD_D, 1, 0.3, 0, 0, 0);
      } else if (c.kind === 'gem') {
        const s = 0.62 + Math.sin(t * 6 + c.spin) * 0.05;
        r.submitTRS(g.octa, c.x, c.y + Math.sin(t * 3 + c.spin) * 0.08, c.z, 0, c.spin, 0, s, s * 1.25, s, GEM, 1, 0.8, 0, 0, 0);
        r.submitTRS(g.sphere, c.x, c.y, c.z, 0, 0, 0, 1.5, 1.5, 1.5, GEM, 0.28, 0, 10, 0, 2);
      } else this._power(c, t);
    });
  }

  _power(c, t) {
    const r = this.r, g = this.g, col = POWERUPS[c.power].color, y = c.y + Math.sin(t * 3 + c.z) * 0.12, x = c.x, z = c.z;
    r.submitTRS(g.torus, x, y, z, Math.PI / 2, 0, 0, 1.9, 1.9, 1.9, col, 0.9, 1, 10, 0, 2);
    r.submitTRS(g.sphere, x, y, z, 0, 0, 0, 2.1, 2.1, 2.1, col, 0.16, 0, 10, 0, 2);
    const a = c.spin, dark = [0.12, 0.12, 0.16];
    switch (c.power) {
      case 'magnet':
        for (const s of [-1, 1]) { r.submitTRS(g.box, x + s * 0.3 * Math.cos(a), y + 0.1, z + s * 0.3 * Math.sin(a) * 0, 0, a, 0, 0.2, 0.62, 0.2, [0.9, 0.15, 0.2], 1, 0.4, 0, 0, 0); }
        r.submitTRS(g.box, x, y - 0.24, z, 0, a, 0, 0.8, 0.2, 0.2, [0.9, 0.15, 0.2], 1, 0.4, 0, 0, 0);
        for (const s of [-1, 1]) r.submitTRS(g.box, x + s * 0.3 * Math.cos(a), y + 0.46, z, 0, a, 0, 0.21, 0.14, 0.21, [0.92, 0.92, 0.95], 1, 0.4, 0, 0, 0);
        break;
      case 'shield':
        r.submitTRS(g.sphere, x, y, z, 0, a, 0, 0.72, 0.86, 0.26, [0.3, 0.72, 1], 1, 0.6, 0, 0, 0);
        r.submitTRS(g.sphere, x, y, z, 0, a, 0, 0.5, 0.6, 0.32, [0.85, 0.96, 1], 1, 0.7, 0, 0, 0);
        break;
      case 'speed':
        for (let i = 0; i < 2; i++) r.submitTRS(g.cone, x, y + 0.08 - i * 0.24, z, Math.PI, a, 0, 0.5, 0.48, 0.5, [1, 0.62 - i * 0.1, 0.12], 1, 0.7, 0, 0, 0);
        break;
      case 'double':
        r.submitTRS(g.octa, x, y, z, 0, a, 0, 0.8, 0.8, 0.8, [1, 0.86, 0.2], 1, 0.7, 0, 0, 0);
        r.submitTRS(g.cyl, x, y, z, Math.PI / 2, a, 0, 0.5, 0.1, 0.5, dark, 1, 0.1, 0, 0, 0);
        break;
      case 'multiplier':
        r.submitTRS(g.cyl, x, y, z, Math.PI / 2, a, 0, 0.7, 0.14, 0.7, [0.3, 0.9, 0.4], 1, 0.7, 0, 0, 0);
        r.submitTRS(g.cyl, x, y, z, Math.PI / 2, a, 0, 0.42, 0.18, 0.42, GOLD, 1, 0.6, 0, 0, 0);
        break;
      case 'invincible':
        r.submitTRS(g.torus, x, y + 0.22, z, 0, 0, 0, 0.9, 0.9, 0.9, [1, 0.85, 0.3], 1, 0.8, 0, 0, 0); // ankh loop (rotates via a)
        r.submitTRS(g.box, x, y - 0.14, z, 0, a, 0, 0.12, 0.6, 0.12, [1, 0.85, 0.3], 1, 0.8, 0, 0, 0);
        r.submitTRS(g.box, x, y, z, 0, a, 0, 0.44, 0.12, 0.12, [1, 0.85, 0.3], 1, 0.8, 0, 0, 0);
        break;
      default: break;
    }
  }
}
