// Hand-designed obstacle patterns. Lanes are -1 / 0 / +1. dz is metres ahead of the pattern start.
// Every pattern is solvable: at least one lane (or a jump / slide) gets the player through, with reaction time
// derived from the current speed.
const LN = [-1, 0, 1];
const others = (free) => LN.filter((l) => l !== free);
const line = (l, dz0, n, sp, y = 0.9) => Array.from({ length: n }, (_, i) => ({ l, dz: dz0 + i * sp, y }));
const arc = (l, dz0, n, sp, peak = 2.0) => Array.from({ length: n }, (_, i) => ({ l, dz: dz0 + i * sp, y: 0.9 + (peak - 0.9) * Math.sin(Math.PI * i / (n - 1)) }));
const clampL = (v) => Math.max(-1, Math.min(1, v));
const stepFrom = (rng, l) => (l === 0 ? rng.sign() : -l);   // move one lane towards the middle / across

export const PATTERNS = [
  { name: 'single', w: 3, min: 0, build({ rng, free, diff }) {
    const kinds = ['barrier', 'overhead', 'crate1']; if (diff > 0.1) kinds.push('cart', 'fruitcart', 'crates');
    const t = rng.pick(kinds), l = rng.pick(others(free)), coins = line(free, -2, 8, 1.6);
    if (t === 'barrier' || t === 'crate1') coins.push(...arc(l, -4, 8, 1.1, 2.1));
    return { len: 10, obs: [{ t, l, dz: 0 }], coins };
  } },
  { name: 'pairSolid', w: 2.2, min: 60, build({ rng, free }) {
    const ks = ['crates', 'cart', 'fruitcart', 'barrier', 'crate1'], o = others(free);
    return { len: 12, obs: o.map((l) => ({ t: rng.pick(ks), l, dz: rng.range(0, 3) })), coins: line(free, -2, 10, 1.6) };
  } },
  { name: 'wallJump', w: 2, min: 0, build({ rng }) {
    const t = rng.chance(0.5) ? 'barrier' : 'crate1', l = rng.pick(LN);
    return { len: 9, obs: LN.map((x) => ({ t, l: x, dz: 0 })), coins: arc(l, -4, 9, 1.05, 2.1) };
  } },
  { name: 'wallSlide', w: 1.6, min: 150, build({ rng }) {
    const l = rng.pick(LN);
    return { len: 10, obs: LN.map((x) => ({ t: 'overhead', l: x, dz: 0 })), coins: line(l, -3, 9, 1.0, 0.55) };
  } },
  { name: 'trainGap', w: 2.4, min: 250, build({ rng, free, speed }) {
    const len = rng.range(12, 22), mv = rng.chance(0.4);
    return { len: len + 2, obs: others(free).map((l) => ({ t: 'train', l, dz: len / 2, opts: { len, vz: mv ? 9 : 0 } })), coins: line(free, -2, Math.floor(len / 1.6) + 3, 1.6) };
  } },
  { name: 'trainStep', w: 1.6, min: 500, build({ rng, free, speed }) {
    const len = rng.range(12, 16), gap = speed * 0.7 + 6, f1 = clampL(free + stepFrom(rng, free));
    const obs = [], coins = [];
    for (const l of others(free)) obs.push({ t: 'train', l, dz: len / 2, opts: { len } });
    for (const l of others(f1)) obs.push({ t: 'train', l, dz: len + gap + len / 2, opts: { len } });
    coins.push(...line(free, -2, 9, 1.6), ...line(f1, len + gap, 9, 1.6));
    return { len: len * 2 + gap + 2, obs, coins };
  } },
  { name: 'crateSlalom', w: 1.4, min: 400, build({ rng, free, speed }) {
    const sp = speed * 0.6 + 6, obs = [], coins = []; let f = free;
    for (let i = 0; i < 3; i++) { for (const l of others(f)) obs.push({ t: 'crates', l, dz: i * sp }); coins.push(...line(f, i * sp - 3, 5, 1.5)); f = clampL(f + stepFrom(rng, f)); }
    return { len: sp * 2 + 4, obs, coins };
  } },
  { name: 'jumpSlide', w: 1.6, min: 450, build({ rng, speed }) {
    const D = speed * 0.85 + 5, l = rng.pick(LN);
    return { len: D + 8, obs: [...LN.map((x) => ({ t: 'barrier', l: x, dz: 0 })), ...LN.map((x) => ({ t: 'overhead', l: x, dz: D }))], coins: [...arc(l, -3, 8, 1.0, 2.0), ...line(l, D - 2, 6, 1.0, 0.55)] };
  } },
  { name: 'slideJump', w: 1.3, min: 600, build({ rng, speed }) {
    const D = speed * 0.85 + 5, l = rng.pick(LN);
    return { len: D + 8, obs: [...LN.map((x) => ({ t: 'overhead', l: x, dz: 0 })), ...LN.map((x) => ({ t: 'crate1', l: x, dz: D }))], coins: [...line(l, -3, 6, 1.0, 0.55), ...arc(l, D - 3, 8, 1.0, 2.1)] };
  } },
  { name: 'tuktukRush', w: 1.6, min: 350, build({ rng, free }) {
    const o = others(free);
    return { len: 16, obs: [{ t: 'tuktuk', l: o[0], dz: 0 }, { t: 'tuktuk', l: o[1], dz: rng.range(6, 12) }], coins: line(free, -2, 12, 1.6) };
  } },
  { name: 'barrelRun', w: 1.5, min: 300, build({ rng, free }) {
    const ph = rng.range(0, 6.28);
    return { len: 26, obs: [{ t: 'barrel', l: 0, dz: 0, opts: { phase: ph } }, { t: 'barrel', l: 0, dz: 13, opts: { phase: ph + Math.PI } }], coins: [...line(free, -2, 6, 1.6), ...line(free, 14, 6, 1.6)] };
  } },
  { name: 'mixed', w: 1.5, min: 700, build({ rng, speed }) {
    const sp = speed * 0.75 + 5, ts = ['barrier', 'overhead', 'crates', 'crate1', 'cart'], obs = [], coins = []; let l = rng.pick(LN);
    for (let i = 0; i < 3; i++) { const t = rng.pick(ts); obs.push({ t, l, dz: i * sp }); const nl = clampL(l + stepFrom(rng, l)); coins.push(...line(nl, i * sp + 2, 4, 1.4)); l = nl; }
    return { len: sp * 2 + 4, obs, coins };
  } },
  { name: 'trainBarrier', w: 1.5, min: 800, build({ rng }) {
    const s = LN.slice().sort(() => rng.next() - 0.5);
    const len = rng.range(14, 20);
    return { len: len + 2, obs: [{ t: 'train', l: s[0], dz: len / 2, opts: { len } }, { t: 'barrier', l: s[1], dz: 4 }, { t: 'overhead', l: s[2], dz: 4 }], coins: [...arc(s[1], 0, 8, 1.0, 2.0), ...line(s[2], 1, 6, 1, 0.55)] };
  } },
  { name: 'coinRiver', w: 1.6, min: 0, build({ rng }) {
    const coins = []; let l = rng.pick(LN), dz = 0; const segs = rng.int(3, 5);
    for (let s = 0; s < segs; s++) { coins.push(...line(l, dz, 7, 1.3)); dz += 9; const nl = clampL(l + rng.pick([-1, 1])); for (let i = 1; i <= 3; i++) coins.push({ l: l + (nl - l) * i / 4, dz: dz - 2 + i * 0.6, y: 0.9 }); l = nl; }
    if (rng.chance(0.5)) coins[rng.int(0, coins.length - 1)].rare = true;
    return { len: dz + 2, obs: [], coins };
  } },
  { name: 'breather', w: 1, min: 0, build({ rng }) { return { len: 12, obs: [], coins: line(rng.pick(LN), 0, 10, 1.4) }; } },
];

export function powerRow(rng, kind) {
  const l = rng.pick(LN);
  return { len: 14, obs: [], coins: [...line(l, -3, 5, 1.6), { l, dz: 6, y: 1.1, power: kind }, ...line(l, 8, 5, 1.6)] };
}
export { others, LN };
