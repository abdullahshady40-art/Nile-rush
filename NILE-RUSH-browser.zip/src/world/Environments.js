// The seven world environments. Order defines the cycle; each lasts CFG.envLen metres.
import { SIGN } from './SignAtlas.js';

export const ENVS = [
  { id: 'cairo',   name: 'Cairo & the Nile', ar: 'القاهرة',      tod: 'day',    sign: SIGN.ENV0, style: 'city',    fogScale: 1.0,  accent: [0.96, 0.75, 0.27] },
  { id: 'desert',  name: 'Desert Road',      ar: 'طريق الصحراء',  tod: 'day',    sign: SIGN.ENV1, style: 'desert',  fogScale: 1.05, accent: [0.95, 0.72, 0.4] },
  { id: 'bridge',  name: 'Nile Bridge',      ar: 'كوبري النيل',   tod: 'day',    sign: SIGN.ENV2, style: 'bridge',  fogScale: 1.1,  accent: [0.5, 0.8, 1] },
  { id: 'station', name: 'Train Station',    ar: 'محطة القطار',   tod: 'sunset', sign: SIGN.ENV3, style: 'station', fogScale: 0.9,  accent: [1, 0.55, 0.35] },
  { id: 'sunset',  name: 'Nile Sunset',      ar: 'غروب النيل',    tod: 'sunset', sign: SIGN.ENV5, style: 'sunset',  fogScale: 1.0,  accent: [1, 0.6, 0.3] },
  { id: 'night',   name: 'Night Egypt',      ar: 'ليل مصر',       tod: 'night',  sign: SIGN.ENV4, style: 'night',   fogScale: 0.95, accent: [0.55, 0.9, 0.85] },
  { id: 'storm',   name: 'Dust Storm',       ar: 'عاصفة رمال',    tod: 'storm',  sign: SIGN.ENV6, style: 'storm',   fogScale: 1.0,  accent: [1, 0.75, 0.45] },
];
export const ENV_COUNT = ENVS.length;
