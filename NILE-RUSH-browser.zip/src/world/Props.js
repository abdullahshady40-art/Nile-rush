import * as M from '../core/mat4.js';
import { hex } from '../core/Utils.js';
import { SIGN } from './SignAtlas.js';

export const shade = (c, k) => [c[0] * k, c[1] * k, c[2] * k];
export const C = {
  asphalt: hex('#3b3e44'), sandRoad: hex('#7a6a52'), curb: hex('#bdb6a6'), pavement: hex('#a89f8d'), pavementLight: hex('#cbc2aa'),
  dirt: hex('#8f7c5c'), sand: hex('#e0bd7c'), sandDark: hex('#c79b54'), sandLight: hex('#eed39c'), stone: hex('#d8c496'), stoneDark: hex('#a48f66'),
  water: hex('#1d7088'), waterDusk: hex('#3a6f86'), trunk: hex('#6d4c2f'), leaf: hex('#2f6b2a'), leaf2: hex('#3f8a34'), leafDry: hex('#7a7a3a'),
  white: [0.93, 0.93, 0.9], dark: [0.11, 0.11, 0.13], metal: hex('#6b7280'), metalLight: hex('#9aa3af'), wood: hex('#8a5a33'), woodDark: hex('#5b3a22'),
  lane: [0.92, 0.9, 0.82], laneEdge: [0.95, 0.78, 0.25], copper: hex('#3f9a86'), gold: hex('#f2b84b'), glass: hex('#1a2633'), lampWarm: hex('#ffcf7a'),
  bldg: [hex('#e3c89a'), hex('#d9a97a'), hex('#cf9b6b'), hex('#e8dcc0'), hex('#c9b591'), hex('#e0b48c'), hex('#b5c4b0'), hex('#d8b7a0'), hex('#9fb4c4'), hex('#e5d3ae')],
  bldgOld: [hex('#c7a06a'), hex('#b98a5a'), hex('#d1b27e'), hex('#a9855c'), hex('#c4a578')],
  awning: [hex('#c0392b'), hex('#1f7a8c'), hex('#e0a526'), hex('#2e8b57'), hex('#7a3e9d')],
  train: [hex('#2f6f8f'), hex('#b3382c'), hex('#3a7d44'), hex('#e0a526'), hex('#5b6c8a')],
};
export const SHOP_SIGNS = [SIGN.KOSHARI, SIGN.FUL, SIGN.CAFE, SIGN.PHARMACY, SIGN.JUICE, SIGN.BAKERY, SIGN.SWEETS, SIGN.GARAGE, SIGN.GROCERY, SIGN.FISH, SIGN.TEA, SIGN.BAZAAR, SIGN.HOTEL];
const NO = {};

/** Collects static instances (with pre-baked matrices) grouped by geometry+pass for one world segment. */
export class Deco {
  constructor(geo) { this.geo = geo; this.groups = new Map(); this.m = M.create(); this.dyn = []; }
  _g(name, pass) {
    const key = name + ':' + pass; let g = this.groups.get(key);
    if (!g) { g = { geo: this.geo[name], pass, arr: new Float32Array(24 * 48), n: 0 }; this.groups.set(key, g); }
    return g;
  }
  add(name, x, y, z, sx, sy, sz, c, o = NO) {
    const g = this._g(name, o.pass || 0);
    if ((g.n + 1) * 24 > g.arr.length) { const a = new Float32Array(g.arr.length * 2); a.set(g.arr); g.arr = a; }
    M.compose(this.m, x, y, z, o.rx || 0, o.ry || 0, o.rz || 0, sx, sy, sz);
    const d = g.arr, k = g.n * 24; d.set(this.m, k);
    d[k + 16] = c[0]; d[k + 17] = c[1]; d[k + 18] = c[2]; d[k + 19] = o.a === undefined ? 1 : o.a;
    d[k + 20] = o.em || 0; d[k + 21] = o.pat || 0; d[k + 22] = o.p1 || 0; d[k + 23] = 0; g.n++;
  }
  // base-anchored helpers (y = bottom)
  box(x, y, z, w, h, d, c, o) { this.add('box', x, y + h / 2, z, w, h, d, c, o); }
  cyl(x, y, z, dia, h, c, o) { this.add('cyl', x, y + h / 2, z, dia, h, dia, c, o); }
  cone(x, y, z, dia, h, c, o) { this.add('cone', x, y + h / 2, z, dia, h, dia, c, o); }
  sphere(x, y, z, dia, c, o) { this.add('sphere', x, y, z, dia, dia, dia, c, o); }
  dome(x, y, z, dia, c, o) { this.add('dome', x, y, z, dia, dia, dia, c, o); }
  glow(x, y, z, size, c, a = 0.35) { this.add('sphere', x, y, z, size, size, size, c, { pat: 14, a, pass: 2 }); }
  items() { return [...this.groups.values()].filter((g) => g.n > 0); }
}

// ---------------------------------------------------------------- ground / road
export function ground(d, ctx, x0, x1, y, c, pat = 0) { d.add('plane', (x0 + x1) / 2, y, ctx.z0 - ctx.L / 2, x1 - x0, 1, ctx.L, c, { pat }); }

export function road(d, ctx, c = C.asphalt, o = NO) {
  const { z0, L } = ctx, zc = z0 - L / 2;
  d.add('plane', 0, 0, zc, 8.8, 1, L, c, { pat: o.pat === undefined ? 6 : o.pat });
  for (let k = 0; k < 5; k++) for (const x of [-1.2, 1.2]) d.box(x, 0, z0 - 1.6 - k * 6.4, 0.14, 0.03, 3.2, C.lane);
  for (const x of [-3.9, 3.9]) d.box(x, 0, zc, 0.12, 0.03, L, o.edge || C.laneEdge);
  if (!o.noCurb) for (const x of [-4.55, 4.55]) d.box(x, 0, zc, 0.5, 0.2, L, C.curb);
}

// ---------------------------------------------------------------- buildings
export function building(d, ctx, side, nearX, z, w, h, dp, o = NO) {
  const rng = ctx.rng, body = o.color || rng.pick(o.palette || C.bldg);
  const cx = nearX + side * dp / 2;
  d.box(cx, 0, z, dp, h, w, body, { pat: 1, p1: rng.int(0, 999) });
  d.box(cx, h, z, dp + 0.3, 0.45, w + 0.3, shade(body, 0.78));
  const r = rng.next();
  if (r < 0.28) d.cyl(cx + (rng.next() - 0.5) * dp * 0.4, h + 0.45, z + (rng.next() - 0.5) * w * 0.4, 1.7, 1.7, C.metal);
  else if (r < 0.5) d.cyl(cx, h + 0.45, z, 0.12, 4.5, C.dark);
  else if (r < 0.62) d.box(cx, h + 0.45, z, dp * 0.5, 2.6, w * 0.4, shade(body, 0.9), { pat: 1, p1: 7 });
  const floors = Math.floor(h / 2.9);
  if (o.balconies !== false && ctx.q.decor > 0.45) {
    for (let f = 2; f < floors; f++) if (rng.next() < 0.3) {
      const bz = z + (rng.next() - 0.5) * Math.max(0, w - 3.5);
      d.box(nearX - side * 0.5, f * 2.9, bz, 1.0, 0.14, 2.3, shade(body, 0.7));
      d.box(nearX - side * 1.0, f * 2.9 + 0.14, bz, 0.06, 0.95, 2.3, C.dark);
    }
  }
  if (o.shop !== false && rng.next() < 0.8) {
    const sz = z + (rng.next() - 0.5) * Math.max(0, w - 5);
    const awn = rng.pick(C.awning);
    d.add('box', nearX - side * 0.75, 2.5, sz, 1.6, 0.1, 4.2, awn, { pat: 13, rz: side * 0.28 });
    d.add('sign', nearX - side * 0.07, 3.55, sz, 3.2, 1.6, 1, [1, 1, 1], { pat: 11, p1: o.sign !== undefined ? o.sign : rng.pick(SHOP_SIGNS), ry: side < 0 ? Math.PI / 2 : -Math.PI / 2 });
    d.box(nearX - side * 0.05, 0.1, sz, 0.06, 2.2, 3.4, C.glass, { pat: 15, p1: 0.9 });
  }
}

export function minaret(d, x, z, h, c) {
  const cap = C.copper;
  d.box(x, 0, z, 2.8, h * 0.5, 2.8, c, { pat: 3 });
  d.box(x, h * 0.5, z, 3.3, 0.35, 3.3, shade(c, 0.82));
  d.cyl(x, h * 0.5 + 0.35, z, 1.7, h * 0.28, shade(c, 1.04));
  d.cyl(x, h * 0.78 + 0.35, z, 2.5, 0.3, shade(c, 0.82));
  d.cyl(x, h * 0.78 + 0.65, z, 1.3, h * 0.1, shade(c, 1.04), { pat: 15, p1: 0.6 });
  d.cone(x, h * 0.88 + 0.65, z, 1.6, h * 0.12 + 2.2, cap);
  d.add('torus', x, h + 3.2, z, 0.9, 0.9, 0.9, C.gold, { rx: Math.PI / 2, em: 0.4, pat: 15, p1: 1.4 });
}
export function mosqueDome(d, x, z, r, c) {
  d.box(x, 0, z, r * 1.5, 6, r * 1.5, c, { pat: 3 });
  d.dome(x, 6, z, r * 1.5, C.copper);
  d.cyl(x, 6 + r * 0.75, z, 0.2, 1.4, C.gold);
}

// ---------------------------------------------------------------- nature / street furniture
export function palm(d, x, z, h, rng, leaf = C.leaf, trunk = C.trunk) {
  const lean = rng.range(-0.25, 0.25);
  d.add('cyl', x, h * 0.17, z, 0.5, h * 0.34, 0.5, trunk);
  d.add('cyl', x + lean * 0.3, h * 0.5, z, 0.4, h * 0.34, 0.4, trunk);
  d.add('cyl', x + lean * 0.7, h * 0.83, z, 0.32, h * 0.34, 0.32, trunk);
  const cx = x + lean, cy = h;
  const n = 8;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2 + rng.range(-0.2, 0.2), pitch = -0.5 - rng.range(0, 0.25), len = rng.range(2.6, 3.2);
    const dx = Math.cos(a) * len * 0.45, dz = Math.sin(a) * len * 0.45;
    const k = 0.9 + rng.next() * 0.2;
    d.add('box', cx + dx, cy - 0.25 + Math.sin(pitch) * len * 0.35, z + dz, len, 0.06, 0.62, [leaf[0] * k, leaf[1] * k, leaf[2] * k], { ry: -a, rz: pitch });
  }
  d.sphere(cx + 0.15, cy - 0.2, z, 0.3, C.woodDark); d.sphere(cx - 0.15, cy - 0.3, z + 0.12, 0.28, C.woodDark);
}
export function deadPalm(d, x, z, h, rng) {
  d.add('cyl', x, h * 0.3, z, 0.4, h * 0.6, 0.4, C.trunk, { rz: rng.range(-0.15, 0.15) });
  for (let i = 0; i < 4; i++) { const a = rng.range(0, 6.28); d.add('box', x + Math.cos(a) * 0.8, h * 0.6 - 0.3, z + Math.sin(a) * 0.8, 1.8, 0.05, 0.3, C.leafDry, { ry: -a, rz: -0.9 }); }
}
export function lamp(d, x, z, side, o = NO) {
  const h = o.h || 6.2;
  d.cyl(x, 0, z, 0.16, h, C.dark);
  d.box(x - side * 0.9, h - 0.05, z, 1.9, 0.1, 0.12, C.dark);
  d.box(x - side * 1.7, h - 0.3, z, 0.7, 0.2, 0.34, C.lampWarm, { pat: 15, p1: 2.4 });
  d.glow(x - side * 1.7, h - 0.6, z, 2.6, C.lampWarm, 0.28);
}
export function bench(d, x, z, ry = 0) { d.box(x, 0.35, z, 0.5, 0.1, 1.8, C.wood, { ry }); d.box(x, 0, z - 0.7, 0.4, 0.4, 0.1, C.dark); d.box(x, 0, z + 0.7, 0.4, 0.4, 0.1, C.dark); }
export function rock(d, x, z, s, c, rng) { d.add('lowsphere', x, s * 0.25, z, s * rng.range(1.2, 1.7), s * rng.range(0.7, 1), s * rng.range(1.0, 1.5), c, { ry: rng.range(0, 6) }); }
export function dune(d, x, z, w, h, dp, c) { d.add('dome', x, -0.1, z, w, h * 2, dp, c, { pat: 5 }); }
export function pyramid(d, x, z, s, c) { d.add('pyramid', x, s * 0.35, z, s, s * 0.7, s, c, { pat: 3, ry: 0 }); }
export function obelisk(d, x, z, h, c) { d.box(x, 0, z, 2.6, 0.8, 2.6, C.stoneDark); d.cone(x, 0.8, z, 1.2, h, c, {}); d.add('cyl', x, 0.8 + h * 0.35, z, 1.15, h * 0.7, 1.15, c); d.add('pyramid', x, 0.8 + h * 0.72 + 0.6, z, 1.1, 1.2, 1.1, C.gold, { em: 0.2 }); }
export function sphinx(d, x, z, ry) {
  const s = C.sandLight, sd = C.sand;
  const o = { ry };
  const cs = Math.cos(ry), sn = Math.sin(ry);
  const P = (lx, lz) => [x + lx * cs + lz * sn, z - lx * sn + lz * cs];
  let [px, pz] = P(0, 0); d.add('box', px, 2, pz, 5.5, 4, 14, s, { ry, pat: 5 });
  [px, pz] = P(0, 9.2); d.add('box', px, 1.0, pz, 4.4, 2.0, 5.2, sd, { ry });
  [px, pz] = P(0, 6.4); d.add('box', px, 4.8, pz, 3.4, 3.4, 3.6, s, { ry });
  [px, pz] = P(0, 6.4); d.add('box', px, 6.9, pz, 4.4, 1.1, 4.4, C.stoneDark, { ry });
  [px, pz] = P(0, 6.6); d.add('box', px, 5.4, pz, 4.6, 5.8, 1.2, C.stoneDark, { ry });
}
export function tent(d, x, z, ry, c) { d.add('prism', x, 1.5, z, 5.5, 3, 6, c, { pat: 13, ry }); d.box(x, 0, z, 5.2, 0.1, 5.8, C.woodDark, { ry }); }

// ---------------------------------------------------------------- water & boats (dynamic)
export function addBoat(d, x, y, z, ry, sail) { d.dyn.push({ kind: 'boat', x, y, z, ry, sail, ph: Math.random() * 6.28 }); }
export function drawBoat(r, x, y, z, ry, sail, t, ph) {
  const g = r.geo, bob = Math.sin(t * 1.3 + ph) * 0.08, roll = Math.sin(t * 0.9 + ph) * 0.05;
  const cs = Math.cos(ry), sn = Math.sin(ry);
  const P = (lx, lz) => [x + lx * cs + lz * sn, z - lx * sn + lz * cs];
  let p = P(0, 0);
  r.submitTRS(g.box, p[0], y + 0.35 + bob, p[1], 0, ry, roll, 1.7, 0.7, 6.4, C.woodDark, 1, 0, 0, 0, 0);
  p = P(0, 3.6); r.submitTRS(g.box, p[0], y + 0.6 + bob, p[1], -0.4, ry, roll, 1.3, 0.55, 1.8, C.wood, 1, 0, 0, 0, 0);
  p = P(0, -3.4); r.submitTRS(g.box, p[0], y + 0.55 + bob, p[1], 0.2, ry, roll, 1.4, 0.5, 1.2, C.wood, 1, 0, 0, 0, 0);
  p = P(0, 0.4); r.submitTRS(g.cyl, p[0], y + 3 + bob, p[1], 0, ry, roll, 0.14, 5.4, 0.14, C.woodDark, 1, 0, 0, 0, 0);
  p = P(0, 0.2); r.submitTRS(g.prism, p[0], y + 3.4 + bob, p[1], 0, ry + Math.PI / 2, roll, 5.4, 4.6, 0.07, sail, 1, 0.1, 13, 0, 0);
}

// ---------------------------------------------------------------- bridges / stations / night
export function lion(d, x, z, ry) {
  const c = C.stone, k = { ry };
  const cs = Math.cos(ry), sn = Math.sin(ry); const P = (lx, lz) => [x + lx * cs + lz * sn, z - lx * sn + lz * cs];
  d.box(x, 0, z, 2.4, 1.3, 4, C.stoneDark, { ry, pat: 3 });
  let p = P(0, 0); d.add('box', p[0], 2.1, p[1], 1.3, 1.3, 2.6, c, k);
  p = P(0, -1.0); d.add('box', p[0], 3.0, p[1], 1.0, 1.7, 0.9, c, k);
  p = P(0, -1.2); d.add('sphere', p[0], 3.7, p[1], 1.1, 1.1, 1.1, c, k);
  p = P(0, -1.2); d.add('sphere', p[0], 3.7, p[1], 1.6, 1.6, 0.7, shade(c, 0.88), k);
}
export function trainCarDecor(d, x, z, len, color, ry = 0) {
  d.box(x, 0.6, z, 2.7, 3.0, len, color, { ry });
  d.box(x, 3.6, z, 2.5, 0.35, len - 0.4, shade(color, 1.15), { ry });
  d.box(x, 1.8, z, 2.74, 0.9, len - 1.2, C.glass, { pat: 15, p1: 0.9, ry });
  d.box(x, 0.2, z, 2.4, 0.5, len - 0.6, C.dark, { ry });
}
export function fanous(d, x, y, z, color) {
  d.cyl(x, y, z, 0.36, 0.55, color, { pat: 15, p1: 2.2 });
  d.cone(x, y + 0.55, z, 0.42, 0.25, C.gold);
  d.cone(x, y - 0.22, z, 0.3, 0.22, C.gold);
  d.glow(x, y + 0.28, z, 1.15, color, 0.22);
}
export function gate(d, ctx, sign, accent) {
  const z = ctx.z0 - 6;
  for (const x of [-6.2, 6.2]) { d.box(x, 0, z, 1.4, 8.5, 1.4, C.stone, { pat: 3 }); d.box(x, 8.5, z, 1.9, 0.5, 1.9, C.stoneDark); }
  d.box(0, 8.3, z, 14, 1.5, 1.3, C.stone, { pat: 3 });
  d.add('sign', 0, 8.95, z + 0.7, 6, 3, 1, [1, 1, 1], { pat: 11, p1: sign });
  d.box(0, 9.8, z, 14.4, 0.4, 1.6, accent, { em: 0.35 });
}
