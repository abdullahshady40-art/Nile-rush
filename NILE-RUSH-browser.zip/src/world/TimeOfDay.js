import { CFG } from '../core/Config.js';
import { smoothstep, lerp, clamp } from '../core/Utils.js';
import { ENVS } from './Environments.js';

// Lighting palettes. The active palette is blended between the current and the next environment.
const norm = (v) => { const l = Math.hypot(v[0], v[1], v[2]); return [v[0] / l, v[1] / l, v[2] / l]; };
export const PALETTES = {
  day: {
    skyTop: [0.17, 0.42, 0.84], skyMid: [0.52, 0.74, 0.94], skyBot: [0.86, 0.90, 0.92],
    sunDir: norm([0.35, 0.72, 0.5]), sunCol: [1.0, 0.93, 0.78], ambS: [0.50, 0.56, 0.68], ambG: [0.40, 0.36, 0.30],
    fogCol: [0.84, 0.89, 0.92], fogNear: 40, fogFar: 200, night: 0, cloud: 0.9, cloudCol: [1, 1, 1], grade: [1, 1, 1],
  },
  sunset: {
    skyTop: [0.20, 0.20, 0.50], skyMid: [0.88, 0.40, 0.32], skyBot: [1.0, 0.68, 0.36],
    sunDir: norm([0.55, 0.16, -0.82]), sunCol: [1.0, 0.56, 0.26], ambS: [0.50, 0.38, 0.46], ambG: [0.34, 0.24, 0.22],
    fogCol: [0.96, 0.62, 0.42], fogNear: 30, fogFar: 190, night: 0.12, cloud: 0.9, cloudCol: [1.0, 0.62, 0.5], grade: [1.04, 0.98, 0.94],
  },
  night: {
    skyTop: [0.015, 0.025, 0.09], skyMid: [0.05, 0.08, 0.2], skyBot: [0.10, 0.15, 0.30],
    sunDir: norm([-0.4, 0.6, -0.6]), sunCol: [0.42, 0.52, 0.85], ambS: [0.16, 0.20, 0.36], ambG: [0.08, 0.08, 0.14],
    fogCol: [0.06, 0.09, 0.19], fogNear: 30, fogFar: 185, night: 1, cloud: 0.25, cloudCol: [0.12, 0.16, 0.3], grade: [0.95, 1.0, 1.1],
  },
  storm: {
    skyTop: [0.42, 0.28, 0.16], skyMid: [0.74, 0.50, 0.28], skyBot: [0.82, 0.58, 0.34],
    sunDir: norm([0.3, 0.5, 0.6]), sunCol: [0.95, 0.66, 0.38], ambS: [0.52, 0.40, 0.30], ambG: [0.34, 0.26, 0.18],
    fogCol: [0.78, 0.56, 0.34], fogNear: 4, fogFar: 92, night: 0.06, cloud: 1, cloudCol: [0.7, 0.5, 0.3], grade: [1.05, 0.98, 0.9],
  },
};
const V3 = ['skyTop', 'skyMid', 'skyBot', 'sunDir', 'sunCol', 'ambS', 'ambG', 'fogCol', 'cloudCol', 'grade'];
const S1 = ['fogNear', 'fogFar', 'night', 'cloud'];

/** Computes sky/lighting for a given distance: blends environment palettes; supports a forced time-of-day. */
export class Atmosphere {
  constructor() {
    this.out = { flash: 0 };
    for (const k of V3) this.out[k] = new Float32Array(3);
    for (const k of S1) this.out[k] = 0;
    this.envIndex = 0; this.blend = 0; this.flashT = 0; this.cur = null; this.next = null;
    this.forced = 'auto';
  }
  setForced(mode) { this.forced = mode; }
  envAt(dist) { return ENVS[Math.floor(Math.max(dist, 0) / CFG.envLen) % ENVS.length]; }
  update(dist, dt, time) {
    const idx = Math.floor(Math.max(dist, 0) / CFG.envLen);
    const local = dist - idx * CFG.envLen;
    const cur = ENVS[idx % ENVS.length], next = ENVS[(idx + 1) % ENVS.length];
    const t = smoothstep(CFG.envLen - CFG.envBlend, CFG.envLen, local);
    this.cur = cur; this.next = next; this.blend = t; this.envIndex = idx;
    const tod = (e) => (this.forced !== 'auto' && e.tod !== 'storm' ? this.forced : e.tod);
    const A = PALETTES[tod(cur)], B = PALETTES[tod(next)], o = this.out;
    for (const k of V3) for (let i = 0; i < 3; i++) o[k][i] = lerp(A[k][i], B[k][i], t);
    for (const k of S1) o[k] = lerp(A[k], B[k], t);
    const fogS = lerp(cur.fogScale || 1, next.fogScale || 1, t);
    o.fogFar *= fogS; o.fogNear *= Math.min(1, fogS);
    // lightning flashes during storms
    const stormW = (tod(cur) === 'storm' ? 1 - t : 0) + (tod(next) === 'storm' ? t : 0);
    this.flashT -= dt;
    if (stormW > 0.6 && this.flashT < -3 && Math.random() < dt * 0.25) { this.flashT = 0.35; }
    o.flash = this.flashT > 0 ? Math.max(0, Math.sin(this.flashT * 22)) * 0.35 * clamp(stormW, 0, 1) : 0;
    o.time = time;
    return o;
  }
  /** Ambient particle kind and rate (per second) for the current blend. */
  ambientFx() {
    const A = this.cur.tod, B = this.next.tod, t = this.blend;
    const main = t > 0.5 ? B : A;
    if (main === 'night') return ['firefly', 6];
    if (main === 'storm') return ['sand', 70];
    if (main === 'sunset') return ['ember', 6];
    return ['mote', 5];
  }
}
