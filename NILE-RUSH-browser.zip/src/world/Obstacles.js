import { Pool } from '../core/Pool.js';
import { CFG } from '../core/Config.js';
import { hex } from '../core/Utils.js';
import { C, shade } from './Props.js';
import { SIGN } from './SignAtlas.js';

/**
 * Obstacle catalogue. Every obstacle is one AABB (x, z centre; yb bottom; h height; hw/hd half sizes).
 *  jump  : can be cleared by jumping        slide : can be passed by sliding
 *  vz    : world speed towards the player   sway  : lateral oscillation amplitude (metres)
 */
export const OBSTACLE_TYPES = {
  barrier:  { w: 2.0, h: 0.9,  d: 0.5, yb: 0,    jump: true },
  crate1:   { w: 1.8, h: 1.0,  d: 1.0, yb: 0,    jump: true },
  overhead: { w: 2.2, h: 1.5,  d: 0.6, yb: 1.35, slide: true },
  crates:   { w: 1.9, h: 2.4,  d: 1.3, yb: 0 },
  cart:     { w: 2.0, h: 1.9,  d: 3.6, yb: 0 },
  fruitcart:{ w: 2.0, h: 2.1,  d: 2.0, yb: 0 },
  tuktuk:   { w: 1.5, h: 1.7,  d: 2.4, yb: 0,    vz: 6 },
  barrel:   { w: 1.0, h: 1.05, d: 1.0, yb: 0,    jump: true, sway: 2.4 },
  train:    { w: 2.1, h: 3.4,  d: 14,  yb: 0,    vz: 0 },
};
const STYLE_VARIANTS = {
  barrier:  { city: [0, 3], desert: [1], bridge: [0, 3], station: [2], night: [3, 0], sunset: [0, 3], storm: [1, 3] },
  overhead: { city: [0, 2], desert: [1, 2], bridge: [0, 1], station: [3], night: [2, 0], sunset: [0, 2], storm: [1] },
  crate1:   { city: [0], desert: [1], bridge: [0], station: [2], night: [0], sunset: [0], storm: [1] },
  crates:   { city: [0], desert: [1], bridge: [0], station: [2], night: [0], sunset: [0], storm: [1] },
  train:    { city: [0, 1], desert: [2], bridge: [0], station: [0, 1], night: [1], sunset: [0, 1], storm: [2] },
};
const TUK = [hex('#2f74c0'), hex('#f2c21b'), hex('#2e9b57'), hex('#d8442f')];
const CRATE = hex('#a8763e'), CRATE_D = hex('#6b4a28'), STRAW = hex('#d8b65a'), SAND_STONE = hex('#d2b57a'), ORANGE = hex('#f08a1c');

export class Obstacles {
  constructor(renderer) {
    this.r = renderer; this.g = renderer.geo;
    this.pool = new Pool(() => ({ type: '', variant: 0, x: 0, z: 0, yb: 0, h: 1, hw: 1, hd: 1, vz: 0, sway: 0, phase: 0, baseX: 0, t: 0, col: 0, counted: false, near: false, len: 14, sign: 0 }), 110);
  }
  clear() { this.pool.releaseAll(); }

  spawn(type, lane, dist, style, rng, opts = {}) {
    const o = this.pool.acquire(); if (!o) return null;
    const def = OBSTACLE_TYPES[type];
    o.type = type; o.baseX = lane * CFG.laneWidth; o.x = o.baseX; o.z = -dist; o.yb = def.yb; o.h = def.h;
    o.hw = def.w / 2; o.vz = opts.vz !== undefined ? opts.vz : def.vz || 0; o.sway = opts.sway !== undefined ? opts.sway : def.sway || 0;
    o.len = opts.len || def.d; o.hd = (type === 'train' ? o.len : def.d) / 2;
    o.phase = opts.phase !== undefined ? opts.phase : rng.range(0, 6.28); o.t = 0; o.counted = false; o.near = false; o.smashed = false;
    const vl = STYLE_VARIANTS[type] && STYLE_VARIANTS[type][style];
    o.variant = vl ? rng.pick(vl) : 0; o.col = rng.int(0, 3); o.sign = rng.chance(0.5) ? SIGN.DETOUR : SIGN.CAUTION;
    if (type === 'crates' && o.variant === 2) o.h = 2.2;
    return o;
  }

  update(dt, playerZ) {
    this.pool.forEachAlive((o) => {
      o.t += dt;
      if (o.vz) o.z += o.vz * dt;
      if (o.sway) o.x = Math.max(-CFG.laneWidth, Math.min(CFG.laneWidth, o.baseX + Math.sin(o.t * 2.2 + o.phase) * o.sway));
      if (o.z - o.hd > playerZ + CFG.despawnBehind) o.alive = false;
    });
  }

  draw(t, shadowLevel) {
    const r = this.r;
    this.pool.forEachAlive((o) => {
      this._draw(o, t);
      if (shadowLevel >= 2 && o.type !== 'train') r.submitTRS(this.g.plane, o.x, 0.03, o.z, 0, 0, 0, o.hw * 2 + 0.7, 1, o.hd * 2 + 0.7, [0, 0, 0], 0.5, 0, 9, 0, 1);
    });
  }

  _draw(o, t) {
    const r = this.r, g = this.g, x = o.x, z = o.z;
    const B = (dx, cy, dz, sx, sy, sz, c, em = 0, pat = 0, p1 = 0, ry = 0) => r.submitTRS(g.box, x + dx, cy, z + dz, 0, ry, 0, sx, sy, sz, c, 1, em, pat, p1, 0);
    const Cy = (dx, cy, dz, dia, h, c, em = 0, rx = 0, rz = 0) => r.submitTRS(g.cyl, x + dx, cy, z + dz, rx, 0, rz, dia, h, dia, c, 1, em, 0, 0, 0);
    switch (o.type) {
      case 'barrier':
        if (o.variant === 0) { // striped roadwork barrier
          B(-0.85, 0.35, 0, 0.14, 0.7, 0.42, C.dark); B(0.85, 0.35, 0, 0.14, 0.7, 0.42, C.dark);
          B(0, 0.7, 0, 2.0, 0.34, 0.14, [1, 0.8, 0.1], 0, 2); B(0, 0.36, 0, 2.0, 0.28, 0.14, [1, 0.8, 0.1], 0, 2);
          B(0, 0.95, 0, 0.16, 0.16, 0.16, [1, 0.2, 0.1], 1, 10);
        } else if (o.variant === 1) { // sandstone block with carved band
          B(0, 0.45, 0, 2.0, 0.9, 0.7, SAND_STONE, 0, 3); B(0, 0.8, 0.36, 2.0, 0.12, 0.02, C.gold, 0.2); B(0, 0.5, 0.36, 1.6, 0.06, 0.02, C.stoneDark);
        } else if (o.variant === 2) { // station luggage trolley
          B(0, 0.4, 0, 1.9, 0.12, 0.8, C.metal); B(0.6, 0.65, 0.1, 0.7, 0.45, 0.5, [0.75, 0.2, 0.15]); B(-0.3, 0.68, -0.05, 0.9, 0.5, 0.55, [0.2, 0.35, 0.6]); B(-0.9, 0.8, 0, 0.08, 0.9, 0.7, C.dark);
          for (const sx of [-0.8, 0.8]) for (const sz of [-0.32, 0.32]) Cy(sx, 0.16, sz, 0.32, 0.1, C.dark, 0, 0, Math.PI / 2);
        } else { // wooden fence
          B(-0.9, 0.45, 0, 0.14, 0.9, 0.14, C.woodDark); B(0.9, 0.45, 0, 0.14, 0.9, 0.14, C.woodDark); B(0, 0.7, 0, 2.0, 0.16, 0.08, C.wood); B(0, 0.38, 0, 2.0, 0.16, 0.08, C.wood); B(0, 0.54, 0.06, 0.1, 0.5, 0.05, C.wood);
        }
        break;
      case 'crate1':
        if (o.variant === 1) { for (let i = 0; i < 3; i++) r.submitTRS(g.lowsphere, x - 0.55 + i * 0.55, 0.28, z, 0, 0, 0, 0.7, 0.5, 0.9, [0.78, 0.66, 0.42], 1, 0, 0, 0, 0); for (let i = 0; i < 2; i++) r.submitTRS(g.lowsphere, x - 0.28 + i * 0.55, 0.72, z, 0, 0, 0, 0.7, 0.5, 0.9, [0.72, 0.6, 0.38], 1, 0, 0, 0, 0); }
        else if (o.variant === 2) { B(-0.35, 0.3, 0, 1.0, 0.6, 0.7, [0.25, 0.4, 0.65]); B(0.45, 0.4, 0.05, 0.8, 0.8, 0.6, [0.7, 0.25, 0.2]); B(0, 0.82, 0, 0.7, 0.36, 0.5, [0.85, 0.7, 0.3]); }
        else { B(0, 0.5, 0, 1.7, 1.0, 1.0, CRATE, 0, 3); B(0, 0.5, 0.51, 1.72, 0.12, 0.02, CRATE_D); B(0, 0.95, 0, 1.74, 0.1, 1.04, CRATE_D); B(0, 0.05, 0, 1.74, 0.1, 1.04, CRATE_D); }
        break;
      case 'overhead':
        B(-1.1, 1.6, 0, 0.14, 3.2, 0.14, C.dark); B(1.1, 1.6, 0, 0.14, 3.2, 0.14, C.dark);
        if (o.variant === 0) { B(0, 2.7, 0, 2.4, 0.14, 0.14, C.dark); r.submitTRS(g.sign, x, 1.95, z, 0, 0, 0, 2.2, 1.1, 1, [1, 1, 1], 1, 0.15, 11, o.sign, 0); }
        else if (o.variant === 1) { for (let i = 0; i < 3; i++) Cy(0, 1.6 + i * 0.32, 0, 0.24, 2.3, C.metal, 0, 0, Math.PI / 2); }
        else if (o.variant === 2) { B(0, 2.75, 0, 2.3, 0.05, 0.05, C.dark); const cl = [[0.9, 0.3, 0.25], [0.2, 0.6, 0.8], [0.95, 0.8, 0.2], [0.4, 0.7, 0.4], [0.9, 0.9, 0.9]]; for (let i = 0; i < 5; i++) B(-0.9 + i * 0.45, 2.1 + Math.sin(t * 2 + i) * 0.03, 0, 0.36, 1.2, 0.04, cl[i], 0, 13); }
        else { B(0, 2.45, 0, 2.4, 0.5, 0.5, C.metal); B(0.5, 1.95, 0.28, 0.16, 0.16, 0.04, [1, 0.2, 0.1], 1.4, 10); B(-0.5, 1.95, 0.28, 0.16, 0.16, 0.04, [0.2, 1, 0.3], 1.4, 10); }
        break;
      case 'crates':
        if (o.variant === 1) { B(0, 0.6, 0, 1.9, 1.2, 1.3, SAND_STONE, 0, 3); B(0.05, 1.7, 0, 1.7, 1.0, 1.1, shade(SAND_STONE, 0.9), 0, 3, 0, 0.1); B(0, 2.3, 0, 1.2, 0.2, 0.9, C.gold, 0.15); }
        else if (o.variant === 2) { B(-0.4, 0.55, 0, 1.0, 1.1, 0.9, [0.25, 0.4, 0.65]); B(0.5, 0.65, 0, 0.8, 1.3, 0.8, [0.7, 0.25, 0.2]); B(0, 1.75, 0, 1.6, 1.0, 0.9, [0.9, 0.75, 0.3]); B(0, 2.3, 0, 0.6, 0.2, 0.3, C.dark); }
        else { B(0, 0.55, 0, 1.9, 1.1, 1.3, CRATE, 0, 3); B(0.05, 1.65, 0, 1.75, 1.1, 1.2, shade(CRATE, 1.05), 0, 3, 0, 0.12); B(-0.1, 2.3, 0, 1.0, 0.25, 0.9, STRAW); B(0, 0.55, 0.66, 1.92, 0.1, 0.02, CRATE_D); }
        break;
      case 'cart': {
        B(0, 0.75, 0.2, 1.6, 0.32, 2.2, C.wood, 0, 3); B(-0.8, 1.1, 0.2, 0.08, 0.5, 2.2, C.woodDark); B(0.8, 1.1, 0.2, 0.08, 0.5, 2.2, C.woodDark);
        B(0, 1.45, 0.2, 1.5, 0.85, 1.9, STRAW);
        const sp = z * 0.8;
        for (const sx of [-0.92, 0.92]) r.submitTRS(g.cyl, x + sx, 0.55, z + 0.4, sp, 0, Math.PI / 2, 1.1, 0.12, 1.1, C.woodDark, 1, 0, 0, 0, 0);
        B(0, 1.0, -1.3, 0.62, 0.7, 1.3, [0.55, 0.52, 0.5]); B(0, 1.42, -2.0, 0.34, 0.5, 0.7, [0.5, 0.47, 0.45]); B(-0.1, 1.72, -1.9, 0.08, 0.3, 0.1, [0.45, 0.42, 0.4]); B(0.1, 1.72, -1.9, 0.08, 0.3, 0.1, [0.45, 0.42, 0.4]);
        for (const sx of [-0.2, 0.2]) for (const sz of [-0.85, -1.7]) B(sx, 0.35, sz, 0.14, 0.7, 0.14, [0.45, 0.42, 0.4]);
        B(0, 0.85, -0.5, 0.1, 0.1, 1.2, C.woodDark);
        break; }
      case 'fruitcart':
        B(0, 0.8, 0, 1.8, 0.14, 1.3, C.wood, 0, 3); for (const sx of [-0.85, 0.85]) for (const sz of [-0.6, 0.6]) B(sx, 1.05, sz, 0.08, 2.1, 0.08, C.woodDark);
        B(0, 1.95, 0, 2.1, 0.08, 1.7, [0.85, 0.3, 0.2], 0, 13, 0, 0);
        for (let i = 0; i < 3; i++) { B(-0.55 + i * 0.55, 1.0, 0, 0.5, 0.2, 0.9, CRATE); for (let j = 0; j < 4; j++) r.submitTRS(g.sphere, x - 0.55 + i * 0.55 + (j % 2 - 0.5) * 0.2, 1.2, z + (j < 2 ? -0.2 : 0.2), 0, 0, 0, 0.24, 0.24, 0.24, i === 1 ? [0.95, 0.75, 0.15] : ORANGE, 1, 0, 0, 0, 0); }
        for (const sx of [-0.95, 0.95]) r.submitTRS(g.cyl, x + sx, 0.42, z + 0.9, z * 0.9, 0, Math.PI / 2, 0.84, 0.1, 0.84, C.woodDark, 1, 0, 0, 0, 0);
        break;
      case 'tuktuk': {
        const c = TUK[o.col];
        B(0, 0.75, 0.1, 1.25, 0.8, 1.7, c); B(0, 0.5, -0.9, 0.8, 0.5, 0.7, c); B(0, 1.7, 0.25, 1.35, 0.1, 1.4, C.dark); B(-0.62, 1.2, 0.25, 0.06, 1.0, 0.06, C.dark); B(0.62, 1.2, 0.25, 0.06, 1.0, 0.06, C.dark);
        B(0, 1.3, -0.6, 0.9, 0.55, 0.05, [0.6, 0.8, 0.9]); B(0, 0.8, -1.25, 0.3, 0.2, 0.05, [1, 0.95, 0.7], 1.6, 10);
        B(0, 1.3, 0.95, 1.0, 0.4, 0.04, [0.15, 0.15, 0.17]);
        const sp = t * 12;
        r.submitTRS(g.cyl, x, 0.3, z - 0.95, sp, 0, Math.PI / 2, 0.6, 0.16, 0.6, C.dark, 1, 0, 0, 0, 0);
        for (const sx of [-0.6, 0.6]) r.submitTRS(g.cyl, x + sx, 0.3, z + 0.7, sp, 0, Math.PI / 2, 0.6, 0.16, 0.6, C.dark, 1, 0, 0, 0, 0);
        break; }
      case 'barrel':
        r.submitTRS(g.cyl, x, 0.53, z, 0, o.t * 4, 0, 0.98, 1.05, 0.98, [0.78, 0.25, 0.15], 1, 0, 0, 0, 0);
        for (const yy of [0.2, 0.86]) r.submitTRS(g.cyl, x, yy, z, 0, o.t * 4, 0, 1.02, 0.09, 1.02, C.dark, 1, 0, 0, 0, 0);
        r.submitTRS(g.cyl, x, 1.06, z, 0, 0, 0, 0.6, 0.03, 0.6, [0.9, 0.85, 0.2], 1, 0.2, 0, 0, 0);
        break;
      case 'train': {
        const L = o.len, pal = C.train, col = pal[(o.col + o.variant) % pal.length];
        if (o.variant === 2) { // freight wagon
          B(0, 0.5, 0, 1.9, 0.3, L, C.dark); B(0, 1.9, 0, 2.1, 2.5, L - 0.4, [0.55, 0.32, 0.22], 0, 3); B(0, 3.25, 0, 2.2, 0.16, L - 0.2, [0.4, 0.25, 0.2]);
          for (let k = -Math.floor(L / 4); k <= Math.floor(L / 4); k++) B(0, 1.9, k * 3.4, 2.14, 2.4, 0.12, [0.3, 0.2, 0.16]);
        } else {
          B(0, 0.5, 0, 1.9, 0.6, L - 0.6, C.dark); B(0, 1.9, 0, 2.1, 2.5, L, col);
          B(0, 3.25, 0, 1.9, 0.3, L - 0.2, [0.85, 0.87, 0.9]); B(0, 2.2, 0, 2.14, 0.85, L - 1.2, C.glass, 0, 15, 1.4); B(0, 1.25, 0, 2.15, 0.16, L - 0.4, [0.95, 0.8, 0.2]);
          for (let k = -Math.floor(L / 6); k <= Math.floor(L / 6); k++) B(0, 1.7, k * 4.6, 2.16, 1.6, 0.1, shade(col, 0.6));
        }
        const f = o.vz > 0 ? L / 2 + 0.03 : L / 2 + 0.03; // headlights on the +z (player-facing) end
        B(-0.62, 1.0, f, 0.34, 0.26, 0.06, [1, 0.96, 0.8], 2.2, 10); B(0.62, 1.0, f, 0.34, 0.26, 0.06, [1, 0.96, 0.8], 2.2, 10);
        B(0, 2.55, f, 1.5, 0.7, 0.06, C.glass, 0.1); B(0, 3.05, f, 0.5, 0.16, 0.06, [1, 0.6, 0.15], 1.6, 10);
        break; }
      default: break;
    }
  }
}
