import { CFG } from '../core/Config.js';
import { Rng, clamp, lerp } from '../core/Utils.js';
import { PATTERNS, powerRow, LN } from './Patterns.js';

const POWER_WEIGHTS = [['magnet', 22], ['shield', 22], ['speed', 17], ['double', 15], ['multiplier', 15], ['invincible', 4]];

/** Streams obstacle patterns, coin trails and power-ups ahead of the player. */
export class Spawner {
  constructor(obstacles, collectibles) { this.obs = obstacles; this.col = collectibles; this.rng = new Rng(1); this.reset(45, 1); }
  reset(startDist = 45, seed = (Math.random() * 1e9) | 0) {
    this.rng = new Rng(seed); this.next = startDist; this.free = 0; this.last = ''; this.powerAt = startDist + this.rng.range(140, 260); this.count = 0;
  }
  update(playerDist, speed, styleAt) {
    let guard = 0;
    while (this.next < playerDist + CFG.spawnAhead && guard++ < 6) this._spawn(speed, styleAt);
  }
  _spawn(speed, styleAt) {
    const rng = this.rng, dist = this.next, diff = clamp(dist / 3200, 0, 1), style = styleAt(dist);
    let pat;
    if (dist >= this.powerAt) {
      const kind = rng.weighted(POWER_WEIGHTS, (x) => x[1])[0];
      pat = powerRow(rng, kind); this.powerAt = dist + rng.range(CFG.powerupSpawnEvery[0], CFG.powerupSpawnEvery[1]); this.last = 'power';
    } else {
      const cands = PATTERNS.filter((p) => dist >= p.min);
      const p = rng.weighted(cands, (q) => q.w * (q.name === this.last ? 0.25 : 1) * ((q.name === 'coinRiver' || q.name === 'breather') && this.count < 2 ? 0 : 1));
      this.free = clamp(this.free + rng.pick([-1, 0, 0, 1]), -1, 1);
      pat = p.build({ rng, free: this.free, speed, diff }); this.last = p.name;
    }
    for (const o of pat.obs) this.obs.spawn(o.t, o.l, dist + o.dz, style, rng, o.opts || {});
    for (const c of pat.coins) {
      if (c.power) this.col.spawnPower(c.power, c.l, dist + c.dz, c.y);
      else this.col.spawnCoin(c.l, dist + c.dz, c.y, c.rare || (rng.next() < 0.02 && pat.obs.length === 0));
    }
    const gap = Math.max(9, speed * 0.9 + 4) * lerp(1, 0.82, diff) + rng.range(0, 7);
    this.next = dist + pat.len + gap; this.count++;
  }
}
