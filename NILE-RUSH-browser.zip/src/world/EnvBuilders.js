// Procedural scenery for each environment. Each builder fills one world segment (CFG.segLen metres).
import { C, shade, ground, road, building, minaret, mosqueDome, palm, deadPalm, lamp, bench, rock, dune, pyramid, obelisk, sphinx, tent, addBoat, lion, trainCarDecor, fanous, gate } from './Props.js';
import { SIGN } from './SignAtlas.js';

const SAILS = [[0.95, 0.93, 0.86], [0.95, 0.93, 0.86], [0.9, 0.55, 0.25], [0.35, 0.6, 0.75], [0.85, 0.8, 0.6]];

function row(d, ctx, side, nearX, o) {
  const { rng, z0, L } = ctx, zEnd = z0 - L; let zz = z0;
  while (zz > zEnd + 0.8) {
    let w = rng.range(o.wMin || 7, o.wMax || 12); const rem = zz - zEnd;
    if (rem - w < 5) w = rem;
    building(d, ctx, side, nearX, zz - w / 2, w, rng.range(o.hMin, o.hMax), rng.range(9, 14), o.b || {});
    zz -= w + (w === rem ? 0 : rng.range(0, 0.5));
  }
}
const farBank = (d, ctx, sx, n = 4) => {
  const { rng, z0, L } = ctx;
  for (let i = 0; i < n; i++) d.box(sx * rng.range(96, 150), 0, z0 - rng.range(0, L), rng.range(10, 24), rng.range(6, 34), rng.range(10, 20), shade(rng.pick(C.bldg), 0.85), { pat: 1, p1: rng.int(0, 99) });
};

export function buildCity(d, ctx, sunset = false) {
  const { rng, z0, L, q } = ctx, zc = z0 - L / 2;
  ground(d, ctx, -170, -4.4, -0.03, C.dirt, 5);
  road(d, ctx);
  d.box(-6.3, 0, zc, 3.8, 0.16, L, C.pavement);
  row(d, ctx, -1, -8.2, { hMin: 9, hMax: 26, b: sunset ? { palette: C.bldgOld } : {} });
  if (q.decor > 0.6) row(d, ctx, -1, -26, { hMin: 18, hMax: 46, wMin: 10, wMax: 16, b: { shop: false, balconies: false } });
  if (rng.next() < 0.5 * q.decor + 0.15) minaret(d, -30 - rng.range(0, 6), z0 - rng.range(4, 28), rng.range(28, 36), shade(C.stone, 0.95));
  for (const zz of [z0 - 4, z0 - 20]) lamp(d, -4.9, zz, -1);
  // promenade + river
  d.add('box', 7.2, 0.08, zc, 5.6, 0.16, L, C.pavementLight, { pat: 12 });
  d.box(10.1, 0.16, zc, 0.12, 0.95, L, C.metal);
  for (let k = 0; k < 8; k++) d.box(10.1, 0.16, z0 - 2 - k * 4, 0.2, 1.05, 0.2, C.dark);
  d.box(10.6, -2.6, zc, 0.9, 2.6, L, C.stone, { pat: 3 });
  d.add('plane', 71, -2.5, zc, 121, 1, L, sunset ? C.waterDusk : C.water, { pat: 4 });
  ground(d, ctx, 130, 300, -0.5, C.dirt, 5);
  for (let k = 0; k < 4; k++) palm(d, 8.6, z0 - 3 - k * 8, rng.range(6, 8.4), rng);
  for (const zz of [z0 - 10, z0 - 26]) lamp(d, 9.4, zz, 1);
  if (rng.next() < 0.6) bench(d, 5.6, z0 - rng.range(3, 29), Math.PI / 2);
  const nb = sunset ? 3 : 2;
  for (let i = 0; i < nb; i++) addBoat(d, rng.range(15, 55), -2.5, z0 - rng.range(0, L), rng.range(-0.15, 0.15) + (rng.next() < 0.5 ? 0 : Math.PI), rng.pick(SAILS));
  farBank(d, ctx, 1, 4);
  if (ctx.i % 5 === 2) { // lotus-topped tower on the far bank
    const tx = 72, tz = z0 - 10;
    d.add('cone', tx, 30, tz, 8, 60, 8, [0.72, 0.68, 0.6], { pat: 3 });
    d.add('sphere', tx, 62, tz, 9, 4, 9, [0.75, 0.7, 0.62]);
    d.add('cyl', tx, 66, tz, 2, 10, 2, C.metalLight);
  }
}

export function buildDesert(d, ctx, stormy = false) {
  const { rng, z0, L, q } = ctx, zc = z0 - L / 2;
  ground(d, ctx, -220, 220, -0.03, stormy ? C.sandDark : C.sand, 5);
  road(d, ctx, C.sandRoad, { noCurb: true, edge: shade(C.lane, 0.85) });
  for (const side of [-1, 1]) {
    const nd = Math.round((stormy ? 2 : 3) * q.decor + 0.4);
    for (let i = 0; i < nd; i++) dune(d, side * rng.range(14, 60), z0 - rng.range(0, L), rng.range(18, 44), rng.range(2.5, 9), rng.range(18, 36), rng.next() < 0.5 ? C.sand : C.sandLight);
    for (let i = 0; i < 3; i++) rock(d, side * rng.range(6.5, 22), z0 - rng.range(0, L), rng.range(0.8, 2.6), rng.pick([C.stoneDark, C.sandDark, shade(C.stone, 0.8)]), rng);
    // sand drifts hugging the road edge
    if (rng.next() < 0.6) d.add('dome', side * 5.6, -0.1, z0 - rng.range(0, L), rng.range(3, 6), 1.1, rng.range(6, 12), C.sandLight, { pat: 5 });
    if (ctx.i % 3 === (side > 0 ? 0 : 1)) pyramid(d, side * rng.range(75, 120), z0 - 10, rng.range(60, 96), shade(C.stone, 0.9));
  }
  if (!stormy) {
    if (rng.next() < 0.5) { const sx = rng.sign() * rng.range(9, 15), pz = z0 - rng.range(4, 26); for (let k = 0; k < 3; k++) palm(d, sx + rng.range(-2, 2), pz + rng.range(-3, 3), rng.range(5, 8), rng); }
    if (ctx.i % 8 === 3) sphinx(d, -18, z0 - 16, Math.PI / 2);
    if (ctx.i % 6 === 1) obelisk(d, 11, z0 - 12, 14, C.stone);
    if (ctx.i % 7 === 5) tent(d, -13, z0 - 14, 0.4, [0.75, 0.32, 0.22]);
    d.cyl(6.5, 0, z0 - 6, 0.3, 8, C.woodDark); d.box(6.5, 7.2, z0 - 6, 0.12, 0.12, 2.6, C.woodDark);
  } else {
    if (rng.next() < 0.7) deadPalm(d, rng.sign() * rng.range(8, 16), z0 - rng.range(3, 29), rng.range(5, 7), rng);
    if (rng.next() < 0.5) { const sx = rng.sign() * rng.range(9, 14), pz = z0 - rng.range(4, 26); d.box(sx, 0, pz, 1, rng.range(2, 4), rng.range(4, 7), C.stoneDark, { pat: 3 }); d.box(sx, 0, pz - 5, 1, rng.range(1, 2.5), 3, C.stoneDark, { pat: 3 }); }
    d.add('sign', 6.2, 3.4, z0 - 9, 2.6, 1.3, 1, [1, 1, 1], { pat: 11, p1: SIGN.CAUTION, ry: -0.35, rz: 0.12 });
    d.cyl(6.2, 0, z0 - 9, 0.14, 3, C.dark);
  }
}

export function buildBridge(d, ctx) {
  const { rng, z0, L } = ctx, zc = z0 - L / 2;
  d.box(0, -0.8, zc, 13.4, 0.78, L, [0.36, 0.38, 0.42], { pat: 6 });
  road(d, ctx, C.asphalt, { noCurb: true });
  for (const s of [-1, 1]) {
    d.box(s * 5.5, 0, zc, 2.2, 0.18, L, C.pavementLight, { pat: 12 });
    d.box(s * 6.55, 0, zc, 0.5, 1.15, L, C.stone, { pat: 3 });
    lamp(d, s * 6.2, z0 - 4, s); lamp(d, s * 6.2, z0 - 20, s);
    d.add('plane', s * 68, -6, zc, 122, 1, L, C.water, { pat: 4 });
    ground(d, ctx, s > 0 ? 128 : -300, s > 0 ? 300 : -128, -0.8, C.dirt, 5);
    d.box(s * 6.5, -0.8, z0 - 26, 1.8, 0.8, 1.2, C.stoneDark);
    farBank(d, ctx, s, 3);
    if (rng.next() < 0.7) addBoat(d, s * rng.range(14, 50), -6, z0 - rng.range(0, L), rng.range(-0.2, 0.2) + (rng.next() < 0.5 ? 0 : Math.PI), rng.pick(SAILS));
  }
  // steel arch every segment
  const steel = [0.16, 0.26, 0.5], az = z0 - 16, R = 6.9;
  for (let k = 0; k < 9; k++) {
    const a = (k / 8) * Math.PI, px = Math.cos(a) * R, py = 0.9 + Math.sin(a) * R;
    d.add('box', px, py, az, 3.1, 0.55, 0.55, steel, { rz: a + Math.PI / 2 });
    if (k > 0 && k < 8) d.add('box', px, (py + 0.4) / 2 + 0.1, az, 0.08, py - 0.4, 0.08, C.metalLight);
  }
  for (let k = 0; k < 4; k++) d.box(0, 0.9 + R * 0.5 + k * 1.5, az, 0.1, 0.1, 0.1, steel);
  d.cyl(0, -6, z0 - 24, 7, 5.3, C.stone, { pat: 3 });
  if (ctx.first) { lion(d, -7.6, z0 - 20, Math.PI / 2); lion(d, 7.6, z0 - 20, -Math.PI / 2); }
}

export function buildStation(d, ctx) {
  const { rng, z0, L } = ctx, zc = z0 - L / 2;
  ground(d, ctx, -40, 40, -0.03, [0.55, 0.52, 0.48], 12);
  road(d, ctx, [0.62, 0.6, 0.57], { pat: 12, noCurb: true, edge: [0.95, 0.8, 0.2] });
  for (const s of [-1, 1]) {
    d.box(s * 9.5, 0, zc, 7, 0.5, L, C.pavementLight, { pat: 12 });
    d.box(s * 6.2, 0.5, zc, 0.25, 0.03, L, [0.98, 0.82, 0.15], { em: 0.3 });
    for (let k = 0; k < 10; k++) d.box(s * 16.5, 0, z0 - 1.5 - k * 3.2, 4.2, 0.12, 0.5, C.woodDark);
    for (const dx of [-0.75, 0.75]) d.box(s * 16.5 + dx, 0.12, zc, 0.14, 0.14, L, C.metalLight);
    trainCarDecor(d, s * 20, z0 - 8, 15, C.train[(ctx.i + (s > 0 ? 1 : 3)) % C.train.length]);
    trainCarDecor(d, s * 20, z0 - 24, 15, C.train[(ctx.i + (s > 0 ? 2 : 0)) % C.train.length]);
    d.box(s * 27, 0, zc, 1, 14, L, C.stone, { pat: 3 });
    d.cyl(s * 6.7, 0, z0 - 8, 0.7, 10, C.metal); d.cyl(s * 6.7, 0, z0 - 24, 0.7, 10, C.metal);
    d.box(s * 12, 0.5, z0 - 14, 1.6, 0.5, 0.8, C.dark); d.box(s * 12, 0.5, z0 - 15, 0.9, 1.1, 0.7, C.wood);
    bench(d, s * 11, z0 - 4, Math.PI / 2);
  }
  d.box(0, 10, zc, 54, 0.6, L, [0.2, 0.22, 0.26]);
  for (const z of [z0 - 8, z0 - 24]) d.box(0, 9.5, z, 13.4, 0.5, 0.6, C.metal);
  for (const z of [z0 - 4, z0 - 12, z0 - 20, z0 - 28]) for (const x of [-9, -3, 3, 9]) {
    d.cyl(x, 8.6, z, 0.06, 1.4, C.dark); d.box(x, 8.3, z, 1.2, 0.18, 0.4, C.lampWarm, { pat: 15, p1: 2.6, em: 0.7 });
  }
  const pl = [SIGN.PLAT1, SIGN.PLAT2, SIGN.PLAT3, SIGN.METRO, SIGN.EXIT, SIGN.TICKETS][ctx.i % 6];
  d.add('sign', 0, 7.4, z0 - 16, 4, 2, 1, [1, 1, 1], { pat: 11, p1: pl });
  d.cyl(0, 7.2, z0 - 16, 0.05, 2.8, C.dark);
  d.add('sign', -6.65, 5.2, z0 - 8, 2.2, 1.1, 1, [1, 1, 1], { pat: 11, p1: SIGN.WELCOME, ry: Math.PI / 2 });
  d.add('cyl', 6.65, 6.2, z0 - 24, 1.5, 0.2, 1.5, C.white, { rz: Math.PI / 2, ry: 0 });
}

export function buildNight(d, ctx) {
  const { rng, z0, L, q } = ctx, zc = z0 - L / 2;
  ground(d, ctx, -120, 120, -0.03, [0.34, 0.3, 0.26], 5);
  road(d, ctx, [0.28, 0.27, 0.3], { pat: 12 });
  for (const s of [-1, 1]) {
    d.box(s * 6.3, 0, zc, 3.8, 0.16, L, C.pavement);
    row(d, ctx, s, s * 8.2, { hMin: 8, hMax: 19, b: { palette: C.bldgOld } });
    if (q.decor > 0.6 && rng.next() < 0.5) row(d, ctx, s, s * 25, { hMin: 16, hMax: 34, b: { shop: false, balconies: false } });
  }
  if (rng.next() < 0.55) { minaret(d, -21 - rng.range(0, 4), z0 - rng.range(6, 26), 30, C.stone); }
  if (rng.next() < 0.4) mosqueDome(d, 22, z0 - 16, 9, C.stone);
  const colors = [[1, 0.35, 0.2], [1, 0.72, 0.2], [0.2, 0.8, 0.75], [0.7, 0.3, 0.9], [1, 0.5, 0.6]];
  for (let k = 0; k < 4; k++) {
    const z = z0 - 4 - k * 8;
    d.box(0, 6.5, z, 16.4, 0.05, 0.05, C.dark);
    for (let j = 0; j < 5; j++) fanous(d, -6 + j * 3, 5.6 + rng.range(-0.2, 0.3), z, rng.pick(colors));
  }
  for (const s of [-1, 1]) lamp(d, s * 5.0, z0 - 12, s * 1);
}

export function buildEnv(env, d, ctx) {
  switch (env.id) {
    case 'cairo': buildCity(d, ctx, false); break;
    case 'sunset': buildCity(d, ctx, true); break;
    case 'desert': buildDesert(d, ctx, false); break;
    case 'storm': buildDesert(d, ctx, true); break;
    case 'bridge': buildBridge(d, ctx); break;
    case 'station': buildStation(d, ctx); break;
    case 'night': buildNight(d, ctx); break;
    default: buildCity(d, ctx, false);
  }
  if (ctx.first) gate(d, ctx, env.sign, env.accent);
}
