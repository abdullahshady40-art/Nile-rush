import { CFG } from '../core/Config.js';
import { Rng } from '../core/Utils.js';
import { Deco, drawBoat } from './Props.js';
import { buildEnv } from './EnvBuilders.js';
import { ENVS } from './Environments.js';

/** Endless procedural world: static decor segments are generated ahead of the player and recycled behind. */
export class World {
  constructor(renderer) {
    this.r = renderer; this.segs = new Map(); this.seed = 1; this.q = { decor: 1, view: 190 };
    this.lo = 0; this.hi = -1; this.built = 0;
  }
  reset(seed = (Math.random() * 1e9) | 0, q) {
    this.segs.clear(); this.seed = seed; if (q) this.q = q;
  }
  setQuality(q) { this.q = q; this.segs.clear(); }
  envIndexAt(dist) { return Math.floor(Math.max(dist, 0) / CFG.envLen) % ENVS.length; }

  _build(i) {
    const L = CFG.segLen, dist0 = i * L;
    const env = ENVS[this.envIndexAt(dist0)];
    const ctx = { i, z0: -dist0, L, rng: new Rng(this.seed + i * 7919), q: this.q, first: Math.floor(dist0 / CFG.envLen) !== Math.floor(Math.max(dist0 - L, -1) / CFG.envLen) || i === 0 };
    const d = new Deco(this.r.geo);
    buildEnv(env, d, ctx);
    const seg = { i, items: d.items(), dyn: d.dyn };
    this.segs.set(i, seg); this.built++;
    return seg;
  }

  /** Ensure segments around `dist` exist, drop the ones far behind. */
  update(dist) {
    const L = CFG.segLen, first = Math.floor((dist - 40) / L), last = Math.floor((dist + this.q.view + 20) / L);
    for (let i = Math.max(0, first); i <= last; i++) if (!this.segs.has(i)) this._build(i);
    for (const k of this.segs.keys()) if (k < first - 1 || k > last + 2) this.segs.delete(k);
  }

  draw(t) {
    const r = this.r;
    for (const seg of this.segs.values()) {
      for (const g of seg.items) r.submitRaw(g.geo, g.arr, g.n, g.pass);
      for (const b of seg.dyn) drawBoat(r, b.x, b.y, b.z, b.ry, b.sail, t, b.ph);
    }
  }
}
