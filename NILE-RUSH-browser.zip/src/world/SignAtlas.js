// Procedurally painted street signs (Arabic + English) packed into one texture atlas.
// Atlas: 4 columns x 8 rows, each cell 256x128. Cell index = row*4 + col (row 0 = top).
export const SIGN = {
  KOSHARI: 0, FUL: 1, CAFE: 2, PHARMACY: 3, JUICE: 4, BAKERY: 5, KHAN: 6, SWEETS: 7, GARAGE: 8, GROCERY: 9, FISH: 10,
  NILERUSH: 11, PLAT1: 12, PLAT2: 13, PLAT3: 14, EXIT: 15, METRO: 16, TICKETS: 17, WELCOME: 18, EGYPT: 19,
  ENV0: 20, ENV1: 21, ENV2: 22, ENV3: 23, ENV4: 24, ENV5: 25, ENV6: 26,
  CAUTION: 27, TEA: 28, BAZAAR: 29, HOTEL: 30, DETOUR: 31,
};
const D = [
  ['كشري القاهرة', 'KOSHARI', '#B3261E', '#FFF3D0'], ['فول وطعمية', 'FUL & TAAMEYA', '#1E6B3A', '#FFF3D0'],
  ['مقهى النيل', 'NILE CAFE', '#12336B', '#F5C451'], ['صيدلية', 'PHARMACY', '#0E7C66', '#FFFFFF'],
  ['عصير قصب', 'SUGARCANE', '#6DAA2C', '#10260A'], ['مخبز بلدي', 'BAKERY', '#8A4B1E', '#FFE9B8'],
  ['خان القاهرة', 'KHAN', '#4B2A6B', '#F5C451'], ['حلويات', 'SWEETS', '#C2477A', '#FFF3F7'],
  ['ورشة النيل', 'GARAGE', '#2B2F36', '#F5C451'], ['بقالة', 'GROCERY', '#2F7A9E', '#FFFFFF'],
  ['مطعم أسماك', 'FISH', '#0D5C7A', '#E9FBFF'], ['NILE RUSH', 'اجري مع النيل', '#0B1B47', '#F5C451'],
  ['رصيف ١', 'PLATFORM 1', '#12336B', '#FFFFFF'], ['رصيف ٢', 'PLATFORM 2', '#12336B', '#FFFFFF'],
  ['رصيف ٣', 'PLATFORM 3', '#12336B', '#FFFFFF'], ['مخرج', 'EXIT', '#0E7C4A', '#FFFFFF'],
  ['مترو', 'METRO', '#B3261E', '#FFFFFF'], ['تذاكر', 'TICKETS', '#1F2937', '#F5C451'],
  ['أهلاً بكم', 'WELCOME', '#0E7C66', '#FFF3D0'], ['مصر', 'EGYPT', '#1F2937', '#F5C451'],
  ['القاهرة', 'CAIRO · NILE', '#0B1B47', '#F5C451'], ['الصحراء', 'DESERT', '#8A5A1E', '#FFF3D0'],
  ['كوبري النيل', 'NILE BRIDGE', '#12336B', '#F5C451'], ['المحطة', 'TRAIN STATION', '#7A1E1E', '#FFF3D0'],
  ['ليل مصر', 'NIGHT EGYPT', '#0A1230', '#8FE3D8'], ['الغروب', 'SUNSET', '#B34A1E', '#FFF0C8'],
  ['عاصفة رمال', 'DUST STORM', '#5A3A1E', '#FFD9A0'],
  ['حذر', 'CAUTION', '#F2C200', '#111111'], ['شاي وقهوة', 'TEA & COFFEE', '#5B3A1E', '#FFE9B8'],
  ['سوق', 'BAZAAR', '#7A2E6B', '#FFE9B8'], ['فندق النيل', 'NILE HOTEL', '#12336B', '#FFFFFF'],
  ['تحويلة', 'DETOUR', '#F2C200', '#111111'],
];

export function paintSignAtlas() {
  const cw = 256, ch = 128;
  const cv = document.createElement('canvas'); cv.width = cw * 4; cv.height = ch * 8;
  const g = cv.getContext('2d');
  const arFont = '"Segoe UI","Noto Naskh Arabic","Noto Sans Arabic",Tahoma,"DejaVu Sans",Arial,sans-serif';
  D.forEach((s, i) => {
    const x = (i % 4) * cw, y = Math.floor(i / 4) * ch;
    g.save(); g.translate(x, y);
    g.fillStyle = s[2]; g.fillRect(0, 0, cw, ch);
    g.strokeStyle = s[3]; g.lineWidth = 6; g.strokeRect(9, 9, cw - 18, ch - 18);
    g.globalAlpha = 0.22; g.fillStyle = s[3]; g.fillRect(9, 9, cw - 18, 6); g.globalAlpha = 1;
    g.fillStyle = s[3]; g.textAlign = 'center'; g.textBaseline = 'middle';
    const fit = (txt, px, wgt, fam, maxW, cy) => {
      let sz = px; g.font = `${wgt} ${sz}px ${fam}`;
      while (g.measureText(txt).width > maxW && sz > 10) { sz -= 2; g.font = `${wgt} ${sz}px ${fam}`; }
      g.fillText(txt, cw / 2, cy);
    };
    g.direction = 'rtl'; fit(s[0], 50, 'bold', arFont, cw - 40, 50);
    g.direction = 'ltr'; fit(s[1], 24, 'bold', 'Arial Black,Arial,Helvetica,sans-serif', cw - 40, 98);
    g.restore();
  });
  return cv;
}
