#!/usr/bin/env node
// Static project check: JS syntax, import/export wiring, referenced files, manifest, service worker list.
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let errors = 0, checked = 0;
const fail = (m) => { errors++; console.error('  ✗ ' + m); };
const ok = (m) => console.log('  ✓ ' + m);

function walk(dir, out = []) {
  for (const n of fs.readdirSync(dir, { withFileTypes: true })) {
    if (n.name === 'node_modules' || n.name.startsWith('.')) continue;
    const p = path.join(dir, n.name); if (n.isDirectory()) walk(p, out); else out.push(p);
  }
  return out;
}
const all = walk(root);
const js = all.filter((f) => f.endsWith('.js') && !f.includes(path.sep + 'tools' + path.sep + 'world-test'));

console.log('JavaScript syntax');
for (const f of js) { const r = spawnSync(process.execPath, ['--check', f], { encoding: 'utf8' }); checked++; if (r.status !== 0) fail(path.relative(root, f) + '\n' + r.stderr); }
if (!errors) ok(`${checked} files parse`);

console.log('Imports / exports');
const exportsOf = new Map();
for (const f of js) {
  const src = fs.readFileSync(f, 'utf8'), names = new Set();
  for (const m of src.matchAll(/export\s+(?:async\s+)?(?:function\*?|class|const|let|var)\s+([A-Za-z0-9_$]+)/g)) names.add(m[1]);
  for (const m of src.matchAll(/export\s*\{([^}]+)\}/g)) m[1].split(',').forEach((s) => names.add(s.trim().split(/\s+as\s+/).pop()));
  exportsOf.set(f, names);
}
let imports = 0;
for (const f of js) {
  const src = fs.readFileSync(f, 'utf8');
  for (const m of src.matchAll(/import\s+(?:(\*\s+as\s+\w+)|\{([^}]*)\}|(\w+))?\s*(?:,\s*\{([^}]*)\})?\s*from\s+['"]([^'"]+)['"]/g)) {
    const spec = m[5]; if (!spec.startsWith('.')) continue; imports++;
    const target = path.resolve(path.dirname(f), spec);
    if (!fs.existsSync(target)) { fail(`${path.relative(root, f)}: missing module ${spec}`); continue; }
    const list = (m[2] || m[4] || '').split(',').map((s) => s.trim().split(/\s+as\s+/)[0]).filter(Boolean);
    const ex = exportsOf.get(target);
    if (ex) for (const n of list) if (!ex.has(n)) fail(`${path.relative(root, f)}: '${n}' is not exported by ${spec}`);
  }
}
ok(`${imports} relative imports resolved`);

console.log('Project files');
for (const f of ['index.html', 'manifest.json', 'sw.js', 'package.json', 'README.md', 'README-DEPLOY.md', 'netlify.toml', 'vercel.json', 'icons/icon-192.png', 'icons/icon-512.png', 'src/main.js', 'assets/assets.json']) if (!fs.existsSync(path.join(root, f))) fail('missing ' + f);
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
for (const m of html.matchAll(/(?:src|href)="([^"#?]+)"/g)) if (!/^(https?:|data:)/.test(m[1]) && !fs.existsSync(path.join(root, m[1]))) fail('index.html references missing ' + m[1]);
const man = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
for (const i of man.icons) if (!fs.existsSync(path.join(root, i.src))) fail('manifest icon missing ' + i.src);
if (!man.icons.some((i) => i.sizes === '192x192') || !man.icons.some((i) => i.sizes === '512x512')) fail('manifest needs 192 and 512 icons');
if (man.display !== 'standalone') fail('manifest display should be standalone');
const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8'); const list = JSON.parse(sw.match(/PRECACHE_START\*\/([\s\S]*?)\/\*PRECACHE_END/)[1]);
if (!list.length) fail('sw.js precache list is empty — run npm run build:sw');
for (const u of list) if (u !== './' && !fs.existsSync(path.join(root, u))) fail('sw.js precaches missing file ' + u);
for (const f of js) { const rel = path.relative(root, f).split(path.sep).join('/'); if (rel.startsWith('src/') && !list.includes(rel)) fail('sw.js precache list is missing ' + rel + ' — run npm run build:sw'); }
JSON.parse(fs.readFileSync(path.join(root, 'assets/assets.json'), 'utf8')); JSON.parse(fs.readFileSync(path.join(root, 'vercel.json'), 'utf8'));
ok('index.html, manifest, service worker, hosting configs');

console.log(errors ? `\n${errors} problem(s) found` : '\nAll checks passed');
process.exit(errors ? 1 : 0);
