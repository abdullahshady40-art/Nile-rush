#!/usr/bin/env node
// Regenerates the precache list + cache version inside sw.js from the files on disk.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const INCLUDE_DIRS = ['src', 'icons'];
const OPTIONAL_DIRS = ['assets'];               // user files: models/images/audio dropped in by the developer
const ROOT_FILES = ['index.html', 'manifest.json', 'assets/assets.json'];
const EXT = /\.(js|css|json|png|jpg|jpeg|webp|svg|html|glb|gltf|mp3|wav|webm)$/i;

function walk(dir, out = []) {
  for (const n of fs.readdirSync(path.join(root, dir), { withFileTypes: true })) {
    const rel = path.posix.join(dir, n.name);
    if (n.isDirectory()) walk(rel, out); else if (EXT.test(n.name) && !/README/i.test(n.name)) out.push(rel);
  }
  return out;
}
const files = new Set(['./', ...ROOT_FILES.filter((f) => fs.existsSync(path.join(root, f)))]);
for (const d of INCLUDE_DIRS) walk(d).forEach((f) => files.add(f));
for (const d of OPTIONAL_DIRS) if (fs.existsSync(path.join(root, d))) walk(d).forEach((f) => files.add(f));
const list = [...files].sort();
const hash = crypto.createHash('sha1');
for (const f of list) if (f !== './') hash.update(f).update(fs.readFileSync(path.join(root, f)));
const version = 'nile-rush-' + hash.digest('hex').slice(0, 10);

let sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');
sw = sw.replace(/const VERSION = '[^']*';/, `const VERSION = '${version}';`);
sw = sw.replace(/\/\*PRECACHE_START\*\/[\s\S]*?\/\*PRECACHE_END\*\//, `/*PRECACHE_START*/${JSON.stringify(list, null, 2)}/*PRECACHE_END*/`);
fs.writeFileSync(path.join(root, 'sw.js'), sw);
console.log(`sw.js updated: ${list.length} files, cache ${version}`);
