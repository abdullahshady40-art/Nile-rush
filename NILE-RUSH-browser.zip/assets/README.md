# Adding your own assets to NILE RUSH

NILE RUSH ships fully playable with **zero external assets** — every character,
building, sign, sound effect and music track is generated in code by the
NileForge engine. Everything in this folder is optional. Drop in files, point
to them from `assets/assets.json`, and the game will use them automatically;
anything you leave out keeps using the built-in procedural version.

## 1. 3D character / vehicle models (Meshy or any other tool)

1. Export your model as **`.glb`** (preferred, single file) or `.gltf` + `.bin` + textures.
2. Put the file in `assets/models/`, e.g. `assets/models/karim.glb`.
3. Register it in `assets/assets.json`:

```json
{
  "models": {
    "characters": {
      "karim": { "file": "karim.glb", "height": 1.75, "rotY": 0 }
    },
    "boards": {
      "felucca": { "file": "felucca-board.glb", "height": 0.5 }
    }
  }
}
```

- `height` — the model is rescaled so its own height (in metres, model space) equals this value. Tune until it matches the other characters.
- `rotY` — degrees to rotate the model so it faces the camera correctly (the game expects the character to face **towards the viewer**, i.e. +Z).
- Character ids must match `src/characters/CharacterData.js` (`karim`, `nour`, `amun`). Board ids must match `felucca`, `papyrus`, `lotus`, `barge`.
- The loader reads static geometry + base colour/texture only. Any animation/skinning data in the file is ignored — the engine animates the whole model (idle/run/jump/slide/hit/death/board) as one rigid piece, the same way it animates the built-in procedural characters. For fully skeletal animation you'd need to extend `src/rendering/GLTFLoader.js` and `src/characters/CharacterView.js`.
- If a model fails to load or isn't listed, that character silently falls back to the built-in procedural low-poly rig — nothing breaks.

**Using Meshy.ai:** generate your model, export/download as GLB, and follow the steps above. This project does not call the Meshy API itself and doesn't claim to — you generate the model on their site and simply drop the resulting file in.

## 2. Images (logo, textures)

Put image files in `assets/images/` and reference them:

```json
{
  "images": {
    "logo": "logo.png",
    "textures": { "billboard1": "poster1.jpg" }
  }
}
```

`logo` is currently reserved for a future custom title-screen logo swap; textures are validated on load (missing/broken files are skipped without crashing the game).

## 3. Music and sound effects

Put audio files (`.mp3`, `.wav`, or `.webm`) in `assets/audio/` and reference them:

```json
{
  "audio": {
    "music": { "menu": "menu-theme.mp3", "game": "run-theme.mp3" },
    "sfx": { "coin": "coin.wav", "jump": "jump.wav" }
  }
}
```

Valid SFX keys: `jump, land, slide, lane, coin, gem, hit, smash, near, shield, shieldBreak, magnet, speed, double, multiplier, invincible, dash, board, boardBreak, gameover, click, select, back, buy, error, count, go, reward, horn`.

If a track/effect is missing or fails to decode, the game keeps using its generated Web Audio version — you will never get a silent or broken button.

## Notes

- All paths in `assets.json` are relative to their folder (`assets/models/…`, `assets/images/…`, `assets/audio/…`) — don't include the folder name.
- Nothing here is required for hosting or judging the game: delete this whole `assets/` folder's contents (keep `assets.json` with empty values) and NILE RUSH runs exactly the same, just with its own built-in art and audio.
